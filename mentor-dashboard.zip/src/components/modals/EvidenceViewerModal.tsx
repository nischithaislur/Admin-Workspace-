import React from 'react';
import { X, FileText, CheckCircle2, Clock, ShieldCheck, Download, AlertTriangle } from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';

export const EvidenceViewerModal: React.FC = () => {
  const { isEvidenceModalOpen, setIsEvidenceModalOpen, viewingEvidence } = useWorkspace();

  if (!isEvidenceModalOpen || !viewingEvidence) return null;

  const isApproved = viewingEvidence.adminApprovalStatus === 'Approved';
  const isUnderReview = viewingEvidence.adminApprovalStatus === 'Under Review' || viewingEvidence.adminApprovalStatus === 'Pending Review';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-[#EDE8DC] w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-[#FAF8F5]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FAF0F2] text-[#4A121E] flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">
                Student Evidence Submission
              </span>
              <h2 className="font-serif text-base font-bold text-slate-900 truncate max-w-md">
                {viewingEvidence.title}
              </h2>
            </div>
          </div>
          <button
            onClick={() => setIsEvidenceModalOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Status banner */}
          <div
            className={`p-3.5 rounded-xl border flex items-center justify-between ${
              isApproved
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : isUnderReview
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}
          >
            <div className="flex items-center gap-2">
              {isApproved ? (
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
              ) : isUnderReview ? (
                <Clock className="w-5 h-5 text-amber-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
              )}
              <div>
                <p className="text-xs font-bold">
                  {isApproved
                    ? 'Formal Admin Verification Status: Approved'
                    : isUnderReview
                    ? 'Formal Admin Verification Status: Under Review'
                    : 'Formal Admin Verification Status: Revisions Requested'}
                </p>
                <p className="text-[11px] opacity-80">
                  {viewingEvidence.verifiedBy
                    ? `Verified by ${viewingEvidence.verifiedBy}`
                    : 'Awaiting Mesa Academic Review Committee review'}
                </p>
              </div>
            </div>

            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-white/80 shadow-xs">
              {viewingEvidence.fileType || 'PDF Document'}
            </span>
          </div>

          {/* Submission Info */}
          <div className="grid grid-cols-2 gap-4 text-xs bg-[#FAF8F5] p-3.5 rounded-xl border border-slate-200/60">
            <div>
              <span className="text-slate-500">Submission Date:</span>
              <p className="font-semibold text-slate-900">{viewingEvidence.submissionDate || 'Nov 02, 2026'}</p>
            </div>
            <div>
              <span className="text-slate-500">Document Cryptographic Hash:</span>
              <p className="font-mono text-[10px] text-slate-600 truncate">sha256:7f9b841a0e882... (Audited)</p>
            </div>
          </div>

          {/* Admin Feedback Box */}
          {viewingEvidence.adminFeedback && (
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-xs font-bold text-slate-800 block mb-1">
                Official Admin & Faculty Review Notes:
              </span>
              <p className="text-xs text-slate-700 italic leading-relaxed">
                "{viewingEvidence.adminFeedback}"
              </p>
            </div>
          )}

          {/* Simulated Document Preview */}
          <div className="border border-slate-200 rounded-xl p-5 bg-white space-y-3 shadow-inner">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 text-xs text-slate-500">
              <span className="font-serif font-bold text-slate-900">Document Content Preview</span>
              <span>4 Pages · Verified Extract</span>
            </div>

            <div className="space-y-2 text-xs text-slate-700 font-mono bg-slate-50 p-4 rounded-lg leading-relaxed max-h-48 overflow-y-auto">
              <p className="text-slate-900 font-bold font-sans">
                [EXECUTIVE SUMMARY · ILS PGP 2026 INCUBATION CELL]
              </p>
              <p>1. Objective: Empirical validation of core MSL hypothesis and customer friction logs.</p>
              <p>2. Methodology: Structured customer interviews (n=30), audited order fulfillment timestamps, and direct telemetry records.</p>
              <p>3. Quantitative Findings: Average delivery time logged at 11.4 mins with 48.2% 7-day cohort retention.</p>
              <p>4. Student Sign-off: Certified authentic by founders under Mesa Academic Honor Code.</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3.5 border-t border-slate-100 bg-[#FAF8F5]">
          <span className="text-[11px] text-slate-500">
            Per Mesa policy: Mentor can view evidence; formal approval is reserved for Admin.
          </span>
          <button
            onClick={() => setIsEvidenceModalOpen(false)}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19]"
          >
            Close Viewer
          </button>
        </div>
      </div>
    </div>
  );
};
