import React, { useState } from 'react';
import { X, Receipt, CheckCircle2, AlertCircle, Info } from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';

interface CreateInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateInvoiceModal: React.FC<CreateInvoiceModalProps> = ({ isOpen, onClose }) => {
  const { meetings, reports, invoices, createInvoice } = useWorkspace();
  const [selectedMeetingId, setSelectedMeetingId] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  // Eligible meetings: status === 'Completed' && has a report && not already invoiced
  const eligibleMeetings = meetings.filter((m) => {
    if (m.status !== 'Completed') return false;
    const hasReport = reports.some((r) => r.meetingId === m.id);
    const alreadyInvoiced = invoices.some((inv) => inv.meetingId === m.id);
    return hasReport && !alreadyInvoiced;
  });

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMeetingId) {
      setError('Please select an eligible verified mentorship session.');
      return;
    }

    const ok = createInvoice(selectedMeetingId);
    if (ok) {
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1200);
    } else {
      setError('Unable to generate invoice. Meeting may already be invoiced or pending report.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-[#EDE8DC] w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-[#FAF8F5]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#FAF0F2] text-[#4A121E] flex items-center justify-center">
              <Receipt className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-bold tracking-wider text-[#4A121E] uppercase">
                Mesa Incubation Cell
              </span>
              <h2 className="font-serif text-base font-bold text-slate-900">
                Generate Honorarium Invoice
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleGenerate} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Invoice generated and submitted for payment disbursement!</span>
            </div>
          )}

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-[#4A121E] shrink-0 mt-0.5" />
            <p>
              <strong className="text-slate-800">One-Meeting-One-Invoice Policy:</strong> In accordance with Mesa academic regulations, an invoice can only be generated once for an eligible session that has completed with a verified meeting report on file.
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-900 mb-1">
              Select Verified Session
            </label>
            {eligibleMeetings.length === 0 ? (
              <div className="p-4 rounded-xl border border-dashed border-slate-300 text-center text-xs text-slate-500 bg-[#FAF8F5]">
                No pending eligible sessions found. All completed meetings with approved reports have already been invoiced.
              </div>
            ) : (
              <select
                value={selectedMeetingId}
                onChange={(e) => {
                  setSelectedMeetingId(e.target.value);
                  setError('');
                }}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none bg-white"
                required
              >
                <option value="">-- Select Completed & Verified Session --</option>
                {eligibleMeetings.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.ventureName} · {new Date(m.scheduledAt).toLocaleDateString()} ({m.topic.slice(0, 35)}...)
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Institutional Rate Card */}
          <div className="p-4 rounded-xl bg-[#FAF8F5] border border-slate-200 space-y-2 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>Standard Mentorship Honorarium (45 min)</span>
              <span className="font-semibold text-slate-900">₹3,500.00</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>GST / Professional Tax (18%)</span>
              <span className="font-semibold text-slate-900">₹630.00</span>
            </div>
            <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-slate-900">
              <span>Total Payable Amount</span>
              <span className="text-[#4A121E] font-serif text-sm">₹4,130.00</span>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-700 hover:bg-slate-100 border border-slate-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={eligibleMeetings.length === 0 || success}
              className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] disabled:opacity-50 shadow-sm"
            >
              Generate & Submit Invoice
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
