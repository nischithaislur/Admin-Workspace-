import React, { useState, useEffect } from 'react';
import { X, CheckSquare, AlertCircle } from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';

export const CreateGoalModal: React.FC = () => {
  const {
    isGoalModalOpen,
    setIsGoalModalOpen,
    preselectedVentureForGoal,
    ventures,
    mentor,
    createGoal
  } = useWorkspace();

  const assignedVentures = ventures.filter((v) => v.isAssignedToCurrentMentor);

  const [ventureId, setVentureId] = useState(
    preselectedVentureForGoal || (assignedVentures[0] ? assignedVentures[0].id : '')
  );
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [milestone, setMilestone] = useState('MSL-3 Product-Solution Fit');
  const [dueDate, setDueDate] = useState(
    new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [error, setError] = useState('');

  useEffect(() => {
    if (preselectedVentureForGoal) {
      setVentureId(preselectedVentureForGoal);
      const v = ventures.find((item) => item.id === preselectedVentureForGoal);
      if (v && v.founders[0]) {
        setAssignedTo(v.founders[0].name);
      }
    } else if (assignedVentures.length > 0) {
      setVentureId(assignedVentures[0].id);
      if (assignedVentures[0].founders[0]) {
        setAssignedTo(assignedVentures[0].founders[0].name);
      }
    }
  }, [preselectedVentureForGoal, ventures]);

  const handleVentureChange = (id: string) => {
    setVentureId(id);
    const v = ventures.find((item) => item.id === id);
    if (v && v.founders[0]) {
      setAssignedTo(v.founders[0].name);
    }
  };

  if (!isGoalModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim() || !ventureId || !assignedTo.trim()) {
      setError('Please fill out all required goal fields.');
      return;
    }

    const selectedVenture = ventures.find((v) => v.id === ventureId);
    if (!selectedVenture) return;

    createGoal({
      ventureId: selectedVenture.id,
      ventureName: selectedVenture.name,
      title: title.trim(),
      description: description.trim(),
      assignedBy: {
        id: mentor.id,
        name: mentor.name,
        role: 'Principal Mentor'
      },
      assignedTo: assignedTo.trim(),
      dueDate,
      milestone
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-[#EDE8DC] w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-[#FAF8F5]">
          <div>
            <span className="text-[11px] font-semibold tracking-wider text-[#4A121E] uppercase">
              Authorized Mentor Action
            </span>
            <h2 className="font-serif text-lg font-bold text-slate-900">
              Assign Venture Goal / Milestone Task
            </h2>
          </div>
          <button
            onClick={() => setIsGoalModalOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-900 mb-1">
              Select Assigned Venture <span className="text-red-500">*</span>
            </label>
            <select
              value={ventureId}
              onChange={(e) => handleVentureChange(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none bg-white"
              required
            >
              {assignedVentures.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name} ({v.currentStage} · {v.currentMSL.split('—')[0]})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-900 mb-1">
              Goal / Task Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Conduct 15 Customer Friction Interviews with hostel wardens"
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-900 mb-1">
                Assignee (Founder) <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={assignedTo}
                onChange={(e) => setAssignedTo(e.target.value)}
                placeholder="Student founder name"
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-900 mb-1">
                Due Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-900 mb-1">
              Target Milestone / MSL Tag
            </label>
            <input
              type="text"
              value={milestone}
              onChange={(e) => setMilestone(e.target.value)}
              placeholder="e.g. MSL-2 Demand Verification, MSL-3 Unit Contribution"
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-900 mb-1">
              Description & Verification Rubric <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Clarify what student founders must submit as empirical evidence (e.g. signed logs, transcripts, sheets)..."
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none"
              required
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsGoalModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-700 hover:bg-slate-100 border border-slate-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-sm flex items-center gap-1.5"
            >
              <CheckSquare className="w-4 h-4" />
              <span>Assign Milestone Goal</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
