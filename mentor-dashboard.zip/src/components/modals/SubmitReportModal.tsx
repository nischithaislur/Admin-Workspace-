import React, { useState, useEffect } from 'react';
import { X, Star, Plus, Trash2, CheckCircle2, AlertCircle } from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';

export const SubmitReportModal: React.FC = () => {
  const {
    isReportModalOpen,
    setIsReportModalOpen,
    reportMeetingTarget,
    submitReport
  } = useWorkspace();

  const [summary, setSummary] = useState('');
  const [advice, setAdvice] = useState('');
  const [engagementScore, setEngagementScore] = useState(5);
  const [actionItems, setActionItems] = useState<
    { task: string; assignee: string; dueDate: string }[]
  >([{ task: '', assignee: '', dueDate: '' }]);
  const [error, setError] = useState('');

  useEffect(() => {
    if (reportMeetingTarget) {
      setSummary('');
      setAdvice('');
      setEngagementScore(5);
      setActionItems([
        {
          task: '',
          assignee: reportMeetingTarget.founderName.split('&')[0].trim(),
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
        }
      ]);
      setError('');
    }
  }, [reportMeetingTarget]);

  if (!isReportModalOpen || !reportMeetingTarget) return null;

  const handleAddActionItem = () => {
    setActionItems([
      ...actionItems,
      {
        task: '',
        assignee: reportMeetingTarget.founderName.split('&')[0].trim(),
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      }
    ]);
  };

  const handleRemoveActionItem = (index: number) => {
    setActionItems(actionItems.filter((_, i) => i !== index));
  };

  const handleActionItemChange = (index: number, field: 'task' | 'assignee' | 'dueDate', value: string) => {
    const updated = [...actionItems];
    updated[index][field] = value;
    setActionItems(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!summary.trim() || !advice.trim()) {
      setError('Please provide both the meeting summary and strategic advice provided.');
      return;
    }

    const filteredActions = actionItems.filter((item) => item.task.trim() !== '');

    submitReport({
      meetingId: reportMeetingTarget.id,
      ventureId: reportMeetingTarget.ventureId,
      ventureName: reportMeetingTarget.ventureName,
      mentorId: reportMeetingTarget.mentorId,
      mentorName: reportMeetingTarget.mentorName,
      sessionDate: new Date(reportMeetingTarget.scheduledAt).toLocaleDateString('en-US', {
        month: 'short',
        day: '2-digit',
        year: 'numeric'
      }),
      durationMinutes: reportMeetingTarget.durationMinutes || 45,
      meetingSummary: summary.trim(),
      adviceProvided: advice.trim(),
      founderEngagementScore: engagementScore,
      actionItems: filteredActions
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-[#EDE8DC] w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-[#FAF8F5]">
          <div>
            <span className="text-[11px] font-semibold tracking-wider text-[#4A121E] uppercase">
              Mentorship Meeting Report
            </span>
            <h2 className="font-serif text-lg font-bold text-slate-900">
              {reportMeetingTarget.ventureName} · {reportMeetingTarget.topic}
            </h2>
          </div>
          <button
            onClick={() => setIsReportModalOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-[#FAF8F5] p-3 rounded-xl border border-slate-200/60">
            <div>
              <span className="text-slate-500">Founder(s):</span>
              <p className="font-medium text-slate-900">{reportMeetingTarget.founderName}</p>
            </div>
            <div>
              <span className="text-slate-500">Scheduled Session:</span>
              <p className="font-medium text-slate-900">
                {new Date(reportMeetingTarget.scheduledAt).toLocaleString([], {
                  dateStyle: 'medium',
                  timeStyle: 'short'
                })}{' '}
                ({reportMeetingTarget.durationMinutes} min)
              </p>
            </div>
          </div>

          {/* Meeting Summary */}
          <div>
            <label className="block text-xs font-semibold text-slate-900 mb-1">
              Meeting Discussion Summary <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={3}
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              placeholder="Synthesize the key progress updates, challenges discussed, and customer/pilot findings shared by the founder..."
              className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:border-[#4A121E] focus:ring-1 focus:ring-[#4A121E] outline-none"
              required
            />
          </div>

          {/* Advice Provided */}
          <div>
            <label className="block text-xs font-semibold text-slate-900 mb-1">
              Mentorship Advice & Direction Provided <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={3}
              value={advice}
              onChange={(e) => setAdvice(e.target.value)}
              placeholder="Detail specific strategic advice, unit economics suggestions, go-to-market priorities, or contacts recommended..."
              className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:border-[#4A121E] focus:ring-1 focus:ring-[#4A121E] outline-none"
              required
            />
          </div>

          {/* Engagement Score */}
          <div>
            <label className="block text-xs font-semibold text-slate-900 mb-1.5">
              Founder Preparation & Engagement
            </label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((num) => (
                <button
                  type="button"
                  key={num}
                  onClick={() => setEngagementScore(num)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                    engagementScore >= num
                      ? 'bg-[#FAF0F2] text-[#4A121E] border-[#F5D0D8]'
                      : 'bg-white text-slate-400 border-slate-200'
                  }`}
                >
                  <Star className={`w-3.5 h-3.5 ${engagementScore >= num ? 'fill-[#4A121E]' : ''}`} />
                  <span>{num}</span>
                </button>
              ))}
              <span className="text-xs text-slate-500 ml-2">
                {engagementScore === 5
                  ? 'Exceptional - Thoroughly prepared & empirical'
                  : engagementScore === 4
                  ? 'Strong engagement'
                  : engagementScore === 3
                  ? 'Adequate'
                  : 'Needs better session preparation'}
              </span>
            </div>
          </div>

          {/* Action Items */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-900">
                Agreed Action Items & Follow-up Tasks
              </label>
              <button
                type="button"
                onClick={handleAddActionItem}
                className="text-xs text-[#4A121E] hover:underline flex items-center gap-1 font-medium"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Task</span>
              </button>
            </div>

            <div className="space-y-2">
              {actionItems.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={item.task}
                    onChange={(e) => handleActionItemChange(idx, 'task', e.target.value)}
                    placeholder="Task description (e.g. Finalize Pod 1 inventory audit)..."
                    className="flex-2 text-xs p-2 rounded-lg border border-slate-200 focus:border-[#4A121E] outline-none"
                  />
                  <input
                    type="text"
                    value={item.assignee}
                    onChange={(e) => handleActionItemChange(idx, 'assignee', e.target.value)}
                    placeholder="Assignee"
                    className="flex-1 text-xs p-2 rounded-lg border border-slate-200 focus:border-[#4A121E] outline-none"
                  />
                  <input
                    type="date"
                    value={item.dueDate}
                    onChange={(e) => handleActionItemChange(idx, 'dueDate', e.target.value)}
                    className="w-32 text-xs p-2 rounded-lg border border-slate-200 focus:border-[#4A121E] outline-none"
                  />
                  {actionItems.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveActionItem(idx)}
                      className="p-2 text-slate-400 hover:text-red-600 rounded-lg"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Notice */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600">
            <span className="font-semibold text-slate-700">Policy Note:</span> Once submitted, this report is archived in the venture's official history and routed to the Mesa Incubation Director. Approved reports qualify for institutional session honorarium invoicing.
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsReportModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-700 hover:bg-slate-100 border border-slate-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-sm flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Submit Meeting Report</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
