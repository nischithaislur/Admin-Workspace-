import React, { useState, useRef, useEffect } from 'react';
import {
  Menu,
  Bell,
  ChevronDown,
  User,
  Shield,
  Clock,
  LogOut,
  ExternalLink,
  Sparkles,
  Check,
  ChevronRight,
  Compass
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';

interface HeaderProps {
  onToggleMobileSidebar: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleMobileSidebar }) => {
  const {
    currentPage,
    setCurrentPage,
    mentor,
    selectedVenture,
    notifications,
    unreadNotificationsCount,
    markNotificationRead,
    markAllNotificationsRead,
    isSimulatingUnassignedMentor,
    setIsSimulatingUnassignedMentor,
    openVentureHistory
  } = useWorkspace();

  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isNotifMenuOpen, setIsNotifMenuOpen] = useState(false);

  const profileRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setIsNotifMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getPageTitle = () => {
    switch (currentPage) {
      case 'dashboard':
        return 'Mentorship Overview';
      case 'mentorship-sessions':
        return 'Mentorship Sessions';
      case 'meetings':
        return 'Mentorship Sessions · My Meetings';
      case 'reports':
        return 'Mentorship Sessions · Meeting Reports';
      case 'availability':
        return 'Mentorship Sessions · My Availability';
      case 'goals':
        return 'Goals & Tasks';
      case 'directory':
        return 'Startup Directory';
      case 'venture-history':
        return selectedVenture ? `${selectedVenture.name} · Complete Venture History` : 'Venture History';
      case 'availability':
        return 'My Availability';
      case 'invoices':
        return 'Invoices & Honorarium';
      case 'notifications':
        return 'Notifications';
      case 'profile':
        return 'My Profile';
      default:
        return 'Mentor Workspace';
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-[#EDE8DC] px-4 sm:px-6 lg:px-8 py-3.5 transition-colors">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Hamburger + Context Breadcrumb */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleMobileSidebar}
            className="p-2 -ml-2 rounded-lg text-slate-700 hover:text-[#4A121E] hover:bg-[#FCECEF]/60 lg:hidden"
            aria-label="Toggle navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 text-xs text-slate-600">
            {currentPage === 'venture-history' && selectedVenture ? (
              <div className="flex items-center gap-2 font-medium">
                <button
                  onClick={() => setCurrentPage('directory')}
                  className="hover:text-[#4A121E] transition-colors flex items-center gap-1"
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>Startup Directory</span>
                </button>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-[#4A121E] font-semibold">{selectedVenture.name}</span>
                <span className="hidden sm:inline text-slate-400">·</span>
                <span className="hidden sm:inline text-slate-600 font-normal">Venture History</span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className="font-serif text-slate-900 font-semibold text-sm sm:text-base tracking-tight">
                  {getPageTitle()}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Right: Badge, Notifications, Role Preview & Mentor Profile */}
        <div className="flex items-center gap-2.5 sm:gap-4">
          {/* Programme Badge */}
          <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FAF0F2] border border-[#F5D0D8] text-[#4A121E] text-xs font-semibold tracking-wide">
            <span className="w-1.5 h-1.5 rounded-full bg-[#4A121E]" />
            <span>ILS · PGP 2026</span>
          </div>

          {/* RLS Permission Switcher (Demo / Testing feature) */}
          <button
            onClick={() => setIsSimulatingUnassignedMentor(!isSimulatingUnassignedMentor)}
            title="Toggle between Assigned Principal Mentor view and Unassigned Mentor view to test Supabase RLS restrictions"
            className={`hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors border ${
              isSimulatingUnassignedMentor
                ? 'bg-amber-50 text-amber-900 border-amber-300'
                : 'bg-white text-slate-700 border-slate-200 hover:border-[#4A121E]/30'
            }`}
          >
            <Shield className="w-3 h-3 text-[#4A121E]" />
            <span>RLS Test: {isSimulatingUnassignedMentor ? 'Unassigned Mentor' : 'Assigned Mentor'}</span>
          </button>

          {/* Notification Bell */}
          <div className="relative" ref={notifRef}>
            <button
              onClick={() => setIsNotifMenuOpen(!isNotifMenuOpen)}
              className="relative p-2 rounded-xl text-slate-700 hover:text-[#4A121E] hover:bg-[#FCECEF]/60 transition-colors"
              aria-label="View notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-[#4A121E] text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-[#FAF8F5]">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>

            {/* Notification Dropdown */}
            {isNotifMenuOpen && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-[#EDE8DC] py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="flex items-center justify-between px-4 py-2 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="font-serif font-bold text-slate-900 text-sm">Notifications</span>
                    {unreadNotificationsCount > 0 && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#FCECEF] text-[#4A121E]">
                        {unreadNotificationsCount} new
                      </span>
                    )}
                  </div>
                  {unreadNotificationsCount > 0 && (
                    <button
                      onClick={markAllNotificationsRead}
                      className="text-xs text-[#4A121E] hover:underline font-medium"
                    >
                      Mark all as read
                    </button>
                  )}
                </div>

                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                  {notifications.slice(0, 5).map((notif) => (
                    <div
                      key={notif.id}
                      onClick={() => {
                        markNotificationRead(notif.id);
                        if (notif.actionUrl) {
                          openVentureHistory(notif.actionUrl);
                          setIsNotifMenuOpen(false);
                        }
                      }}
                      className={`p-3.5 hover:bg-slate-50 cursor-pointer transition-colors ${
                        !notif.read ? 'bg-[#FDF9F9]' : ''
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <p className={`text-xs ${!notif.read ? 'font-semibold text-slate-900' : 'text-slate-700'}`}>
                          {notif.title}
                        </p>
                        <span className="text-[10px] text-slate-400 shrink-0">{notif.timestamp}</span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-1 line-clamp-2">{notif.message}</p>
                    </div>
                  ))}
                </div>

                <div className="p-2 border-t border-slate-100 text-center">
                  <button
                    onClick={() => {
                      setCurrentPage('notifications');
                      setIsNotifMenuOpen(false);
                    }}
                    className="text-xs font-semibold text-[#4A121E] hover:underline py-1"
                  >
                    View all notifications
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Mentor Profile Dropdown */}
          <div className="relative" ref={profileRef}>
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="flex items-center gap-2.5 p-1.5 sm:px-3 sm:py-1.5 rounded-xl border border-slate-200/80 bg-white hover:border-[#4A121E]/40 hover:bg-[#FAF8F5] transition-all shadow-xs"
            >
              <div className="w-8 h-8 rounded-full bg-[#4A121E] text-white flex items-center justify-center font-bold text-xs shadow-xs">
                {mentor.name
                  .split(' ')
                  .map((n) => n[0])
                  .join('')
                  .slice(0, 2)}
              </div>
              <div className="hidden sm:block text-left">
                <p className="text-xs font-semibold text-slate-900 leading-tight">{mentor.name}</p>
                <p className="text-[10px] text-slate-500 font-medium">Principal Mentor</p>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 hidden sm:block" />
            </button>

            {/* Profile Dropdown Menu */}
            {isProfileMenuOpen && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-[#EDE8DC] p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-3 py-2 border-b border-slate-100 mb-1">
                  <p className="font-semibold text-sm text-slate-900">{mentor.name}</p>
                  <p className="text-xs text-slate-500">{mentor.email}</p>
                  <span className="inline-block mt-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#FAF0F2] text-[#4A121E]">
                    ILS · PGP 2026 Faculty
                  </span>
                </div>

                <div className="space-y-0.5">
                  <button
                    onClick={() => {
                      setCurrentPage('profile');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs text-slate-700 hover:bg-[#FCECEF]/60 hover:text-[#4A121E] transition-colors"
                  >
                    <User className="w-4 h-4" />
                    <span>My Profile & Expertise</span>
                  </button>
                  <button
                    onClick={() => {
                      setCurrentPage('availability');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs text-slate-700 hover:bg-[#FCECEF]/60 hover:text-[#4A121E] transition-colors"
                  >
                    <Clock className="w-4 h-4" />
                    <span>Office Hours & Availability</span>
                  </button>
                  <button
                    onClick={() => {
                      setCurrentPage('invoices');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs text-slate-700 hover:bg-[#FCECEF]/60 hover:text-[#4A121E] transition-colors"
                  >
                    <Shield className="w-4 h-4" />
                    <span>Honorarium & Invoices</span>
                  </button>
                </div>

                <div className="mt-2 pt-2 border-t border-slate-100">
                  <button
                    onClick={() => {
                      alert('Authenticated session active as Dr. Rajesh Sharma. Sign out disabled in incubator demo.');
                      setIsProfileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs text-slate-500 hover:bg-slate-100 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
