import React from 'react';
import {
  LayoutDashboard,
  Calendar,
  FileText,
  CheckSquare,
  Compass,
  Clock,
  Receipt,
  Bell,
  User,
  X,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { useWorkspace, WorkspacePage } from '../../context/WorkspaceContext';

interface SidebarProps {
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isMobileOpen, setIsMobileOpen }) => {
  const {
    currentPage,
    setCurrentPage,
    unreadNotificationsCount,
    meetings,
    mentor,
    selectedVenture
  } = useWorkspace();

  const pendingReportsCount = meetings.filter(
    (m) => m.status === 'Completed' && !m.reportSubmitted
  ).length;

  const navItems: { id: WorkspacePage; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5 shrink-0" /> },
    {
      id: 'mentorship-sessions',
      label: 'Mentorship Sessions',
      icon: <Calendar className="w-5 h-5 shrink-0" />,
      badge: pendingReportsCount > 0 ? pendingReportsCount : undefined
    },
    { id: 'goals', label: 'Goals & Tasks', icon: <CheckSquare className="w-5 h-5 shrink-0" /> },
    { id: 'directory', label: 'Startup Directory', icon: <Compass className="w-5 h-5 shrink-0" /> },
    { id: 'invoices', label: 'Invoices', icon: <Receipt className="w-5 h-5 shrink-0" /> },
    {
      id: 'notifications',
      label: 'Notifications',
      icon: <Bell className="w-5 h-5 shrink-0" />,
      badge: unreadNotificationsCount > 0 ? unreadNotificationsCount : undefined
    },
    { id: 'profile', label: 'My Profile', icon: <User className="w-5 h-5 shrink-0" /> }
  ];

  const handleNavClick = (pageId: WorkspacePage) => {
    setCurrentPage(pageId);
    setIsMobileOpen(false);
  };

  const isNavActive = (id: WorkspacePage) => {
    if (currentPage === id) return true;
    if (
      id === 'mentorship-sessions' &&
      (currentPage === 'mentorship-sessions' ||
        currentPage === 'meetings' ||
        currentPage === 'reports' ||
        currentPage === 'availability')
    ) {
      return true;
    }
    if (id === 'directory' && currentPage === 'venture-history') return true;
    return false;
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden transition-opacity"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-[#4A121E] text-white flex flex-col justify-between transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Top Header & Branding */}
        <div>
          <div className="flex items-center justify-between px-6 py-5 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-white/15 border border-white/20 flex items-center justify-center font-serif text-lg font-bold text-white shadow-inner">
                M
              </div>
              <div>
                <h1 className="font-serif text-base font-bold tracking-wide uppercase leading-tight text-white">
                  Mesa Startup Hub
                </h1>
                <p className="text-[11px] font-medium tracking-wider text-white/70 uppercase">
                  Mentor Workspace
                </p>
              </div>
            </div>

            {/* Mobile close button */}
            <button
              onClick={() => setIsMobileOpen(false)}
              className="p-1 rounded-lg text-white/70 hover:text-white hover:bg-white/10 lg:hidden"
              aria-label="Close sidebar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Items */}
          <nav className="px-3 py-4 space-y-1 overflow-y-auto max-h-[calc(100vh-210px)]">
            {navItems.map((item) => {
              const active = isNavActive(item.id);
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${
                    active
                      ? 'bg-white text-[#4A121E] shadow-sm font-semibold'
                      : 'text-white/80 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-3 truncate">
                    {item.icon}
                    <span className="truncate">{item.label}</span>
                  </div>

                  {item.badge !== undefined && (
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                        active
                          ? 'bg-[#4A121E] text-white'
                          : 'bg-white text-[#4A121E]'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Mentor Information & Programme Pill */}
        <div className="p-4 border-t border-white/10 bg-[#3F0F19]">
          <div className="flex items-center gap-3 p-2 rounded-xl bg-white/5 border border-white/10">
            <div className="w-10 h-10 rounded-full bg-white text-[#4A121E] font-bold flex items-center justify-center text-sm shadow shrink-0">
              {mentor.name
                .split(' ')
                .map((n) => n[0])
                .join('')
                .slice(0, 2)}
            </div>
            <div className="truncate flex-1">
              <p className="text-xs font-semibold text-white truncate">{mentor.name}</p>
              <p className="text-[11px] text-white/70 truncate">{mentor.programmeRole}</p>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between text-[11px] text-white/60 px-1">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Verified Faculty Mentor
            </span>
            <span>2026 Batch</span>
          </div>
        </div>
      </aside>
    </>
  );
};
