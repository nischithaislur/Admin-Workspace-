import React, { useState } from 'react';
import {
  ArrowLeft,
  Building2,
  Users,
  Calendar,
  CheckCircle2,
  Clock,
  FileText,
  ShieldCheck,
  AlertCircle,
  ExternalLink,
  Plus,
  Compass,
  FileCheck2,
  Target,
  Sparkles,
  BookOpen,
  Eye,
  Lock,
  ChevronRight,
  GraduationCap,
  MessageSquare,
  Award,
  TrendingUp,
  Tag
} from 'lucide-react';
import { useWorkspace, VentureHistoryTab } from '../../context/WorkspaceContext';
import { Stage } from '../../types';

export const VentureHistoryPage: React.FC = () => {
  const {
    selectedVenture,
    backToDirectory,
    ventureHistoryTab,
    setVentureHistoryTab,
    meetings,
    reports,
    goals,
    getVentureActivities,
    openReportModal,
    openGoalModal,
    openEvidenceModal,
    mentor,
    isSimulatingUnassignedMentor,
    setIsSimulatingUnassignedMentor
  } = useWorkspace();

  const [taskFilter, setTaskFilter] = useState<'All' | 'In Progress' | 'Completed' | 'Overdue'>('All');

  if (!selectedVenture) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center border border-[#EDE8DC] max-w-xl mx-auto space-y-4">
        <AlertCircle className="w-10 h-10 text-[#4A121E] mx-auto" />
        <h2 className="font-serif text-xl font-bold text-slate-900">Venture Not Selected</h2>
        <p className="text-xs text-slate-600">Please choose a startup from the directory to view its history.</p>
        <button
          onClick={backToDirectory}
          className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-[#4A121E]"
        >
          Back to Startup Directory
        </button>
      </div>
    );
  }

  // Permission logic: Check if assigned to Dr. Rajesh Sharma
  const isAssigned = isSimulatingUnassignedMentor ? false : selectedVenture.isAssignedToCurrentMentor;

  // Filtered goals for this venture
  const ventureGoals = goals.filter((g) => g.ventureId === selectedVenture.id);
  const filteredGoals = ventureGoals.filter((g) => {
    if (taskFilter === 'All') return true;
    return g.status === taskFilter;
  });

  // Filtered meetings for this venture
  // Notice: Pending student meeting requests remain invisible until Admin approval!
  const ventureMeetings = meetings.filter(
    (m) => m.ventureId === selectedVenture.id && (m.adminApproved || m.status === 'Completed')
  );

  // Venture activities timeline
  const activities = getVentureActivities(selectedVenture.id);

  const tabs: { id: VentureHistoryTab; label: string; count?: number }[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'journey', label: 'Journey & Playbook' },
    { id: 'goals', label: 'Goals & Evidence', count: ventureGoals.length },
    { id: 'meetings', label: 'Meetings', count: ventureMeetings.length },
    { id: 'msl', label: 'MSL Readiness', count: selectedVenture.mslCriteria.length },
    { id: 'activity', label: 'Activity Timeline', count: activities.length }
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Navigation & Breadcrumbs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <button
          onClick={backToDirectory}
          className="inline-flex items-center gap-2 text-xs font-semibold text-[#4A121E] hover:underline transition-colors w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Startup Directory</span>
        </button>

        {/* Assigned badge & simulated switcher */}
        <div className="flex items-center gap-2">
          {isAssigned ? (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Assigned Faculty Mentor Access</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-900 text-xs font-bold">
              <Lock className="w-3.5 h-3.5 text-amber-600" />
              <span>External Faculty Observer (Restricted Access)</span>
            </div>
          )}
        </div>
      </div>

      {/* Main Venture Hero Header Card */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#EDE8DC] shadow-xs space-y-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          {/* Logo & Basic Info */}
          <div className="flex items-start gap-4 sm:gap-5">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-[#FAF0F2] text-[#4A121E] font-serif font-bold text-2xl sm:text-3xl flex items-center justify-center border border-[#F5D0D8] shadow-sm shrink-0">
              {selectedVenture.logo}
            </div>
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2.5">
                <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
                  {selectedVenture.name}
                </h1>
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#FAF0F2] text-[#4A121E] border border-[#F5D0D8]">
                  {selectedVenture.programme}
                </span>
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                  {selectedVenture.status}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-700 font-medium max-w-3xl">
                {selectedVenture.tagline}
              </p>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 pt-1">
                <span>{selectedVenture.industry}</span>
                <span>·</span>
                <span>Founded {selectedVenture.foundingDate}</span>
                <span>·</span>
                <span className="font-semibold text-[#4A121E]">
                  {selectedVenture.currentMSL.split('—')[0]}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          {isAssigned && (
            <div className="flex flex-wrap sm:flex-nowrap items-center gap-2.5 shrink-0">
              <button
                onClick={() => openGoalModal(selectedVenture.id)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-xs flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Assign Goal / Task</span>
              </button>
            </div>
          )}
        </div>

        {/* 5-Stage Journey Progress Tracker Strip */}
        <div className="pt-4 border-t border-slate-100">
          <div className="flex items-center justify-between mb-3 text-xs">
            <span className="font-semibold text-slate-700">Startup Progression Milestones</span>
            <span className="text-slate-500">
              Current Stage: <strong className="text-[#4A121E]">{selectedVenture.currentStage}</strong>
            </span>
          </div>

          <div className="grid grid-cols-5 gap-2 sm:gap-3">
            {(['Discover', 'Validate', 'Build', 'Launch', 'Grow'] as Stage[]).map((stage, idx) => {
              const stageOrder = ['Discover', 'Validate', 'Build', 'Launch', 'Grow'];
              const currentIdx = stageOrder.indexOf(selectedVenture.currentStage);
              const isPast = idx < currentIdx;
              const isCurrent = idx === currentIdx;

              return (
                <div
                  key={stage}
                  className={`p-2.5 sm:p-3 rounded-xl border text-center transition-all ${
                    isPast
                      ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                      : isCurrent
                      ? 'bg-[#FAF0F2] border-[#4A121E] text-[#4A121E] ring-1 ring-[#4A121E]'
                      : 'bg-[#FAF8F5] border-slate-200/70 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1 mb-1">
                    {isPast ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    ) : isCurrent ? (
                      <span className="w-2 h-2 rounded-full bg-[#4A121E] animate-pulse" />
                    ) : (
                      <span className="w-2 h-2 rounded-full bg-slate-300" />
                    )}
                    <span className="text-[10px] font-bold uppercase tracking-wider">
                      Stage {idx + 1}
                    </span>
                  </div>
                  <p className="font-serif text-xs font-bold truncate">{stage}</p>
                  <p className="text-[10px] mt-0.5 opacity-80 hidden sm:block">
                    {isPast ? 'Verified' : isCurrent ? 'In Progress' : 'Upcoming'}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 overflow-x-auto border-t border-slate-100 pt-3">
          {tabs.map((tab) => {
            const active = ventureHistoryTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setVentureHistoryTab(tab.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  active
                    ? 'bg-[#4A121E] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <span>{tab.label}</span>
                {tab.count !== undefined && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                      active ? 'bg-white/20 text-white' : 'bg-slate-200/80 text-slate-700'
                    }`}
                  >
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Permission Gate Warning if simulated unassigned */}
      {!isAssigned && (
        <div className="bg-amber-50 rounded-2xl p-6 border border-amber-200 text-amber-900 space-y-3">
          <div className="flex items-start gap-3">
            <Lock className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <h2 className="text-sm font-bold">
                Restricted Venture Access · Supabase Row Level Security (RLS) Active
              </h2>
              <p className="text-xs text-amber-800 mt-1 leading-relaxed">
                You are currently viewing this startup as an external faculty member. Under Mesa incubator privacy policy, private founder interview transcripts, internal feedback rubrics, and detailed Playbook evidence files are restricted to assigned Principal Mentors ({selectedVenture.mentorAssignment.principalMentor.name}).
              </p>
            </div>
          </div>
          <div className="pt-2 flex items-center gap-3">
            <button
              onClick={() => setIsSimulatingUnassignedMentor(false)}
              className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-[#4A121E] text-white hover:bg-[#3D0F19]"
            >
              Switch back to Assigned Mentor View
            </button>
            <span className="text-[11px] text-amber-700 italic">
              Demonstrates row-level access control enforced at the database layer.
            </span>
          </div>
        </div>
      )}

      {/* TAB 1: OVERVIEW */}
      {ventureHistoryTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left 2 Cols: Detailed Overview & Team */}
            <div className="lg:col-span-2 space-y-6">
              {/* Section A: Venture Narrative & Description */}
              <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-3">
                <h2 className="font-serif text-lg font-bold text-slate-900">
                  Venture Overview & Problem Statement
                </h2>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {selectedVenture.description}
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-100 text-xs">
                  <div>
                    <span className="text-slate-400">Target Market:</span>
                    <p className="font-semibold text-slate-800">{selectedVenture.metrics.targetMarket}</p>
                  </div>
                  <div>
                    <span className="text-slate-400">Grant / Funding:</span>
                    <p className="font-semibold text-slate-800">
                      {selectedVenture.metrics.fundingRaised || 'Bootstrapped'}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400">Monthly Run-rate:</span>
                    <p className="font-semibold text-[#4A121E] font-mono">
                      {selectedVenture.metrics.mrr || 'Pre-revenue'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Section B: Founders & Team */}
              <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h2 className="font-serif text-lg font-bold text-slate-900">
                    Founders & Core Leadership Team
                  </h2>
                  <span className="text-xs text-slate-500">{selectedVenture.founders.length} Co-Founders</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {selectedVenture.founders.map((founder, i) => (
                    <div
                      key={i}
                      className="p-4 rounded-xl border border-slate-200/80 bg-[#FAF8F5] space-y-2"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-white text-[#4A121E] font-bold text-xs flex items-center justify-center border border-slate-200 shadow-xs">
                          {founder.name
                            .split(' ')
                            .map((n) => n[0])
                            .join('')}
                        </div>
                        <div>
                          <p className="font-serif font-bold text-sm text-slate-900">{founder.name}</p>
                          <p className="text-xs text-slate-600 font-medium">{founder.role}</p>
                        </div>
                      </div>
                      <div className="text-[11px] text-slate-500 space-y-0.5 pt-1 border-t border-slate-200/60">
                        <p>{founder.programBatch}</p>
                        <p className="font-mono">{founder.email}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Section H: Workshops & Participation Summary */}
              <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div>
                    <h2 className="font-serif text-lg font-bold text-slate-900">
                      Workshops & Faculty Learning Sessions
                    </h2>
                    <p className="text-xs text-slate-500">Official incubator seminar attendance records</p>
                  </div>
                  <GraduationCap className="w-5 h-5 text-[#4A121E]" />
                </div>

                <div className="space-y-2.5">
                  {selectedVenture.workshops.map((ws) => (
                    <div
                      key={ws.id}
                      className="p-3.5 rounded-xl border border-slate-200/70 bg-[#FAF8F5] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <p className="font-bold text-slate-900">{ws.title}</p>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 font-semibold border border-emerald-200">
                            Attended ({ws.attendanceType})
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500">
                          Instructor: {ws.instructor} · Date: {ws.date}
                        </p>
                        {ws.notes && (
                          <p className="text-[11px] text-slate-600 italic mt-1">"{ws.notes}"</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Col: Mentor Assignment & Key Metrics */}
            <div className="space-y-6">
              {/* Mentors Card */}
              <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-4">
                <h2 className="font-serif text-base font-bold text-slate-900 pb-2 border-b border-slate-100">
                  Assigned Mentorship Board
                </h2>

                <div className="space-y-3">
                  <div className="p-3.5 rounded-xl bg-[#FAF0F2] border border-[#F5D0D8] space-y-1">
                    <span className="text-[10px] font-bold uppercase text-[#4A121E] tracking-wider">
                      Principal Mentor
                    </span>
                    <p className="font-serif font-bold text-sm text-slate-900">
                      {selectedVenture.mentorAssignment.principalMentor.name}
                    </p>
                    <p className="text-[11px] text-slate-600">
                      {selectedVenture.mentorAssignment.principalMentor.email}
                    </p>
                  </div>

                  {selectedVenture.mentorAssignment.associateMentor && (
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                      <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">
                        Associate Mentor
                      </span>
                      <p className="font-serif font-bold text-sm text-slate-900">
                        {selectedVenture.mentorAssignment.associateMentor.name}
                      </p>
                      <p className="text-[11px] text-slate-600">
                        {selectedVenture.mentorAssignment.associateMentor.email}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Empirical Proof Metrics */}
              <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-3">
                <h2 className="font-serif text-base font-bold text-slate-900 pb-2 border-b border-slate-100">
                  Venture Pulse & Traction
                </h2>
                <div className="space-y-2.5 text-xs">
                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-500">Customer Interviews:</span>
                    <span className="font-bold text-slate-900 tabular-nums">
                      {selectedVenture.metrics.customerInterviewsCount} verified
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-500">Team Size:</span>
                    <span className="font-bold text-slate-900 tabular-nums">
                      {selectedVenture.metrics.teamSize} members
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-500">MSL Verification:</span>
                    <span className="font-bold text-[#4A121E]">
                      {selectedVenture.mslCriteria.filter((c) => c.isVerified).length} / {selectedVenture.mslCriteria.length} Verified
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: JOURNEY & PLAYBOOK */}
      {ventureHistoryTab === 'journey' && (
        <div className="space-y-6">
          {/* Section C: Complete Startup Journey Progression */}
          <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-4">
            <div>
              <h2 className="font-serif text-lg font-bold text-slate-900">
                Complete Startup Journey & Milestone History
              </h2>
              <p className="text-xs text-slate-500">
                Chronological stage progression from initial discovery through commercial expansion
              </p>
            </div>

            <div className="space-y-3">
              {selectedVenture.stageMilestones.map((m, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs ${
                    m.status === 'Completed'
                      ? 'bg-emerald-50/50 border-emerald-200'
                      : m.status === 'Current'
                      ? 'bg-[#FAF0F2] border-[#F5D0D8] ring-1 ring-[#4A121E]/30'
                      : 'bg-slate-50/50 border-slate-200 opacity-70'
                  }`}
                >
                  <div className="flex items-start sm:items-center gap-3">
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                        m.status === 'Completed'
                          ? 'bg-emerald-600 text-white'
                          : m.status === 'Current'
                          ? 'bg-[#4A121E] text-white'
                          : 'bg-slate-300 text-slate-700'
                      }`}
                    >
                      {idx + 1}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-serif font-bold text-slate-900 text-sm">
                          {m.stage} Stage
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            m.status === 'Completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : m.status === 'Current'
                              ? 'bg-[#4A121E] text-white'
                              : 'bg-slate-200 text-slate-700'
                          }`}
                        >
                          {m.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-700 font-medium mt-0.5">
                        Key Milestone: {m.milestoneName}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    {m.completionDate ? (
                      <span className="text-emerald-800 font-mono text-[11px] font-semibold">
                        Completed {m.completionDate}
                      </span>
                    ) : (
                      <span className="text-slate-500 text-[11px]">In progress</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section D: Playbook History & Student Evidence Submissions */}
          <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="font-serif text-lg font-bold text-slate-900">
                  Student Playbook History & Evidence Deliverables
                </h2>
                <p className="text-xs text-slate-500">
                  Curriculum sprint activities, verified proof submissions, and faculty feedback
                </p>
              </div>
              <span className="text-xs font-semibold text-[#4A121E] bg-[#FAF0F2] px-3 py-1 rounded-full border border-[#F5D0D8]">
                {selectedVenture.playbookWeeks.length} Curriculum Sprints Documented
              </span>
            </div>

            <div className="space-y-6">
              {selectedVenture.playbookWeeks.map((week) => (
                <div
                  key={week.weekNumber}
                  className="border border-slate-200 rounded-xl overflow-hidden bg-[#FAF8F5]/50"
                >
                  <div className="px-5 py-3.5 bg-[#FAF8F5] border-b border-slate-200 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold uppercase text-[#4A121E] tracking-wider">
                        Week {week.weekNumber} · {week.phase}
                      </span>
                      <h3 className="font-serif font-bold text-sm text-slate-900">
                        {week.title}
                      </h3>
                    </div>
                    <span
                      className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                        week.status === 'Completed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-[#4A121E] text-white'
                      }`}
                    >
                      {week.status}
                    </span>
                  </div>

                  <div className="p-5 divide-y divide-slate-100 space-y-4">
                    {week.activities.map((act) => (
                      <div key={act.id} className="pt-3 first:pt-0 space-y-2">
                        <div className="flex items-start justify-between gap-3 text-xs">
                          <div>
                            <div className="flex items-center gap-2">
                              {act.status === 'Completed' ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                              ) : (
                                <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                              )}
                              <span className="font-semibold text-slate-900">{act.title}</span>
                            </div>
                            <p className="text-slate-600 text-[11px] mt-0.5 ml-6">
                              {act.description}
                            </p>
                          </div>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                              act.status === 'Completed'
                                ? 'bg-emerald-50 text-emerald-700'
                                : 'bg-amber-50 text-amber-700'
                            }`}
                          >
                            {act.status}
                          </span>
                        </div>

                        {/* Evidence attachment box */}
                        {act.evidenceSubmitted && (
                          <div className="ml-6 p-3 rounded-xl bg-white border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2">
                                <FileText className="w-4 h-4 text-[#4A121E]" />
                                <span className="font-medium text-slate-900">
                                  {act.evidenceSubmitted.title}
                                </span>
                                <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                                  Admin {act.evidenceSubmitted.adminApprovalStatus}
                                </span>
                              </div>
                              {act.evidenceSubmitted.adminFeedback && (
                                <p className="text-[11px] text-slate-500 italic">
                                  Admin Note: "{act.evidenceSubmitted.adminFeedback}"
                                </p>
                              )}
                            </div>

                            <button
                              onClick={() => openEvidenceModal(act.evidenceSubmitted)}
                              className="px-3 py-1 rounded-lg text-xs font-semibold text-[#4A121E] bg-[#FAF0F2] hover:bg-[#F5D0D8] border border-[#F5D0D8] flex items-center gap-1 shrink-0 w-fit"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>View Approved Evidence</span>
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: GOALS & EVIDENCE */}
      {ventureHistoryTab === 'goals' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-100">
              <div>
                <h2 className="font-serif text-lg font-bold text-slate-900">
                  Goals & Tasks History
                </h2>
                <p className="text-xs text-slate-500">
                  Goals assigned by Admin and authorized Principal/Associate Mentors
                </p>
              </div>

              <div className="flex items-center gap-2">
                {/* Filters */}
                {(['All', 'In Progress', 'Completed', 'Overdue'] as const).map((status) => (
                  <button
                    key={status}
                    onClick={() => setTaskFilter(status)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      taskFilter === status
                        ? 'bg-[#4A121E] text-white font-bold'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {status}
                  </button>
                ))}

                {isAssigned && (
                  <button
                    onClick={() => openGoalModal(selectedVenture.id)}
                    className="ml-2 px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] flex items-center gap-1 shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Assign Goal</span>
                  </button>
                )}
              </div>
            </div>

            <div className="space-y-3">
              {filteredGoals.map((goal) => (
                <div
                  key={goal.id}
                  className="p-4 rounded-xl border border-slate-200/80 bg-[#FAF8F5] space-y-2 hover:bg-white transition-all"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-serif text-sm font-bold text-slate-900">
                          {goal.title}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            goal.status === 'Completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : goal.status === 'Overdue'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {goal.status}
                        </span>
                      </div>
                      <p className="text-slate-600 text-xs mt-1">{goal.description}</p>
                    </div>

                    <div className="text-right shrink-0 space-y-0.5">
                      <p className="text-slate-500 text-[11px]">
                        Due: <strong className="text-slate-800 font-mono">{goal.dueDate}</strong>
                      </p>
                      <p className="text-slate-400 text-[10px]">
                        Assigned by {goal.assignedBy.name} ({goal.assignedBy.role})
                      </p>
                    </div>
                  </div>

                  {/* Submission & Evidence details */}
                  {goal.evidenceSubmitted && (
                    <div className="mt-2 p-3 bg-white rounded-lg border border-slate-200 text-xs flex items-center justify-between">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <FileCheck2 className="w-4 h-4 text-[#4A121E]" />
                          <span className="font-semibold text-slate-900">
                            {goal.evidenceSubmitted.title}
                          </span>
                          <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-slate-100 text-slate-700">
                            Status: {goal.evidenceSubmitted.status}
                          </span>
                        </div>
                        {goal.evidenceSubmitted.adminFeedback && (
                          <p className="text-[11px] text-slate-500 italic">
                            Feedback: "{goal.evidenceSubmitted.adminFeedback}"
                          </p>
                        )}
                      </div>

                      <button
                        onClick={() => openEvidenceModal(goal.evidenceSubmitted)}
                        className="text-xs font-semibold text-[#4A121E] hover:underline flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Inspect Evidence</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}

              {filteredGoals.length === 0 && (
                <div className="p-8 text-center text-xs text-slate-500">
                  No goals found matching status "{taskFilter}".
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: MEETINGS & REPORTS */}
      {ventureHistoryTab === 'meetings' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div>
                <h2 className="font-serif text-lg font-bold text-slate-900">
                  Mentorship & Meeting History
                </h2>
                <p className="text-xs text-slate-500">
                  Chronological archive of approved and completed mentorship clinics
                </p>
              </div>

              <div className="text-[11px] text-slate-500 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
                <span className="font-semibold text-slate-700">Notice:</span> Pending student meeting requests remain invisible until approved by Mesa Admin.
              </div>
            </div>

            <div className="space-y-4">
              {ventureMeetings.map((mtg) => {
                const report = reports.find((r) => r.meetingId === mtg.id);

                return (
                  <div
                    key={mtg.id}
                    className="p-5 rounded-xl border border-slate-200/80 bg-[#FAF8F5] space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 text-xs">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-serif text-base font-bold text-slate-900">
                            {mtg.topic}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              mtg.status === 'Completed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {mtg.status}
                          </span>
                        </div>
                        <p className="text-slate-600">
                          Mentor: <strong className="text-slate-800">{mtg.mentorName}</strong> · Attendee(s): {mtg.founderName}
                        </p>
                        <p className="text-slate-500 font-mono text-[11px]">
                          {new Date(mtg.scheduledAt).toLocaleString([], {
                            dateStyle: 'medium',
                            timeStyle: 'short'
                          })}{' '}
                          ({mtg.durationMinutes} min)
                        </p>
                      </div>

                      <div className="shrink-0">
                        {mtg.status === 'Completed' && !mtg.reportSubmitted && isAssigned && (
                          <button
                            onClick={() => openReportModal(mtg)}
                            className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19]"
                          >
                            Submit Report
                          </button>
                        )}
                        {mtg.reportSubmitted && (
                          <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Report Archived
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Report Summary & Advice block */}
                    {report && (
                      <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-3 text-xs">
                        <div>
                          <span className="font-semibold text-slate-800 block text-[11px] uppercase tracking-wider text-[#4A121E]">
                            Session Discussion Summary:
                          </span>
                          <p className="text-slate-700 mt-1 leading-relaxed">
                            {report.meetingSummary}
                          </p>
                        </div>

                        <div>
                          <span className="font-semibold text-slate-800 block text-[11px] uppercase tracking-wider text-[#4A121E]">
                            Strategic Advice Provided:
                          </span>
                          <p className="text-slate-700 mt-1 leading-relaxed">
                            {report.adviceProvided}
                          </p>
                        </div>

                        {report.actionItems.length > 0 && (
                          <div className="pt-2 border-t border-slate-100">
                            <span className="font-semibold text-slate-800 block mb-1">
                              Action Items:
                            </span>
                            <ul className="space-y-1 list-disc list-inside text-slate-600">
                              {report.actionItems.map((ai, idx) => (
                                <li key={idx}>
                                  <span className="font-medium text-slate-800">{ai.task}</span> (Assignee: {ai.assignee}, Due: {ai.dueDate})
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: MSL READINESS */}
      {ventureHistoryTab === 'msl' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-6">
            <div className="pb-3 border-b border-slate-100">
              <h2 className="font-serif text-lg font-bold text-slate-900">
                MSL Readiness & Criterion Verification
              </h2>
              <p className="text-xs text-slate-500">
                Mandatory task checklist: A criterion remains "In Progress" until EVERY mandatory task is approved by Admin.
              </p>
            </div>

            <div className="space-y-6">
              {selectedVenture.mslCriteria.map((crit) => {
                const approvedCount = crit.tasks.filter((t) => t.status === 'Approved').length;
                const totalCount = crit.tasks.length;
                const allApproved = approvedCount === totalCount && totalCount > 0;

                return (
                  <div
                    key={crit.id}
                    className={`border rounded-2xl p-5 space-y-4 ${
                      crit.isVerified
                        ? 'bg-emerald-50/40 border-emerald-200'
                        : 'bg-[#FAF8F5] border-slate-200'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-serif font-bold text-base text-slate-900">
                            {crit.name}
                          </h3>
                          <span className="text-xs text-slate-500 font-mono">
                            — {approvedCount}/{totalCount} tasks approved
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-0.5">{crit.description}</p>
                      </div>

                      <span
                        className={`text-xs font-bold px-3 py-1 rounded-full shrink-0 ${
                          crit.isVerified
                            ? 'bg-emerald-600 text-white'
                            : 'bg-amber-100 text-amber-900 border border-amber-300'
                        }`}
                      >
                        Status: {crit.isVerified ? 'Verified' : 'In Progress'}
                      </span>
                    </div>

                    {/* Tasks checklist */}
                    <div className="bg-white rounded-xl border border-slate-200/80 divide-y divide-slate-100 text-xs">
                      {crit.tasks.map((task) => (
                        <div
                          key={task.id}
                          className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                        >
                          <div className="flex items-start sm:items-center gap-2.5">
                            {task.status === 'Approved' ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5 sm:mt-0" />
                            ) : task.status === 'Under Review' ? (
                              <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5 sm:mt-0" />
                            ) : (
                              <AlertCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5 sm:mt-0" />
                            )}
                            <div>
                              <p className="font-semibold text-slate-900">{task.title}</p>
                              <p className="text-[11px] text-slate-500">
                                Required: {task.requiredMetric} · Current: {task.currentMetric}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            {task.evidenceName && (
                              <button
                                onClick={() =>
                                  openEvidenceModal({
                                    title: task.evidenceName,
                                    adminApprovalStatus: task.status,
                                    verifiedBy: task.verifiedBy
                                  })
                                }
                                className="text-[11px] text-[#4A121E] hover:underline font-medium"
                              >
                                View Evidence
                              </button>
                            )}

                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                task.status === 'Approved'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : task.status === 'Under Review'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {task.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: ACTIVITY TIMELINE */}
      {ventureHistoryTab === 'activity' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-5">
            <div className="pb-3 border-b border-slate-100">
              <h2 className="font-serif text-lg font-bold text-slate-900">
                Venture Activity Timeline
              </h2>
              <p className="text-xs text-slate-500">
                Audited chronological log of milestone advancements, mentor reviews, and evidence approvals
              </p>
            </div>

            <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#EDE8DC]">
              {activities.map((act) => (
                <div key={act.id} className="relative group">
                  {/* Pin marker */}
                  <div className="absolute -left-6 top-1 w-4 h-4 rounded-full bg-white border-2 border-[#4A121E] group-hover:scale-110 transition-transform" />

                  <div className="p-4 rounded-xl bg-[#FAF8F5] border border-slate-200/70 space-y-1.5 text-xs">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px]">
                      <span className="font-bold text-[#4A121E] uppercase tracking-wide">
                        {act.type}
                      </span>
                      <span className="text-slate-400 font-mono">
                        {act.date} at {act.timestamp}
                      </span>
                    </div>

                    <p className="text-slate-800 font-medium">{act.description}</p>

                    <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-200/50">
                      Actor: <span className="text-slate-700 font-semibold">{act.actor}</span> ({act.actorRole})
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
