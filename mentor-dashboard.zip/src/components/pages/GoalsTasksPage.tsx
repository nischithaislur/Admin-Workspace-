import React, { useState } from 'react';
import {
  CheckSquare,
  Plus,
  Filter,
  FileCheck2,
  Clock,
  CheckCircle2,
  AlertCircle,
  Eye,
  Building2,
  Calendar
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';

export const GoalsTasksPage: React.FC = () => {
  const {
    goals,
    ventures,
    openGoalModal,
    openEvidenceModal,
    openVentureHistory
  } = useWorkspace();

  const [statusFilter, setStatusFilter] = useState<'All' | 'In Progress' | 'Completed' | 'Overdue'>('All');
  const [ventureFilter, setVentureFilter] = useState<string>('All');

  const filteredGoals = goals.filter((g) => {
    if (statusFilter !== 'All' && g.status !== statusFilter) return false;
    if (ventureFilter !== 'All' && g.ventureId !== ventureFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#4A121E]">
            <CheckSquare className="w-4 h-4" />
            <span>Milestone Accountability System</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            Goals & Tasks
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            Milestone goals assigned by Admin and authorized faculty mentors. Deliverables are reviewed against incubator validation rubrics.
          </p>
        </div>

        <button
          onClick={() => openGoalModal()}
          className="px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-sm flex items-center gap-1.5 transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Assign New Milestone Goal</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-[#EDE8DC] shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Status filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {(['All', 'In Progress', 'Completed', 'Overdue'] as const).map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                statusFilter === status
                  ? 'bg-[#4A121E] text-white shadow-xs'
                  : 'bg-[#FAF8F5] text-slate-600 hover:bg-slate-100 border border-slate-200/60'
              }`}
            >
              {status}
            </button>
          ))}
        </div>

        {/* Venture dropdown filter */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 whitespace-nowrap font-medium">Venture:</span>
          <select
            value={ventureFilter}
            onChange={(e) => setVentureFilter(e.target.value)}
            className="text-xs p-2 rounded-xl border border-slate-200 bg-[#FAF8F5] focus:bg-white focus:border-[#4A121E] outline-none"
          >
            <option value="All">All Ventures ({ventures.length})</option>
            {ventures.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Tasks Grid / List */}
      <div className="space-y-4">
        {filteredGoals.map((goal) => (
          <div
            key={goal.id}
            className="bg-white rounded-2xl border border-[#EDE8DC] p-5 shadow-xs hover:border-[#4A121E]/30 transition-all space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 text-xs">
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => openVentureHistory(goal.ventureId, 'goals')}
                    className="font-serif text-base font-bold text-slate-900 hover:text-[#4A121E] hover:underline"
                  >
                    {goal.ventureName}
                  </button>
                  <span className="text-slate-300">·</span>
                  <span className="text-xs font-semibold text-slate-700">{goal.title}</span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      goal.status === 'Completed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : goal.status === 'Overdue'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {goal.status}
                  </span>
                </div>
                <p className="text-slate-600 leading-relaxed max-w-3xl">{goal.description}</p>
                <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 pt-1">
                  <span>Assignee: <strong className="text-slate-700">{goal.assignedTo}</strong></span>
                  <span>·</span>
                  <span>Milestone: <strong className="text-slate-700">{goal.milestone}</strong></span>
                  <span>·</span>
                  <span>Assigned by: {goal.assignedBy.name} ({goal.assignedBy.role})</span>
                </div>
              </div>

              <div className="text-right shrink-0 space-y-1">
                <div className="flex items-center gap-1 text-slate-500 font-mono text-xs">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Due {goal.dueDate}</span>
                </div>
                <button
                  onClick={() => openVentureHistory(goal.ventureId, 'goals')}
                  className="text-xs font-semibold text-[#4A121E] hover:underline block"
                >
                  View in Venture History →
                </button>
              </div>
            </div>

            {/* Evidence attachment if submitted */}
            {goal.evidenceSubmitted && (
              <div className="mt-2 p-3.5 rounded-xl bg-[#FAF8F5] border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <FileCheck2 className="w-4 h-4 text-[#4A121E]" />
                    <span className="font-semibold text-slate-900">
                      Deliverable: {goal.evidenceSubmitted.title}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-slate-200 text-slate-700">
                      {goal.evidenceSubmitted.status}
                    </span>
                  </div>
                  {goal.evidenceSubmitted.adminFeedback && (
                    <p className="text-[11px] text-slate-500 italic">
                      Review Note: "{goal.evidenceSubmitted.adminFeedback}"
                    </p>
                  )}
                </div>

                <button
                  onClick={() => openEvidenceModal(goal.evidenceSubmitted)}
                  className="px-3 py-1 rounded-lg text-xs font-semibold text-[#4A121E] bg-white border border-slate-200 hover:bg-[#FAF0F2] flex items-center gap-1.5 shrink-0"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Inspect Evidence</span>
                </button>
              </div>
            )}
          </div>
        ))}

        {filteredGoals.length === 0 && (
          <div className="bg-white rounded-2xl p-12 text-center border border-[#EDE8DC] space-y-2">
            <CheckSquare className="w-10 h-10 text-slate-400 mx-auto" />
            <h2 className="font-serif text-lg font-bold text-slate-900">No tasks found</h2>
            <p className="text-xs text-slate-500">
              No tasks match your chosen filters.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
