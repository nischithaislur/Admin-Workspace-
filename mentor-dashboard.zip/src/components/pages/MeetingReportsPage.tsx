import React from 'react';
import {
  FileText,
  CheckCircle2,
  AlertCircle,
  Clock,
  Star,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Building2
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';

export const MeetingReportsPage: React.FC = () => {
  const {
    meetings,
    reports,
    openReportModal,
    openVentureHistory
  } = useWorkspace();

  const pendingReportMeetings = meetings.filter(
    (m) => m.status === 'Completed' && !m.reportSubmitted
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#4A121E]">
            <FileText className="w-4 h-4" />
            <span>Formal Mentorship Documentation</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            Meeting Reports
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            Submit session summaries, strategic advice, and founder action items. Approved reports link directly into each startup's Venture History.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 bg-white px-3 py-1.5 rounded-xl border border-[#EDE8DC] shadow-xs">
          <span>{reports.length} Reports Submitted</span>
          <span className="text-slate-300">·</span>
          <span className="text-[#4A121E]">{pendingReportMeetings.length} Pending</span>
        </div>
      </div>

      {/* Action Required: Pending Reports List */}
      {pendingReportMeetings.length > 0 && (
        <div className="bg-[#FAF0F2] rounded-2xl p-6 border border-[#F5D0D8] space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-[#4A121E] uppercase tracking-wider">
            <AlertCircle className="w-4 h-4" />
            <span>Action Required: Completed Sessions Awaiting Reports</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pendingReportMeetings.map((mtg) => (
              <div
                key={mtg.id}
                className="bg-white p-4 rounded-xl border border-[#F5D0D8] shadow-xs flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-serif font-bold text-sm text-slate-900">
                      {mtg.ventureName}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-50 text-rose-700">
                      Report Due
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">{mtg.topic}</p>
                  <p className="text-[11px] text-slate-400 mt-1 font-mono">
                    Session Date: {new Date(mtg.scheduledAt).toLocaleDateString()}
                  </p>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    onClick={() => openReportModal(mtg)}
                    className="px-4 py-1.5 rounded-lg text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-xs"
                  >
                    Submit Report
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Submitted Reports Archive */}
      <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-5">
        <div className="pb-3 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="font-serif text-lg font-bold text-slate-900">
              Submitted Mentorship Reports Archive
            </h2>
            <p className="text-xs text-slate-500">
              Approved faculty reports archived into venture records
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {reports.map((report) => (
            <div
              key={report.id}
              className="p-5 rounded-xl border border-slate-200/80 bg-[#FAF8F5] space-y-3.5 hover:bg-white transition-all"
            >
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => openVentureHistory(report.ventureId, 'meetings')}
                      className="font-serif text-base font-bold text-slate-900 hover:text-[#4A121E] hover:underline"
                    >
                      {report.ventureName}
                    </button>
                    <span className="text-slate-300">·</span>
                    <span className="text-slate-600">Session on {report.sessionDate}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Submitted: {new Date(report.submittedAt).toLocaleDateString()} · Duration: {report.durationMinutes} min
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                      report.adminStatus === 'Approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    Admin {report.adminStatus}
                  </span>

                  <button
                    onClick={() => openVentureHistory(report.ventureId, 'meetings')}
                    className="px-3 py-1 rounded-lg text-xs font-semibold text-[#4A121E] bg-[#FAF0F2] hover:bg-[#F5D0D8] border border-[#F5D0D8]"
                  >
                    View in History
                  </button>
                </div>
              </div>

              {/* Summary and Advice */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs bg-white p-4 rounded-xl border border-slate-200">
                <div>
                  <span className="font-semibold text-slate-800 block text-[11px] uppercase tracking-wider text-[#4A121E] mb-1">
                    Meeting Summary:
                  </span>
                  <p className="text-slate-600 leading-relaxed">{report.meetingSummary}</p>
                </div>
                <div>
                  <span className="font-semibold text-slate-800 block text-[11px] uppercase tracking-wider text-[#4A121E] mb-1">
                    Advice & Direction:
                  </span>
                  <p className="text-slate-600 leading-relaxed">{report.adviceProvided}</p>
                </div>
              </div>

              {/* Action items */}
              {report.actionItems.length > 0 && (
                <div className="text-xs pt-1">
                  <span className="font-semibold text-slate-800 block mb-1">
                    Agreed Action Items:
                  </span>
                  <div className="space-y-1">
                    {report.actionItems.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-slate-600">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span className="font-medium text-slate-900">{item.task}</span>
                        <span className="text-[11px] text-slate-400">
                          (Assignee: {item.assignee} · Due: {item.dueDate})
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}

          {reports.length === 0 && (
            <div className="p-8 text-center text-xs text-slate-500">
              No reports submitted yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
