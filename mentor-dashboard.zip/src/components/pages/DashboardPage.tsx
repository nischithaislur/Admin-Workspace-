import React from 'react';
import {
  Calendar,
  FileText,
  Rocket,
  CheckSquare,
  Clock,
  ArrowRight,
  ExternalLink,
  AlertCircle,
  Video,
  ChevronRight,
  Building2,
  Sparkles,
  TrendingUp,
  FileCheck2
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';

export const DashboardPage: React.FC = () => {
  const {
    mentor,
    ventures,
    meetings,
    reports,
    goals,
    setCurrentPage,
    openVentureHistory,
    openReportModal,
    openGoalModal
  } = useWorkspace();

  const assignedVentures = ventures.filter((v) => v.isAssignedToCurrentMentor);
  const upcomingMeetings = meetings.filter(
    (m) => m.status === 'Scheduled' && m.adminApproved
  );
  const pendingReportsMeetings = meetings.filter(
    (m) => m.status === 'Completed' && !m.reportSubmitted
  );
  const tasksInProgress = goals.filter(
    (g) => g.status === 'In Progress' || g.status === 'Under Review'
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Welcome Banner */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#EDE8DC] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#4A121E]">
            <span className="w-2 h-2 rounded-full bg-[#4A121E]" />
            <span>Mesa Startup Hub · Academic Year 2026</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Welcome back, {mentor.name}
          </h1>
          <p className="text-sm text-slate-600 max-w-2xl leading-relaxed">
            Guiding {assignedVentures.length} early-stage founder teams through Customer Discovery, MSL Validation, and Product Architecture milestones.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            onClick={() => setCurrentPage('directory')}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-sm flex items-center gap-2 transition-colors"
          >
            <Rocket className="w-4 h-4" />
            <span>Open Startup Directory</span>
          </button>
          <button
            onClick={() => openGoalModal()}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-[#4A121E] bg-[#FAF0F2] hover:bg-[#F5D0D8] border border-[#F5D0D8] flex items-center gap-2 transition-colors"
          >
            <CheckSquare className="w-4 h-4" />
            <span>Assign Milestone Task</span>
          </button>
        </div>
      </div>

      {/* 4 Stat Cards: Mentorship Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {/* Card 1: Upcoming Meetings */}
        <div
          onClick={() => setCurrentPage('meetings')}
          className="bg-white p-5 rounded-2xl border border-[#EDE8DC] shadow-xs hover:border-[#4A121E]/30 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Upcoming Meetings</span>
            <div className="w-9 h-9 rounded-xl bg-[#FAF0F2] text-[#4A121E] flex items-center justify-center group-hover:scale-105 transition-transform">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-serif text-3xl font-bold text-slate-900 tabular-nums">
              {upcomingMeetings.length}
            </span>
            <span className="text-xs text-slate-500">scheduled</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
            <span>Next: Tomorrow 2:30 PM</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </div>

        {/* Card 2: Reports Due */}
        <div
          onClick={() => setCurrentPage('reports')}
          className="bg-white p-5 rounded-2xl border border-[#EDE8DC] shadow-xs hover:border-[#4A121E]/30 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Reports Due</span>
            <div className="w-9 h-9 rounded-xl bg-[#FAF0F2] text-[#4A121E] flex items-center justify-center group-hover:scale-105 transition-transform">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-serif text-3xl font-bold text-[#4A121E] tabular-nums">
              {pendingReportsMeetings.length}
            </span>
            <span className="text-xs font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full">
              Action Required
            </span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
            <span>Loomly session pending</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </div>

        {/* Card 3: Assigned Ventures */}
        <div
          onClick={() => setCurrentPage('directory')}
          className="bg-white p-5 rounded-2xl border border-[#EDE8DC] shadow-xs hover:border-[#4A121E]/30 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Assigned Ventures</span>
            <div className="w-9 h-9 rounded-xl bg-[#FAF0F2] text-[#4A121E] flex items-center justify-center group-hover:scale-105 transition-transform">
              <Building2 className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-serif text-3xl font-bold text-slate-900 tabular-nums">
              {assignedVentures.length}
            </span>
            <span className="text-xs text-slate-500">incubate teams</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
            <span>ILS · PGP 2026 Batch</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </div>

        {/* Card 4: Student Tasks in Progress */}
        <div
          onClick={() => setCurrentPage('goals')}
          className="bg-white p-5 rounded-2xl border border-[#EDE8DC] shadow-xs hover:border-[#4A121E]/30 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-500">Student Tasks in Progress</span>
            <div className="w-9 h-9 rounded-xl bg-[#FAF0F2] text-[#4A121E] flex items-center justify-center group-hover:scale-105 transition-transform">
              <CheckSquare className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-serif text-3xl font-bold text-slate-900 tabular-nums">
              {tasksInProgress.length}
            </span>
            <span className="text-xs text-slate-500">active items</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
            <span>2 deliverables under review</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </div>
      </div>

      {/* Report Reminder Banner (if any completed meeting lacks report) */}
      {pendingReportsMeetings.length > 0 && (
        <div className="bg-[#FAF0F2] rounded-2xl p-5 border border-[#F5D0D8] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#4A121E] text-white flex items-center justify-center shrink-0">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-[#4A121E] uppercase tracking-wide">
                Report Submission Reminder
              </h2>
              <p className="text-xs text-slate-700 mt-0.5">
                Mentorship meeting with <strong className="text-slate-900">{pendingReportsMeetings[0].ventureName}</strong> completed on{' '}
                {new Date(pendingReportsMeetings[0].scheduledAt).toLocaleDateString()}. Please record the session summary and advice provided.
              </p>
            </div>
          </div>
          <button
            onClick={() => openReportModal(pendingReportsMeetings[0])}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shrink-0 shadow-sm"
          >
            Submit Report Now
          </button>
        </div>
      )}

      {/* 2-Column Grid: Upcoming Meetings & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Upcoming Meetings */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-[#EDE8DC] p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="font-serif text-lg font-bold text-slate-900">
                Upcoming Mentorship Sessions
              </h2>
              <p className="text-xs text-slate-500">
                Approved and scheduled 1-on-1 venture clinics
              </p>
            </div>
            <button
              onClick={() => setCurrentPage('meetings')}
              className="text-xs font-semibold text-[#4A121E] hover:underline flex items-center gap-1"
            >
              <span>View All Meetings</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {upcomingMeetings.slice(0, 3).map((meeting) => (
              <div
                key={meeting.id}
                className="p-4 rounded-xl border border-slate-200/80 bg-[#FAF8F5] hover:bg-white hover:border-[#4A121E]/30 transition-all"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openVentureHistory(meeting.ventureId)}
                        className="font-serif text-sm font-bold text-slate-900 hover:text-[#4A121E] hover:underline"
                      >
                        {meeting.ventureName}
                      </button>
                      <span className="text-[11px] text-slate-400">·</span>
                      <span className="text-xs text-slate-600 font-medium">
                        {meeting.founderName}
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 font-medium line-clamp-1">
                      {meeting.topic}
                    </p>
                    <div className="flex items-center gap-3 text-xs text-slate-500 pt-1">
                      <span className="flex items-center gap-1 font-mono">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        {new Date(meeting.scheduledAt).toLocaleString([], {
                          weekday: 'short',
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                      <span>·</span>
                      <span>{meeting.location || 'Virtual Video Room'}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {meeting.meetingLink && (
                      <a
                        href={meeting.meetingLink}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] flex items-center gap-1.5 shadow-xs"
                      >
                        <Video className="w-3.5 h-3.5" />
                        <span>Join Call</span>
                      </a>
                    )}
                    <button
                      onClick={() => openVentureHistory(meeting.ventureId, 'overview')}
                      className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50"
                    >
                      History
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Col: Recent Venture Activity Feed */}
        <div className="bg-white rounded-2xl border border-[#EDE8DC] p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="font-serif text-lg font-bold text-slate-900">
                Recent Venture Activity
              </h2>
              <p className="text-xs text-slate-500">Live milestones & submissions</p>
            </div>
            <Sparkles className="w-4 h-4 text-[#4A121E]" />
          </div>

          <div className="space-y-3.5">
            <div className="text-xs space-y-3">
              <div className="flex items-start gap-2.5 pb-2.5 border-b border-slate-100">
                <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                  <FileCheck2 className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="text-slate-800 font-medium">
                    <strong className="text-slate-900">CampusCart</strong> submitted "Shrinkage_Audit_March2026.pdf"
                  </p>
                  <span className="text-[10px] text-slate-400">2 hours ago · Ananya Rao</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5 pb-2.5 border-b border-slate-100">
                <div className="w-7 h-7 rounded-lg bg-[#FAF0F2] text-[#4A121E] flex items-center justify-center shrink-0 mt-0.5">
                  <TrendingUp className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="text-slate-800 font-medium">
                    <strong className="text-slate-900">KiranaOS</strong> hit 412 WhatsApp supplier purchase orders
                  </p>
                  <span className="text-[10px] text-slate-400">Yesterday · Arjun Singhania</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5 pb-2.5 border-b border-slate-100">
                <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                  <Calendar className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="text-slate-800 font-medium">
                    <strong className="text-slate-900">AgriLoop</strong> confirmed 45-min strategy session
                  </p>
                  <span className="text-[10px] text-slate-400">2 days ago · Vikram C.</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center shrink-0 mt-0.5">
                  <Building2 className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="text-slate-800 font-medium">
                    <strong className="text-slate-900">MediBridge</strong> CDSCO Class B device clearance verified
                  </p>
                  <span className="text-[10px] text-slate-400">Oct 24, 2026 · Mesa Admin</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
