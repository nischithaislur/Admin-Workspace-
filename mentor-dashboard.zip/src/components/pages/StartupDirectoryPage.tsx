import React, { useState } from 'react';
import {
  Search,
  Filter,
  Building2,
  Users,
  Compass,
  ArrowRight,
  ShieldCheck,
  Lock,
  Sparkles,
  Layers,
  ChevronRight,
  TrendingUp,
  Tag
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { Stage } from '../../types';

export const StartupDirectoryPage: React.FC = () => {
  const { ventures, openVentureHistory, isSimulatingUnassignedMentor } = useWorkspace();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStage, setSelectedStage] = useState<string>('All');
  const [assignmentFilter, setAssignmentFilter] = useState<'All' | 'Assigned'>('All');

  const stages: (Stage | 'All')[] = ['All', 'Discover', 'Validate', 'Build', 'Launch', 'Grow'];

  const filteredVentures = ventures.filter((v) => {
    const isAssigned = isSimulatingUnassignedMentor ? false : v.isAssignedToCurrentMentor;

    if (assignmentFilter === 'Assigned' && !isAssigned) return false;
    if (selectedStage !== 'All' && v.currentStage !== selectedStage) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = v.name.toLowerCase().includes(q);
      const matchIndustry = v.industry.toLowerCase().includes(q);
      const matchFounders = v.founders.some((f) => f.name.toLowerCase().includes(q));
      if (!matchName && !matchIndustry && !matchFounders) return false;
    }

    return true;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#4A121E]">
            <Compass className="w-4 h-4" />
            <span>Mesa Venture Portfolio · ILS PGP 2026</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            Startup Directory
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            Click any venture card to open its complete journey, playbook deliverables, meeting history, and MSL readiness audit.
          </p>
        </div>

        {/* Assigned filter button */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setAssignmentFilter('All')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              assignmentFilter === 'All'
                ? 'bg-[#4A121E] text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            All Ventures ({ventures.length})
          </button>
          <button
            onClick={() => setAssignmentFilter('Assigned')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              assignmentFilter === 'Assigned'
                ? 'bg-[#4A121E] text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            My Assigned ({ventures.filter((v) => (isSimulatingUnassignedMentor ? false : v.isAssignedToCurrentMentor)).length})
          </button>
        </div>
      </div>

      {/* Search & Stage Filter Bar */}
      <div className="bg-white rounded-2xl p-4 border border-[#EDE8DC] shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by venture name, industry, or founder..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none bg-[#FAF8F5]/60 focus:bg-white"
          />
        </div>

        {/* Stage Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          <span className="text-[11px] font-medium text-slate-400 mr-1 hidden sm:inline">Stage:</span>
          {stages.map((stage) => (
            <button
              key={stage}
              onClick={() => setSelectedStage(stage)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                selectedStage === stage
                  ? 'bg-[#FAF0F2] text-[#4A121E] border border-[#F5D0D8] font-bold'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {stage}
            </button>
          ))}
        </div>
      </div>

      {/* Ventures Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredVentures.map((venture) => {
          const isAssigned = isSimulatingUnassignedMentor ? false : venture.isAssignedToCurrentMentor;

          return (
            <div
              key={venture.id}
              onClick={() => openVentureHistory(venture.id, 'overview')}
              className="bg-white rounded-2xl border border-[#EDE8DC] shadow-xs hover:shadow-md hover:border-[#4A121E]/40 transition-all cursor-pointer flex flex-col justify-between group overflow-hidden"
            >
              <div className="p-5 space-y-4">
                {/* Top card bar: Logo + Assignment + Stage */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-[#FAF0F2] text-[#4A121E] font-serif font-bold text-lg flex items-center justify-center border border-[#F5D0D8] group-hover:scale-105 transition-transform shrink-0">
                      {venture.logo}
                    </div>
                    <div>
                      <h2 className="font-serif text-lg font-bold text-slate-900 group-hover:text-[#4A121E] transition-colors leading-tight">
                        {venture.name}
                      </h2>
                      <span className="text-xs text-slate-500 font-medium">{venture.industry}</span>
                    </div>
                  </div>

                  <span
                    className={`text-[11px] font-bold px-2.5 py-1 rounded-full shrink-0 ${
                      venture.currentStage === 'Discover'
                        ? 'bg-amber-50 text-amber-800 border border-amber-200'
                        : venture.currentStage === 'Validate'
                        ? 'bg-blue-50 text-blue-800 border border-blue-200'
                        : venture.currentStage === 'Build'
                        ? 'bg-purple-50 text-purple-800 border border-purple-200'
                        : venture.currentStage === 'Launch'
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        : 'bg-indigo-50 text-indigo-800 border border-indigo-200'
                    }`}
                  >
                    Stage: {venture.currentStage}
                  </span>
                </div>

                {/* Tagline & Description */}
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-slate-800 line-clamp-1">
                    {venture.tagline}
                  </p>
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {venture.description}
                  </p>
                </div>

                {/* MSL Level indicator */}
                <div className="p-2.5 rounded-xl bg-[#FAF8F5] border border-slate-200/70 text-xs">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-500 font-medium">MSL Readiness:</span>
                    <span className="font-semibold text-[#4A121E]">{venture.currentMSL.split('—')[0]}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 font-medium truncate mt-0.5">
                    {venture.currentMSL.split('—')[1] || 'Empirical Validation'}
                  </p>
                </div>

                {/* Founders & Assigned Mentors */}
                <div className="space-y-1 text-xs text-slate-600 pt-1 border-t border-slate-100">
                  <div className="flex items-center gap-1.5 truncate">
                    <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="text-slate-500">Founders:</span>
                    <span className="font-medium text-slate-900 truncate">
                      {venture.founders.map((f) => f.name).join(', ')}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 truncate">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#4A121E] shrink-0" />
                    <span className="text-slate-500">Principal Mentor:</span>
                    <span className="font-medium text-slate-900 truncate">
                      {venture.mentorAssignment.principalMentor.name}
                    </span>
                  </div>
                </div>
              </div>

              {/* Bottom Card Footer Callout */}
              <div className="px-5 py-3 bg-[#FAF8F5] border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#4A121E] group-hover:bg-[#FAF0F2] transition-colors">
                <div className="flex items-center gap-1.5">
                  {isAssigned ? (
                    <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-bold">
                      Assigned Mentor Access
                    </span>
                  ) : (
                    <span className="text-[11px] text-slate-600 bg-slate-200/60 px-2 py-0.5 rounded-full font-medium flex items-center gap-1">
                      <Lock className="w-3 h-3 text-slate-400" />
                      External Faculty View
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  <span>Open Venture History</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredVentures.length === 0 && (
        <div className="bg-white rounded-2xl p-12 text-center border border-[#EDE8DC] space-y-3">
          <Building2 className="w-10 h-10 text-slate-400 mx-auto" />
          <h2 className="font-serif text-lg font-bold text-slate-900">No matching startups found</h2>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search query or reset stage filters to view all ventures in the Mesa ILS PGP 2026 cohort.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedStage('All');
              setAssignmentFilter('All');
            }}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-[#4A121E] bg-[#FAF0F2] hover:bg-[#F5D0D8]"
          >
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
};
