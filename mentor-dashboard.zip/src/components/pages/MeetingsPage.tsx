import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Video,
  CheckCircle2,
  AlertCircle,
  FileText,
  Building2,
  ExternalLink,
  Plus,
  Compass,
  ShieldAlert,
  ChevronRight
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';

export const MeetingsPage: React.FC = () => {
  const {
    meetings,
    openReportModal,
    openVentureHistory,
    mentor
  } = useWorkspace();

  const [activeTab, setActiveTab] = useState<'Upcoming' | 'Completed' | 'All'>('Upcoming');

  const upcomingMeetings = meetings.filter(
    (m) => m.status === 'Scheduled' && m.adminApproved
  );
  const completedMeetings = meetings.filter((m) => m.status === 'Completed');
  const pendingAdminApprovalMeetings = meetings.filter((m) => !m.adminApproved);

  const displayedMeetings =
    activeTab === 'Upcoming'
      ? upcomingMeetings
      : activeTab === 'Completed'
      ? completedMeetings
      : meetings.filter((m) => m.adminApproved);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#4A121E]">
            <Calendar className="w-4 h-4" />
            <span>Mesa Mentorship Office Hours</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            My Mentorship Meetings
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            Admin-approved 1-on-1 venture clinics, live Google Meet sessions, and post-meeting review workflows.
          </p>
        </div>

        {/* Tab Filters */}
        <div className="flex items-center gap-1.5 p-1 bg-white rounded-xl border border-[#EDE8DC] shadow-xs">
          {(['Upcoming', 'Completed', 'All'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === tab
                  ? 'bg-[#4A121E] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab} (
              {tab === 'Upcoming'
                ? upcomingMeetings.length
                : tab === 'Completed'
                ? completedMeetings.length
                : meetings.filter((m) => m.adminApproved).length}
              )
            </button>
          ))}
        </div>
      </div>

      {/* Admin Approval Notice Banner */}
      <div className="bg-[#FAF0F2] rounded-2xl p-4 sm:p-5 border border-[#F5D0D8] flex items-start gap-3.5 text-xs text-slate-700">
        <ShieldAlert className="w-5 h-5 text-[#4A121E] shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-[#4A121E] uppercase tracking-wide">
            Program Scheduling Rule:
          </span>{' '}
          In accordance with Mesa incubation governance, all student meeting requests undergo pre-clearance by the Mesa Academic Cell. Pending student requests remain unconfirmed and invisible to mentors until verified by Admin.
        </div>
      </div>

      {/* Meeting Cards List */}
      <div className="space-y-4">
        {displayedMeetings.map((mtg) => (
          <div
            key={mtg.id}
            className="bg-white rounded-2xl border border-[#EDE8DC] p-5 sm:p-6 shadow-xs hover:border-[#4A121E]/30 transition-all space-y-4"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => openVentureHistory(mtg.ventureId)}
                    className="font-serif text-base sm:text-lg font-bold text-slate-900 hover:text-[#4A121E] hover:underline transition-colors"
                  >
                    {mtg.ventureName}
                  </button>
                  <span className="text-slate-300">·</span>
                  <span className="text-xs font-medium text-slate-600">
                    Founder(s): {mtg.founderName}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                      mtg.status === 'Completed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {mtg.status}
                  </span>
                </div>

                <p className="text-xs sm:text-sm font-semibold text-slate-800">
                  {mtg.topic}
                </p>

                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 pt-1">
                  <span className="flex items-center gap-1.5 font-mono">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    {new Date(mtg.scheduledAt).toLocaleString([], {
                      weekday: 'short',
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}{' '}
                    ({mtg.durationMinutes} min)
                  </span>
                  <span>·</span>
                  <span>{mtg.location || 'Virtual Video Room'}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                {mtg.status === 'Scheduled' && mtg.meetingLink && (
                  <a
                    href={mtg.meetingLink}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] flex items-center gap-1.5 shadow-xs transition-colors"
                  >
                    <Video className="w-4 h-4" />
                    <span>Join Video Session</span>
                  </a>
                )}

                {mtg.status === 'Completed' && !mtg.reportSubmitted && (
                  <button
                    onClick={() => openReportModal(mtg)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-xs flex items-center gap-1.5"
                  >
                    <FileText className="w-4 h-4" />
                    <span>Submit Report</span>
                  </button>
                )}

                {mtg.reportSubmitted && (
                  <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Report Filed</span>
                  </span>
                )}

                <button
                  onClick={() => openVentureHistory(mtg.ventureId, 'overview')}
                  className="px-3.5 py-2 rounded-xl text-xs font-medium text-slate-700 bg-[#FAF8F5] hover:bg-slate-100 border border-slate-200"
                >
                  Venture History
                </button>
              </div>
            </div>
          </div>
        ))}

        {displayedMeetings.length === 0 && (
          <div className="bg-white rounded-2xl p-12 text-center border border-[#EDE8DC] space-y-3">
            <Calendar className="w-10 h-10 text-slate-400 mx-auto" />
            <h2 className="font-serif text-lg font-bold text-slate-900">
              No meetings found
            </h2>
            <p className="text-xs text-slate-500">
              No sessions found in the selected tab.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
