import React, { useState, useEffect } from 'react';
import {
  Clock,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Shield,
  ShieldCheck,
  CalendarX,
  Sparkles,
  Info,
  ChevronRight,
  Database,
  ArrowRight,
  RotateCcw
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { AvailabilitySlot, BlackoutDate, DayOfWeek } from '../../types';

export const AvailabilityPage: React.FC = () => {
  const {
    availability,
    blackoutDates,
    saveAvailabilityToSupabase,
    mentor
  } = useWorkspace();

  // Local state for slots and blackout dates to allow editing before saving
  const [slots, setSlots] = useState<AvailabilitySlot[]>(availability);
  const [blackouts, setBlackouts] = useState<BlackoutDate[]>(blackoutDates);

  // Form state for adding / editing a slot
  const [selectedDay, setSelectedDay] = useState<DayOfWeek>('Monday');
  const [startTime, setStartTime] = useState<string>('09:00');
  const [endTime, setEndTime] = useState<string>('11:00');
  const [editingSlotId, setEditingSlotId] = useState<string | null>(null);
  const [slotError, setSlotError] = useState<string>('');

  // Form state for adding blackout dates
  const [blackoutDateInput, setBlackoutDateInput] = useState<string>('');
  const [blackoutReasonInput, setBlackoutReasonInput] = useState<string>('');
  const [blackoutError, setBlackoutError] = useState<string>('');

  // Save feedback state
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [saveTimestamp, setSaveTimestamp] = useState<string>('');
  const [isDirty, setIsDirty] = useState<boolean>(false);

  // Sync state whenever context availability/blackout dates change externally
  useEffect(() => {
    setSlots(availability);
  }, [availability]);

  useEffect(() => {
    setBlackouts(blackoutDates);
  }, [blackoutDates]);

  const daysOfWeek: DayOfWeek[] = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
  ];

  // Utility: Convert 24h "HH:mm" to 12h "h:mm AM/PM"
  const formatTo12Hour = (time24: string): string => {
    if (!time24) return '';
    const [hoursStr, minsStr] = time24.split(':');
    let hours = parseInt(hoursStr, 10);
    const mins = minsStr || '00';
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    if (hours === 0) hours = 12;
    return `${hours}:${mins} ${ampm}`;
  };

  // Utility: Convert "HH:mm" to total minutes from midnight for mathematical comparison
  const timeToMinutes = (time24: string): number => {
    const [h, m] = time24.split(':').map((x) => parseInt(x, 10));
    return h * 60 + (m || 0);
  };

  // Calculate duration string (e.g., "2 hrs" or "1 hr 30 mins")
  const calculateDuration = (start: string, end: string): string => {
    const diff = timeToMinutes(end) - timeToMinutes(start);
    if (diff <= 0) return 'Invalid';
    const h = Math.floor(diff / 60);
    const m = diff % 60;
    if (h > 0 && m > 0) return `${h} hr ${m} min`;
    if (h > 0) return `${h} hr${h > 1 ? 's' : ''}`;
    return `${m} mins`;
  };

  // Validation function: Prevents invalid times and overlapping slots on the same day
  const validateSlotTimes = (
    day: DayOfWeek,
    start: string,
    end: string,
    excludeId?: string | null
  ): string | null => {
    if (!start || !end) {
      return 'Please specify both a start time and an end time.';
    }

    const startMins = timeToMinutes(start);
    const endMins = timeToMinutes(end);

    if (startMins >= endMins) {
      return 'Start time must be strictly earlier than end time.';
    }

    if (endMins - startMins < 30) {
      return 'Each availability slot must be at least 30 minutes in duration.';
    }

    // Overlap detection across existing slots for this day
    const daySlots = slots.filter(
      (s) => s.dayOfWeek === day && (excludeId ? s.id !== excludeId : true)
    );

    for (const existing of daySlots) {
      const existingStart = timeToMinutes(existing.startTime);
      const existingEnd = timeToMinutes(existing.endTime);

      // Overlap formula: max(start1, start2) < min(end1, end2)
      if (Math.max(startMins, existingStart) < Math.min(endMins, existingEnd)) {
        return `Overlap detected: This slot conflicts with your existing ${formatTo12Hour(
          existing.startTime
        )} – ${formatTo12Hour(existing.endTime)} slot on ${day}.`;
      }
    }

    return null;
  };

  // Handle Add or Update Slot
  const handleSlotFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSlotError('');

    const error = validateSlotTimes(selectedDay, startTime, endTime, editingSlotId);
    if (error) {
      setSlotError(error);
      return;
    }

    if (editingSlotId) {
      // Update existing slot
      setSlots((prev) =>
        prev.map((s) =>
          s.id === editingSlotId
            ? {
                ...s,
                dayOfWeek: selectedDay,
                startTime,
                endTime,
                isActive: true
              }
            : s
        )
      );
      setEditingSlotId(null);
    } else {
      // Add new slot
      const newSlot: AvailabilitySlot = {
        id: `av-${selectedDay.toLowerCase().slice(0, 3)}-${Date.now()}`,
        mentorId: mentor.id,
        dayOfWeek: selectedDay,
        startTime,
        endTime,
        slotDurationMinutes: mentor.preferredMeetingLength || 45,
        isActive: true
      };
      setSlots((prev) => [...prev, newSlot]);
    }

    setIsDirty(true);
    setIsSaved(false);

    // Reset default next slot recommendation (e.g. 2 hours after or default)
    setStartTime('14:00');
    setEndTime('16:00');
  };

  // Start editing an existing slot
  const handleStartEdit = (slot: AvailabilitySlot) => {
    setEditingSlotId(slot.id);
    setSelectedDay(slot.dayOfWeek);
    setStartTime(slot.startTime);
    setEndTime(slot.endTime);
    setSlotError('');
    // Scroll smoothly to form if needed
    window.scrollTo({ top: 180, behavior: 'smooth' });
  };

  const handleCancelEdit = () => {
    setEditingSlotId(null);
    setStartTime('09:00');
    setEndTime('11:00');
    setSlotError('');
  };

  // Remove individual slot
  const handleRemoveSlot = (id: string) => {
    setSlots((prev) => prev.filter((s) => s.id !== id));
    if (editingSlotId === id) {
      handleCancelEdit();
    }
    setIsDirty(true);
    setIsSaved(false);
  };

  // Add Blackout Date
  const handleAddBlackout = (e: React.FormEvent) => {
    e.preventDefault();
    setBlackoutError('');

    if (!blackoutDateInput) {
      setBlackoutError('Please select a specific date to mark unavailable.');
      return;
    }

    if (blackouts.some((b) => b.date === blackoutDateInput)) {
      setBlackoutError('This specific date is already marked as unavailable.');
      return;
    }

    const newBo: BlackoutDate = {
      id: `bo-${Date.now()}`,
      mentorId: mentor.id,
      date: blackoutDateInput,
      reason: blackoutReasonInput.trim() || 'Unavailable'
    };

    setBlackouts((prev) => [...prev, newBo]);
    setBlackoutDateInput('');
    setBlackoutReasonInput('');
    setIsDirty(true);
    setIsSaved(false);
  };

  const handleRemoveBlackout = (id: string) => {
    setBlackouts((prev) => prev.filter((b) => b.id !== id));
    setIsDirty(true);
    setIsSaved(false);
  };

  // Save to Supabase (and local persistence)
  const handleSaveToSupabase = () => {
    const success = saveAvailabilityToSupabase(slots, blackouts);
    if (success) {
      setIsSaved(true);
      setIsDirty(false);
      setSaveTimestamp(
        new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      );
      setTimeout(() => setIsSaved(false), 5000);
    }
  };

  // Calculate total advising capacity
  const totalWeeklyMinutes = slots.reduce((acc, s) => {
    return acc + (timeToMinutes(s.endTime) - timeToMinutes(s.startTime));
  }, 0);
  const totalWeeklyHours = (totalWeeklyMinutes / 60).toFixed(1);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#4A121E]">
            <Clock className="w-4 h-4" />
            <span>Mesa Mentorship Scheduling Engine · ILS PGP 2026</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            My Availability
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            Set multiple recurring slots per day and mark blackout dates. Admin schedules founder sessions within your configured windows.
          </p>
        </div>

        {/* Top Action Bar: Save Availability to Supabase */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleSaveToSupabase}
            className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-sm flex items-center gap-2 transition-all shrink-0 cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Save Availability</span>
            {isDirty && (
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" title="Unsaved changes" />
            )}
          </button>
        </div>
      </div>

      {/* Success Notification Banner */}
      {isSaved && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-between gap-3 animate-in fade-in duration-200 shadow-xs">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <p className="font-bold">
                Availability successfully saved to Supabase!
              </p>
              <p className="text-[11px] text-emerald-800">
                Synchronized with the Mesa Admin Scheduling Engine at {saveTimestamp}. Open slots are now visible to the Incubation Desk.
              </p>
            </div>
          </div>
          <span className="text-[10px] font-mono font-semibold px-2.5 py-1 rounded-full bg-white text-emerald-800 border border-emerald-200 shrink-0">
            Supabase DB Synced
          </span>
        </div>
      )}

      {/* Governance Notice Banner */}
      <div className="bg-[#FAF0F2] rounded-2xl p-4 sm:p-5 border border-[#F5D0D8] text-xs text-slate-700 space-y-1">
        <div className="flex items-center gap-2 text-[#4A121E] font-bold uppercase tracking-wider text-[11px]">
          <Shield className="w-4 h-4" />
          <span>Mesa Governance & Scheduling Policy (ILS · PGP 2026)</span>
        </div>
        <p className="leading-relaxed text-slate-700">
          <strong>Only Admin can confirm or reschedule meetings:</strong> Updating your availability defines the open office hour windows within which the Mesa Incubation Cell can book student founder clinics. Changing your availability will <strong>never</strong> automatically approve, reschedule, or cancel existing confirmed meetings.
        </p>
      </div>

      {/* Main 2-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* LEFT 2 COLUMNS: Add Slot Form & Grouped Day Slots */}
        <div className="lg:col-span-2 space-y-6">
          {/* Section 1: Add / Edit Availability Slot Form */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#EDE8DC] shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#FAF0F2] text-[#4A121E] flex items-center justify-center font-bold">
                  {editingSlotId ? <Edit2 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                </div>
                <div>
                  <h2 className="font-serif text-base font-bold text-slate-900">
                    {editingSlotId ? 'Edit Availability Slot' : 'Add Availability Slot'}
                  </h2>
                  <p className="text-xs text-slate-500">
                    {editingSlotId
                      ? 'Modify this specific slot without altering other slots on that day'
                      : 'Add one or more availability windows on any day of the week'}
                  </p>
                </div>
              </div>

              {editingSlotId && (
                <button
                  type="button"
                  onClick={handleCancelEdit}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Cancel Edit</span>
                </button>
              )}
            </div>

            {/* Inline Error Message */}
            {slotError && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                <span>{slotError}</span>
              </div>
            )}

            {/* Form Inputs: Dropdown + Start Picker + End Picker + Button */}
            <form onSubmit={handleSlotFormSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                {/* 1. Day of the Week Dropdown */}
                <div>
                  <label className="block text-xs font-semibold text-slate-900 mb-1">
                    Day of the Week
                  </label>
                  <select
                    value={selectedDay}
                    onChange={(e) => {
                      setSelectedDay(e.target.value as DayOfWeek);
                      setSlotError('');
                    }}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none bg-[#FAF8F5]/50 focus:bg-white font-medium text-slate-800"
                    required
                  >
                    {daysOfWeek.map((day) => {
                      const count = slots.filter((s) => s.dayOfWeek === day).length;
                      return (
                        <option key={day} value={day}>
                          {day} {count > 0 ? `(${count} slot${count > 1 ? 's' : ''})` : ''}
                        </option>
                      );
                    })}
                  </select>
                </div>

                {/* 2. Start Time Picker */}
                <div>
                  <label className="block text-xs font-semibold text-slate-900 mb-1">
                    Start Time
                  </label>
                  <input
                    type="time"
                    value={startTime}
                    onChange={(e) => {
                      setStartTime(e.target.value);
                      setSlotError('');
                    }}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none bg-[#FAF8F5]/50 focus:bg-white font-mono text-slate-800"
                    required
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    {formatTo12Hour(startTime)}
                  </span>
                </div>

                {/* 3. End Time Picker */}
                <div>
                  <label className="block text-xs font-semibold text-slate-900 mb-1">
                    End Time
                  </label>
                  <input
                    type="time"
                    value={endTime}
                    onChange={(e) => {
                      setEndTime(e.target.value);
                      setSlotError('');
                    }}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none bg-[#FAF8F5]/50 focus:bg-white font-mono text-slate-800"
                    required
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    {formatTo12Hour(endTime)}
                  </span>
                </div>
              </div>

              {/* Action row with live duration preview and submit button */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-slate-100">
                <div className="text-xs text-slate-600 flex items-center gap-2">
                  <span className="font-semibold text-slate-700">Preview:</span>
                  <span className="font-mono text-slate-900 font-bold">
                    {selectedDay} · {formatTo12Hour(startTime)} – {formatTo12Hour(endTime)}
                  </span>
                  <span className="text-slate-400">·</span>
                  <span className="text-[#4A121E] font-medium">
                    ({calculateDuration(startTime, endTime)})
                  </span>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  {editingSlotId && (
                    <button
                      type="button"
                      onClick={handleCancelEdit}
                      className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 hover:bg-slate-100 border border-slate-200"
                    >
                      Cancel
                    </button>
                  )}
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {editingSlotId ? <CheckCircle2 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                    <span>{editingSlotId ? 'Update Slot' : 'Add Slot'}</span>
                  </button>
                </div>
              </div>
            </form>
          </div>

          {/* Section 2: Display All Added Slots Grouped By Day */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#EDE8DC] shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="font-serif text-lg font-bold text-slate-900">
                  Weekly Recurring Availability
                </h2>
                <p className="text-xs text-slate-500">
                  All active time slots grouped by day of the week
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-600 font-medium">
                  Total: <strong className="text-slate-900">{slots.length} slots</strong> ({totalWeeklyHours} hrs/week)
                </span>
              </div>
            </div>

            {/* Days Grouped Accordion / List */}
            <div className="space-y-4">
              {daysOfWeek.map((day) => {
                const daySlots = slots
                  .filter((s) => s.dayOfWeek === day)
                  .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

                return (
                  <div
                    key={day}
                    className="border border-slate-200/80 rounded-xl overflow-hidden bg-[#FAF8F5]/40"
                  >
                    {/* Day Header */}
                    <div className="px-4 py-3 bg-[#FAF8F5] border-b border-slate-200/70 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <span className="font-serif font-bold text-slate-900 text-sm">
                          {day}
                        </span>
                        {daySlots.length > 0 ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#FAF0F2] text-[#4A121E] border border-[#F5D0D8]">
                            {daySlots.length} slot{daySlots.length > 1 ? 's' : ''}
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400 italic">
                            No slots configured
                          </span>
                        )}
                      </div>

                      {/* Quick Add Shortcut for this day */}
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedDay(day);
                          setEditingSlotId(null);
                          setSlotError('');
                          window.scrollTo({ top: 180, behavior: 'smooth' });
                        }}
                        className="text-[11px] font-semibold text-[#4A121E] hover:underline flex items-center gap-1"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Add slot for {day}</span>
                      </button>
                    </div>

                    {/* Day's Slots List */}
                    {daySlots.length > 0 ? (
                      <div className="p-3 divide-y divide-slate-100 bg-white">
                        {daySlots.map((slot) => {
                          const isBeingEdited = editingSlotId === slot.id;

                          return (
                            <div
                              key={slot.id}
                              className={`py-2.5 px-3 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs transition-colors ${
                                isBeingEdited
                                  ? 'bg-[#FAF0F2] border border-[#F5D0D8]'
                                  : 'hover:bg-[#FAF8F5]'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <div className="w-2 h-2 rounded-full bg-[#4A121E]" />
                                <div className="flex items-center gap-2">
                                  <span className="font-mono font-bold text-slate-900 text-sm">
                                    {formatTo12Hour(slot.startTime)} – {formatTo12Hour(slot.endTime)}
                                  </span>
                                  <span className="text-[11px] text-slate-500 font-medium">
                                    ({calculateDuration(slot.startTime, slot.endTime)})
                                  </span>
                                </div>
                              </div>

                              {/* Edit | Remove Action Buttons */}
                              <div className="flex items-center gap-3 self-end sm:self-auto">
                                <button
                                  type="button"
                                  onClick={() => handleStartEdit(slot)}
                                  className={`text-xs font-semibold flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors ${
                                    isBeingEdited
                                      ? 'bg-[#4A121E] text-white'
                                      : 'text-slate-600 hover:text-[#4A121E] hover:bg-slate-100'
                                  }`}
                                  title="Edit this slot's start or end time"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                  <span>{isBeingEdited ? 'Editing' : 'Edit'}</span>
                                </button>

                                <span className="text-slate-300">|</span>

                                <button
                                  type="button"
                                  onClick={() => handleRemoveSlot(slot.id)}
                                  className="text-xs font-semibold text-rose-600 hover:text-rose-800 hover:bg-rose-50 px-2.5 py-1 rounded-md flex items-center gap-1 transition-colors"
                                  title="Remove this slot"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>Remove</span>
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="p-4 text-center text-xs text-slate-400 bg-white">
                        Unavailable on {day}. No time slots assigned.
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Blackout Calendar & Admin Scheduling Preview */}
        <div className="space-y-6">
          {/* Section 3: Blackout Dates (Mark Specific Dates Unavailable) */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#EDE8DC] shadow-xs space-y-4">
            <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
              <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-800 flex items-center justify-center font-bold">
                <CalendarX className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-serif text-sm font-bold text-slate-900">
                  Unavailable Specific Dates
                </h3>
                <p className="text-[11px] text-slate-500">
                  Override weekly schedule for travel, exams, or leave
                </p>
              </div>
            </div>

            {blackoutError && (
              <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{blackoutError}</span>
              </div>
            )}

            {/* Form to add Blackout Date */}
            <form onSubmit={handleAddBlackout} className="space-y-3 bg-[#FAF8F5] p-3.5 rounded-xl border border-slate-200/70">
              <div>
                <label className="block text-[11px] font-semibold text-slate-800 mb-1">
                  Select Unavailable Date
                </label>
                <input
                  type="date"
                  value={blackoutDateInput}
                  onChange={(e) => {
                    setBlackoutDateInput(e.target.value);
                    setBlackoutError('');
                  }}
                  className="w-full text-xs p-2 rounded-lg border border-slate-200 bg-white focus:border-[#4A121E] outline-none font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-800 mb-1">
                  Reason / Event (Optional)
                </label>
                <input
                  type="text"
                  value={blackoutReasonInput}
                  onChange={(e) => setBlackoutReasonInput(e.target.value)}
                  placeholder="e.g. Travel, Conference, Board Meeting"
                  className="w-full text-xs p-2 rounded-lg border border-slate-200 bg-white focus:border-[#4A121E] outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 rounded-xl text-xs font-semibold text-[#4A121E] bg-[#FAF0F2] hover:bg-[#F5D0D8] border border-[#F5D0D8] transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <CalendarX className="w-3.5 h-3.5" />
                <span>Mark Date Unavailable</span>
              </button>
            </form>

            {/* List of Marked Blackout Dates */}
            <div className="space-y-2">
              <span className="text-[11px] font-bold uppercase text-slate-400 tracking-wider">
                Active Blackout Overrides ({blackouts.length})
              </span>

              {blackouts.length > 0 ? (
                <div className="space-y-2 max-h-56 overflow-y-auto">
                  {blackouts.map((bo) => (
                    <div
                      key={bo.id}
                      className="p-2.5 rounded-xl border border-slate-200/80 bg-white flex items-center justify-between gap-2 text-xs"
                    >
                      <div className="space-y-0.5">
                        <span className="font-mono font-bold text-slate-900 block">
                          {new Date(bo.date).toLocaleDateString('en-US', {
                            weekday: 'short',
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric'
                          })}
                        </span>
                        <span className="text-[11px] text-slate-500 italic block">
                          {bo.reason}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveBlackout(bo.id)}
                        className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                        title="Remove blackout date"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic">
                  No upcoming blackout dates registered.
                </p>
              )}
            </div>
          </div>

          {/* Section 4: Admin Scheduling Engine Live Preview */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-[#EDE8DC] shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-[#4A121E]" />
                <h3 className="font-serif text-sm font-bold text-slate-900">
                  Admin Scheduling Preview
                </h3>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                Live Synced
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              This preview shows how the Mesa Academic Cell views your availability when assigning and confirming 1-on-1 venture sessions:
            </p>

            <div className="p-3 bg-[#FAF8F5] rounded-xl border border-slate-200 text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Mentor:</span>
                <span className="font-semibold text-slate-900">{mentor.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Weekly Available Windows:</span>
                <span className="font-bold text-slate-900">{slots.length} time windows</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Weekly Advising Capacity:</span>
                <span className="font-bold text-[#4A121E]">{totalWeeklyHours} hours</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Excluded Blackout Dates:</span>
                <span className="font-medium text-slate-800">{blackouts.length} dates</span>
              </div>
            </div>

            <div className="text-[11px] text-slate-500 p-2.5 bg-slate-50 rounded-lg border border-slate-100 flex items-start gap-1.5">
              <Info className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
              <span>
                Students request session topics through their portal; Mesa Admin filters matching mentors using this live availability matrix.
              </span>
            </div>
          </div>

          {/* Bottom Save Availability Action */}
          <div className="bg-white rounded-2xl p-5 border border-[#EDE8DC] shadow-xs text-center space-y-3">
            <p className="text-xs text-slate-600">
              {isDirty
                ? 'You have unsaved changes in your availability schedule.'
                : 'All current changes are synchronized with Supabase.'}
            </p>
            <button
              onClick={handleSaveToSupabase}
              className="w-full py-2.5 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Save Availability to Supabase</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
