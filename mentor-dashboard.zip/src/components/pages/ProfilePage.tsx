import React, { useState } from 'react';
import {
  User,
  ShieldCheck,
  Award,
  Mail,
  Phone,
  BookOpen,
  CheckCircle2,
  Sparkles,
  ExternalLink,
  Plus,
  X
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';

export const ProfilePage: React.FC = () => {
  const { mentor } = useWorkspace();
  const [bio, setBio] = useState(mentor.bio);
  const [phone, setPhone] = useState(mentor.phone);
  const [email, setEmail] = useState(mentor.email);
  const [expertise, setExpertise] = useState<string[]>(mentor.areasOfExpertise);
  const [newTag, setNewTag] = useState('');
  const [isSaved, setIsSaved] = useState(false);

  const handleAddTag = () => {
    if (newTag.trim() && !expertise.includes(newTag.trim())) {
      setExpertise([...expertise, newTag.trim()]);
      setNewTag('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setExpertise(expertise.filter((t) => t !== tag));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#4A121E]">
            <User className="w-4 h-4" />
            <span>Faculty & Mentor Dossier</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            My Mentor Profile
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            Manage your incubator bio, venture advising domains, and public credentials for ILS PGP 2026 students.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-sm flex items-center gap-2 transition-colors self-start sm:self-auto"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Save Changes</span>
        </button>
      </div>

      {isSaved && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Profile updated successfully! Updated credentials reflected in the Mesa Startup Directory.</span>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Identity & Incubation Stats */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs text-center space-y-4">
            <div className="w-24 h-24 rounded-full bg-[#4A121E] text-white font-serif font-bold text-2xl flex items-center justify-center mx-auto shadow-md ring-4 ring-[#FAF0F2]">
              {mentor.name
                .split(' ')
                .map((n) => n[0])
                .join('')}
            </div>

            <div className="space-y-1">
              <h2 className="font-serif text-xl font-bold text-slate-900">{mentor.name}</h2>
              <p className="text-xs font-semibold text-[#4A121E]">{mentor.title}</p>
              <span className="inline-block text-[11px] font-bold px-3 py-0.5 rounded-full bg-[#FAF0F2] text-[#4A121E] border border-[#F5D0D8]">
                {mentor.cohort}
              </span>
            </div>

            <div className="pt-4 border-t border-slate-100 space-y-2 text-xs text-left text-slate-600">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="truncate">{email}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{phone}</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="text-emerald-800 font-semibold">Verified Mesa Faculty</span>
              </div>
            </div>
          </div>

          {/* Mentorship Impact KPIs */}
          <div className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-3">
            <h3 className="font-serif text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
              Mentorship Track Record (2026 Batch)
            </h3>
            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Total Sessions Completed:</span>
                <span className="font-bold text-slate-900 tabular-nums font-mono">
                  {mentor.totalSessionsCompleted} sessions
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Mentored Clinical Hours:</span>
                <span className="font-bold text-slate-900 tabular-nums font-mono">
                  {mentor.totalHoursMentored} hrs
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Student Satisfaction Rating:</span>
                <span className="font-bold text-amber-700 tabular-nums font-mono">
                  ★ {mentor.studentSatisfactionRating} / 5.00
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Primary Assigned Ventures:</span>
                <span className="font-bold text-[#4A121E] tabular-nums font-mono">
                  {mentor.activeVenturesCount} startups
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right 2 Columns: Editable Dossier Form */}
        <div className="lg:col-span-2 space-y-6">
          <form onSubmit={handleSave} className="bg-white rounded-2xl p-6 border border-[#EDE8DC] shadow-xs space-y-5">
            <h2 className="font-serif text-lg font-bold text-slate-900 pb-2 border-b border-slate-100">
              Advisor Profile & Advisory Scope
            </h2>

            <div>
              <label className="block text-xs font-semibold text-slate-900 mb-1">
                Executive Biography & Industry Background
              </label>
              <textarea
                rows={5}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full text-xs p-3.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none leading-relaxed"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Shared with founders before initial problem discovery calls and MSL milestone reviews.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-900 mb-1">
                  Institutional Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-900 mb-1">
                  Contact Phone
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none font-mono"
                />
              </div>
            </div>

            {/* Areas of Expertise Tags */}
            <div>
              <label className="block text-xs font-semibold text-slate-900 mb-1.5">
                Core Mentorship Advisory Domains
              </label>
              <div className="flex flex-wrap gap-2 mb-3">
                {expertise.map((tag) => (
                  <span
                    key={tag}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FAF0F2] text-[#4A121E] text-xs font-semibold border border-[#F5D0D8]"
                  >
                    <span>{tag}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="hover:text-red-700 rounded-full"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-2 max-w-sm">
                <input
                  type="text"
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  placeholder="e.g. CleanTech, DeepTech, B2B Sales..."
                  className="flex-1 text-xs p-2 rounded-xl border border-slate-200 focus:border-[#4A121E] outline-none"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddTag();
                    }
                  }}
                />
                <button
                  type="button"
                  onClick={handleAddTag}
                  className="px-3 py-2 rounded-xl text-xs font-semibold text-[#4A121E] bg-[#FAF0F2] hover:bg-[#F5D0D8] border border-[#F5D0D8]"
                >
                  Add Domain
                </button>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-sm"
              >
                Save Profile Dossier
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
