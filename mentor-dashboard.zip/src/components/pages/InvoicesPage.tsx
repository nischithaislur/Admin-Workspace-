import React, { useState } from 'react';
import {
  Receipt,
  Plus,
  CheckCircle2,
  Clock,
  Download,
  AlertCircle,
  FileCheck2,
  Shield,
  Building2
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { CreateInvoiceModal } from '../modals/CreateInvoiceModal';

export const InvoicesPage: React.FC = () => {
  const { invoices, mentor, meetings, reports } = useWorkspace();
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  const [selectedInvoiceForView, setSelectedInvoiceForView] = useState<string | null>(null);

  // Eligible count
  const eligibleMeetingsCount = meetings.filter((m) => {
    if (m.status !== 'Completed') return false;
    const hasReport = reports.some((r) => r.meetingId === m.id);
    const alreadyInvoiced = invoices.some((inv) => inv.meetingId === m.id);
    return hasReport && !alreadyInvoiced;
  }).length;

  const totalEarnings = invoices
    .filter((inv) => inv.status === 'Paid')
    .reduce((sum, inv) => sum + inv.totalAmount, 0);

  const pendingDisbursement = invoices
    .filter((inv) => inv.status === 'Submitted' || inv.status === 'Approved')
    .reduce((sum, inv) => sum + inv.totalAmount, 0);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#4A121E]">
            <Receipt className="w-4 h-4" />
            <span>Mesa Incubation Cell · Faculty Billing</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            Mentorship Invoices & Honorarium
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            Institutional honorarium disbursements under the one-meeting-one-invoice protocol.
          </p>
        </div>

        <button
          onClick={() => setIsInvoiceModalOpen(true)}
          className="px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#4A121E] hover:bg-[#3D0F19] shadow-sm flex items-center gap-2 transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Generate Session Invoice</span>
          {eligibleMeetingsCount > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-white text-[#4A121E] text-[10px] font-bold">
              {eligibleMeetingsCount} eligible
            </span>
          )}
        </button>
      </div>

      {/* Financial Summary Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-white p-5 rounded-2xl border border-[#EDE8DC] shadow-xs space-y-1">
          <span className="text-xs font-medium text-slate-500">Disbursed (Paid)</span>
          <p className="font-serif text-2xl sm:text-3xl font-bold text-emerald-800 tabular-nums">
            ₹{totalEarnings.toLocaleString()}
          </p>
          <p className="text-[11px] text-slate-400">Direct NEFT to registered account</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-[#EDE8DC] shadow-xs space-y-1">
          <span className="text-xs font-medium text-slate-500">Pending Academic Clearance</span>
          <p className="font-serif text-2xl sm:text-3xl font-bold text-[#4A121E] tabular-nums">
            ₹{pendingDisbursement.toLocaleString()}
          </p>
          <p className="text-[11px] text-slate-400">Under review by Mesa Finance Cell</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-[#EDE8DC] shadow-xs space-y-1">
          <span className="text-xs font-medium text-slate-500">Eligible Unbilled Sessions</span>
          <p className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
            {eligibleMeetingsCount}
          </p>
          <p className="text-[11px] text-slate-400">Completed sessions with approved reports</p>
        </div>
      </div>

      {/* Protocol Banner */}
      <div className="bg-[#FAF8F5] rounded-2xl p-4 sm:p-5 border border-slate-200 text-xs text-slate-700 space-y-1">
        <p className="font-semibold text-slate-900">
          Mesa Startup Hub Invoicing Governance (ILS · PGP 2026):
        </p>
        <p className="leading-relaxed text-slate-600">
          • <strong className="text-slate-800">One-Meeting-One-Invoice:</strong> Each invoice is tied to an individual verified 45-minute clinical session ID. Duplicate claims are prohibited by system constraint.
          <br />
          • <strong className="text-slate-800">Report Prerequisite:</strong> An invoice may only be generated after the mentor has filed a comprehensive session report and received admin verification.
          <br />
          • <strong className="text-slate-800">Program Honorarium:</strong> Standard institutional mentorship honorarium is ₹3,500 + 18% GST (Total ₹4,130) per verified 45-minute session.
        </p>
      </div>

      {/* Invoices Table */}
      <div className="bg-white rounded-2xl border border-[#EDE8DC] shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="font-serif text-base sm:text-lg font-bold text-slate-900">
              Invoice History & Settlement Registry
            </h2>
            <p className="text-xs text-slate-500">Audited records of all submitted session claims</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#FAF8F5] text-slate-500 font-semibold border-b border-slate-200/80">
              <tr>
                <th className="py-3 px-4">Invoice #</th>
                <th className="py-3 px-4">Venture</th>
                <th className="py-3 px-4">Session Topic</th>
                <th className="py-3 px-4">Session Date</th>
                <th className="py-3 px-4 text-right">Amount (incl. GST)</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-[#FAF8F5]/80 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                    {inv.invoiceNumber}
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-[#4A121E]">
                    {inv.ventureName}
                  </td>
                  <td className="py-3.5 px-4 text-slate-700 max-w-xs truncate">
                    {inv.meetingTopic}
                  </td>
                  <td className="py-3.5 px-4 text-slate-500 font-mono">
                    {inv.meetingDate}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900">
                    ₹{inv.totalAmount.toLocaleString()}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                        inv.status === 'Paid'
                          ? 'bg-emerald-100 text-emerald-800'
                          : inv.status === 'Approved'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {inv.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() =>
                        alert(
                          `Official Mesa Tax Invoice ${inv.invoiceNumber}\nBeneficiary: ${mentor.name}\nVenture: ${inv.ventureName}\nTotal Disbursed: ₹${inv.totalAmount}\nStatus: ${inv.status}`
                        )
                      }
                      className="text-xs font-semibold text-[#4A121E] hover:underline flex items-center gap-1 ml-auto"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>PDF</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <CreateInvoiceModal
        isOpen={isInvoiceModalOpen}
        onClose={() => setIsInvoiceModalOpen(false)}
      />
    </div>
  );
};
