import React, { useState } from 'react';
import {
  Bell,
  CheckCircle2,
  Calendar,
  FileText,
  CheckSquare,
  Shield,
  FileCheck2,
  Trash2,
  ChevronRight
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';

export const NotificationsPage: React.FC = () => {
  const {
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    openVentureHistory,
    setCurrentPage
  } = useWorkspace();

  const [categoryFilter, setCategoryFilter] = useState<string>('All');

  const categories = ['All', 'Meetings', 'Reports', 'Goals', 'Admin', 'Evidence'];

  const filtered = notifications.filter((n) => {
    if (categoryFilter === 'All') return true;
    return n.category === categoryFilter;
  });

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'Meetings':
        return <Calendar className="w-4 h-4 text-blue-600" />;
      case 'Reports':
        return <FileText className="w-4 h-4 text-amber-600" />;
      case 'Goals':
        return <CheckSquare className="w-4 h-4 text-emerald-600" />;
      case 'Admin':
        return <Shield className="w-4 h-4 text-[#4A121E]" />;
      case 'Evidence':
        return <FileCheck2 className="w-4 h-4 text-purple-600" />;
      default:
        return <Bell className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#4A121E]">
            <Bell className="w-4 h-4" />
            <span>Workspace Activity Stream</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
            Notifications
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            Deliverable alerts, meeting clearance notices, and administrative updates.
          </p>
        </div>

        <button
          onClick={markAllNotificationsRead}
          className="px-4 py-2 rounded-xl text-xs font-semibold text-[#4A121E] bg-[#FAF0F2] hover:bg-[#F5D0D8] border border-[#F5D0D8] flex items-center gap-1.5 transition-colors self-start sm:self-auto"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Mark All as Read</span>
        </button>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategoryFilter(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              categoryFilter === cat
                ? 'bg-[#4A121E] text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      <div className="bg-white rounded-2xl border border-[#EDE8DC] shadow-xs divide-y divide-slate-100 overflow-hidden">
        {filtered.map((item) => (
          <div
            key={item.id}
            onClick={() => {
              markNotificationRead(item.id);
              if (item.actionUrl) {
                openVentureHistory(item.actionUrl);
              } else if (item.category === 'Reports') {
                setCurrentPage('reports');
              } else if (item.category === 'Meetings') {
                setCurrentPage('meetings');
              }
            }}
            className={`p-5 flex items-start justify-between gap-4 transition-colors cursor-pointer hover:bg-slate-50/80 ${
              !item.read ? 'bg-[#FAF0F2]/40' : ''
            }`}
          >
            <div className="flex items-start gap-3.5">
              <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 shadow-xs flex items-center justify-center shrink-0 mt-0.5">
                {getCategoryIcon(item.category)}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <p className={`text-xs sm:text-sm ${!item.read ? 'font-bold text-slate-900' : 'font-medium text-slate-800'}`}>
                    {item.title}
                  </p>
                  {!item.read && (
                    <span className="w-2 h-2 rounded-full bg-[#4A121E]" />
                  )}
                </div>
                <p className="text-xs text-slate-600 leading-relaxed max-w-2xl">{item.message}</p>
                <span className="text-[10px] text-slate-400 block pt-0.5">{item.timestamp}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600 hidden sm:inline">
                {item.category}
              </span>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="p-12 text-center text-xs text-slate-500">
            No notifications in this category.
          </div>
        )}
      </div>
    </div>
  );
};
