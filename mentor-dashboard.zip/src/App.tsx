/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { WorkspaceProvider, useWorkspace } from './context/WorkspaceContext';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { DashboardPage } from './components/pages/DashboardPage';
import { GoalsTasksPage } from './components/pages/GoalsTasksPage';
import { StartupDirectoryPage } from './components/pages/StartupDirectoryPage';
import { MentorshipSessionsPage } from './components/pages/MentorshipSessionsPage';
import { VentureHistoryPage } from './components/pages/VentureHistoryPage';
import { InvoicesPage } from './components/pages/InvoicesPage';
import { NotificationsPage } from './components/pages/NotificationsPage';
import { ProfilePage } from './components/pages/ProfilePage';

import { SubmitReportModal } from './components/modals/SubmitReportModal';
import { CreateGoalModal } from './components/modals/CreateGoalModal';
import { EvidenceViewerModal } from './components/modals/EvidenceViewerModal';

const MainLayout: React.FC = () => {
  const { currentPage } = useWorkspace();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'mentorship-sessions':
      case 'meetings':
      case 'reports':
      case 'availability':
        return <MentorshipSessionsPage />;
      case 'goals':
        return <GoalsTasksPage />;
      case 'directory':
        return <StartupDirectoryPage />;
      case 'venture-history':
        return <VentureHistoryPage />;
      case 'invoices':
        return <InvoicesPage />;
      case 'notifications':
        return <NotificationsPage />;
      case 'profile':
        return <ProfilePage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-slate-800 flex">
      {/* Dark Maroon Sidebar */}
      <Sidebar
        isMobileOpen={isMobileSidebarOpen}
        setIsMobileOpen={setIsMobileSidebarOpen}
      />

      {/* Main Viewport Container */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Sticky Ivory Header */}
        <Header
          onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        />

        {/* Page Content Viewport */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 sm:py-8 max-w-7xl w-full mx-auto">
          {renderCurrentPage()}
        </main>
      </div>

      {/* Global Interactive Modals */}
      <SubmitReportModal />
      <CreateGoalModal />
      <EvidenceViewerModal />
    </div>
  );
};

export default function App() {
  return (
    <WorkspaceProvider>
      <MainLayout />
    </WorkspaceProvider>
  );
}
