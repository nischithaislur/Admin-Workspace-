import {
  Venture,
  MentorshipMeeting,
  MeetingReport,
  GoalTask,
  AvailabilitySlot,
  BlackoutDate,
  Invoice,
  NotificationItem,
  MentorProfile,
  VentureActivity
} from '../types';

export const CURRENT_MENTOR: MentorProfile = {
  id: 'mentor-rajesh-01',
  name: 'Dr. Rajesh Sharma',
  salutation: 'Dr.',
  title: 'Principal Mentor & Venture Partner',
  email: 'rajesh.sharma@mesa.edu',
  phone: '+91 98201 45890',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=256', // or stylized monogram
  programmeRole: 'Principal Mentor',
  cohort: 'ILS · PGP 2026',
  bio: 'Former VP of Product at InMobi and 2x Founder with successful exit in B2B SaaS. Advising early-stage founders across Product-Market Fit, Go-To-Market strategy, and institutional venture capital readiness.',
  areasOfExpertise: [
    'B2B SaaS',
    'Customer Discovery & MSL',
    'Pricing & Unit Economics',
    'Seed Fundraising',
    'Go-To-Market Execution'
  ],
  totalSessionsCompleted: 28,
  totalHoursMentored: 34.5,
  activeVenturesCount: 4,
  studentSatisfactionRating: 4.95,
  bufferTimeMinutes: 15,
  preferredMeetingLength: 45
};

export const INITIAL_VENTURES: Venture[] = [
  {
    id: 'venture-campuscart',
    name: 'CampusCart',
    tagline: 'Hyperlocal 15-minute campus delivery & student commerce network',
    logo: 'CC',
    description:
      'CampusCart enables university students to order midnight essentials, stationery, and micro-meals delivered directly to hostel rooms within 15 minutes, powered by student fulfillment leads and localized micro-inventory pods.',
    industry: 'Quick Commerce & Campus Tech',
    currentStage: 'Build',
    currentMSL: 'MSL Level 3 — Product-Solution Fit & Pilot Traction',
    foundingDate: 'Jan 15, 2026',
    programme: 'ILS · PGP 2026',
    status: 'Active Incubate',
    isAssignedToCurrentMentor: true,
    founders: [
      {
        name: 'Ananya Rao',
        role: 'CEO & Co-Founder',
        email: 'ananya.r@mesa.edu',
        phone: '+91 98450 11223',
        programBatch: 'PGP 2026 - Section A'
      },
      {
        name: 'Rohan Verma',
        role: 'CTO & Co-Founder',
        email: 'rohan.v@mesa.edu',
        phone: '+91 98450 99881',
        programBatch: 'PGP 2026 - Section B'
      }
    ],
    mentorAssignment: {
      principalMentor: {
        id: 'mentor-rajesh-01',
        name: 'Dr. Rajesh Sharma',
        role: 'Principal Mentor',
        email: 'rajesh.sharma@mesa.edu'
      },
      associateMentor: {
        id: 'mentor-priya-02',
        name: 'Priya Nair',
        role: 'Associate Mentor',
        email: 'priya.nair@mesa.edu'
      }
    },
    stageMilestones: [
      {
        stage: 'Discover',
        status: 'Completed',
        completionDate: 'Feb 10, 2026',
        milestoneName: '100+ On-Campus Problem Validation Interviews'
      },
      {
        stage: 'Validate',
        status: 'Completed',
        completionDate: 'Mar 18, 2026',
        milestoneName: 'WhatsApp Concierge MVP (₹1.2L GMV)'
      },
      {
        stage: 'Build',
        status: 'Current',
        milestoneName: 'PWA Mobile Ordering App & 3 Hostel Hub Pods'
      },
      {
        stage: 'Launch',
        status: 'Upcoming',
        milestoneName: 'Multi-Campus Rollout Across 3 Universities'
      },
      {
        stage: 'Grow',
        status: 'Upcoming',
        milestoneName: 'Institutional Seed Round & Brand Partnerships'
      }
    ],
    metrics: {
      mrr: '₹1,85,000',
      customerInterviewsCount: 142,
      teamSize: 6,
      fundingRaised: '₹15L (Mesa Grant Pool)',
      targetMarket: 'Tier 1 & 2 Residential Universities'
    },
    playbookWeeks: [
      {
        weekNumber: 1,
        phase: 'Problem Space Exploration',
        title: 'Customer Discovery & Cohort Archetypes',
        status: 'Completed',
        completionDate: 'Jan 24, 2026',
        activities: [
          {
            id: 'act-cc-1',
            title: 'Define 3 distinct customer persona archetypes',
            description: 'Document midnight snackers, exam rush stationery buyers, and hostel laundry needs.',
            status: 'Completed',
            completedDate: 'Jan 22, 2026',
            evidenceSubmitted: {
              id: 'ev-cc-1',
              title: 'CampusCart_Customer_Archetypes_V1.pdf',
              fileType: 'PDF',
              fileUrl: '#',
              submissionDate: 'Jan 22, 2026',
              adminApprovalStatus: 'Approved',
              adminFeedback: 'Clear differentiation of urgent vs planned purchasing behavior. Approved by Mesa Incubation Director.',
              verifiedBy: 'Mesa Admin'
            }
          },
          {
            id: 'act-cc-2',
            title: 'Conduct 25 unstructured founder discovery calls',
            description: 'Focus exclusively on past purchase frustrations without pitching any solution.',
            status: 'Completed',
            completedDate: 'Jan 24, 2026',
            evidenceSubmitted: {
              id: 'ev-cc-2',
              title: 'Customer_Discovery_Notes_Summary.pdf',
              fileType: 'PDF',
              fileUrl: '#',
              submissionDate: 'Jan 24, 2026',
              adminApprovalStatus: 'Approved',
              adminFeedback: 'Comprehensive interview synthesis. Verified against rubric.',
              verifiedBy: 'Mesa Admin'
            }
          }
        ]
      },
      {
        weekNumber: 2,
        phase: 'Demand Verification',
        title: 'Smoke Test & Concierge MVP Launch',
        status: 'Completed',
        completionDate: 'Feb 15, 2026',
        activities: [
          {
            id: 'act-cc-3',
            title: 'Deploy WhatsApp Order Concierge for Block B Hostel',
            description: 'Run manual order taking with 15-minute SLA to test fulfillment bottlenecks.',
            status: 'Completed',
            completedDate: 'Feb 12, 2026',
            evidenceSubmitted: {
              id: 'ev-cc-3',
              title: 'WhatsApp_Concierge_Order_Log_100Orders.xlsx',
              fileType: 'SHEET',
              fileUrl: '#',
              submissionDate: 'Feb 13, 2026',
              adminApprovalStatus: 'Approved',
              adminFeedback: 'Impressive average turnaround of 11.4 minutes on first 100 orders.',
              verifiedBy: 'Mesa Admin'
            }
          }
        ]
      },
      {
        weekNumber: 3,
        phase: 'Product Architecture',
        title: 'PWA Architecture & Inventory Integration',
        status: 'Current',
        activities: [
          {
            id: 'act-cc-4',
            title: 'Complete Mobile PWA Wireframes and Core Flow',
            description: 'Map checkout flow with UPI QR code instant payment and live pod inventory check.',
            status: 'Completed',
            completedDate: 'Mar 28, 2026',
            evidenceSubmitted: {
              id: 'ev-cc-4',
              title: 'CampusCart_Figma_Design_Spec_v3.pdf',
              fileType: 'PDF',
              fileUrl: '#',
              submissionDate: 'Mar 29, 2026',
              adminApprovalStatus: 'Approved',
              adminFeedback: 'Clean student-friendly design. Proceed to test with hostel focus group.',
              verifiedBy: 'Mesa Admin'
            }
          },
          {
            id: 'act-cc-5',
            title: 'Hostel Pod Micro-Inventory Ledger Setup',
            description: 'Implement real-time SKU tracking for 40 fast-moving items in Hostel Pod 1.',
            status: 'In Progress'
          }
        ]
      }
    ],
    mslCriteria: [
      {
        id: 'msl-cc-1',
        name: 'Validated Customer Problem',
        category: 'Market Need',
        description: 'Empirical proof that hostel delivery latency and restricted cafeteria hours cause recurring high friction.',
        isVerified: false,
        tasks: [
          {
            id: 'msl-t-1',
            title: '30 Customer Interviews Documented',
            requiredMetric: '30 detailed transcripts',
            currentMetric: '30 documented',
            status: 'Approved',
            evidenceName: 'CampusCart_30_Customer_Transcripts.pdf',
            verifiedDate: 'Feb 02, 2026',
            verifiedBy: 'Admin (Prof. K. Iyer)'
          },
          {
            id: 'msl-t-2',
            title: '30 Customer Testimonials & Friction Quotes',
            requiredMetric: '30 verified quotes',
            currentMetric: '30 verified',
            status: 'Approved',
            evidenceName: 'Verified_Testimonials_Matrix.pdf',
            verifiedDate: 'Feb 08, 2026',
            verifiedBy: 'Admin (Prof. K. Iyer)'
          },
          {
            id: 'msl-t-3',
            title: '5 One-on-One Extended Hostel Warden & Admin Calls',
            requiredMetric: '5 signed clearances',
            currentMetric: '3 completed, 2 under review',
            status: 'Under Review',
            evidenceName: 'Warden_Consultation_Logs.pdf'
          }
        ]
      },
      {
        id: 'msl-cc-2',
        name: 'Problem-Solution Fit Prototype',
        category: 'Product Validation',
        description: 'Working concierge or prototype demonstrating active repeat purchases by initial user cohort.',
        isVerified: true,
        verifiedDate: 'Mar 20, 2026',
        tasks: [
          {
            id: 'msl-t-4',
            title: '100 Organic Concierge Transactions Completed',
            requiredMetric: '100 orders',
            currentMetric: '184 orders',
            status: 'Approved',
            evidenceName: 'Concierge_Order_Ledger_Audited.pdf',
            verifiedDate: 'Mar 19, 2026',
            verifiedBy: 'Admin'
          },
          {
            id: 'msl-t-5',
            title: '40%+ 7-Day Student Repeat Rate',
            requiredMetric: '40% repeat',
            currentMetric: '48.2% repeat',
            status: 'Approved',
            evidenceName: 'Cohort_Retention_Analysis_W3.pdf',
            verifiedDate: 'Mar 20, 2026',
            verifiedBy: 'Admin'
          }
        ]
      },
      {
        id: 'msl-cc-3',
        name: 'Unit Economics & Contribution Margin Positive',
        category: 'Financial Viability',
        description: 'Delivery fee and wholesale markup exceed micro-fulfillment cost per drop.',
        isVerified: false,
        tasks: [
          {
            id: 'msl-t-6',
            title: 'Unit Contribution Margin > ₹18 per Order',
            requiredMetric: '₹18 net contribution',
            currentMetric: '₹14.50 current',
            status: 'Pending Submission'
          },
          {
            id: 'msl-t-7',
            title: 'Inventory Shrinkage < 2.5% across 30 days',
            requiredMetric: '< 2.5% shrinkage',
            currentMetric: '1.9% logged',
            status: 'Under Review',
            evidenceName: 'Shrinkage_Audit_March2026.pdf'
          }
        ]
      }
    ],
    workshops: [
      {
        id: 'ws-1',
        title: 'MSL Framework & Metric Grounding',
        date: 'Jan 18, 2026',
        instructor: 'Dr. Rajesh Sharma',
        attended: true,
        attendanceType: 'In-Person',
        notes: 'Ananya and Rohan presented their customer interview rubric.'
      },
      {
        id: 'ws-2',
        title: 'B2B & Campus GTM Playbooks',
        date: 'Feb 14, 2026',
        instructor: 'Deepak Varma',
        attended: true,
        attendanceType: 'In-Person',
        notes: 'Constructed the university administration partnership memo.'
      },
      {
        id: 'ws-3',
        title: 'Unit Economics: CAC, LTV & Payback',
        date: 'Mar 10, 2026',
        instructor: 'Dr. Rajesh Sharma',
        attended: true,
        attendanceType: 'Virtual',
        notes: 'Analyzed micro-hub inventory turnover and student runner incentive design.'
      }
    ]
  },
  {
    id: 'venture-agriloop',
    name: 'AgriLoop',
    tagline: 'IoT solar cold lockers & predictive farm-to-mandi logistics',
    logo: 'AL',
    description:
      'AgriLoop deploys shared solar-powered cold storage micro-lockers at rural village clusters, giving smallholder vegetable farmers 14 additional days of produce shelf-life and direct price discovery at nearby urban wholesale mandis.',
    industry: 'AgriTech & ClimateTech',
    currentStage: 'Validate',
    currentMSL: 'MSL Level 2 — Customer Problem & Pilot Feasibility',
    foundingDate: 'Dec 01, 2025',
    programme: 'ILS · PGP 2026',
    status: 'Active Incubate',
    isAssignedToCurrentMentor: true,
    founders: [
      {
        name: 'Vikram Choudhury',
        role: 'Founder & CEO',
        email: 'vikram.c@mesa.edu',
        phone: '+91 97110 33445',
        programBatch: 'PGP 2026 - Section C'
      },
      {
        name: 'Meera Deshmukh',
        role: 'Head of Operations',
        email: 'meera.d@mesa.edu',
        phone: '+91 97110 66778',
        programBatch: 'PGP 2026 - Section A'
      }
    ],
    mentorAssignment: {
      principalMentor: {
        id: 'mentor-rajesh-01',
        name: 'Dr. Rajesh Sharma',
        role: 'Principal Mentor',
        email: 'rajesh.sharma@mesa.edu'
      }
    },
    stageMilestones: [
      {
        stage: 'Discover',
        status: 'Completed',
        completionDate: 'Jan 10, 2026',
        milestoneName: 'Field Interviews with 50 Tomato & Chili Farmers in Nashik'
      },
      {
        stage: 'Validate',
        status: 'Current',
        milestoneName: 'First 2 Solar Cold Locker Pilots Operating in Niphad'
      },
      {
        stage: 'Build',
        status: 'Upcoming',
        milestoneName: 'IoT Temperature Telemetry & Mandi Auction Mobile App'
      },
      {
        stage: 'Launch',
        status: 'Upcoming',
        milestoneName: 'Cluster Deployment of 20 Lockers across Maharashtra'
      },
      {
        stage: 'Grow',
        status: 'Upcoming',
        milestoneName: 'Institutional Nabard / Agri Infra Fund Subsidies'
      }
    ],
    metrics: {
      mrr: '₹65,000',
      customerInterviewsCount: 88,
      teamSize: 4,
      fundingRaised: '₹10L Prototype Grant',
      targetMarket: 'Nashik & Pune Vegetable Farmer Producer Orgs (FPOs)'
    },
    playbookWeeks: [
      {
        weekNumber: 1,
        phase: 'Problem Space Exploration',
        title: 'Farmer Post-Harvest Loss Mapping',
        status: 'Completed',
        completionDate: 'Jan 15, 2026',
        activities: [
          {
            id: 'act-al-1',
            title: 'Quantify daily distress selling discounts at Vashi Mandi',
            description: 'Measure price drop between morning peak (7am) and evening distress selloff (4pm).',
            status: 'Completed',
            completedDate: 'Jan 14, 2026',
            evidenceSubmitted: {
              id: 'ev-al-1',
              title: 'Mandi_Distress_Price_Drop_Report.pdf',
              fileType: 'PDF',
              fileUrl: '#',
              submissionDate: 'Jan 14, 2026',
              adminApprovalStatus: 'Approved',
              adminFeedback: 'Rigorous empirical pricing research showing average 38% value loss on perishables.',
              verifiedBy: 'Mesa Admin'
            }
          }
        ]
      },
      {
        weekNumber: 2,
        phase: 'Pilot Deployment',
        title: 'Solar Locker Hardware Prototype',
        status: 'Completed',
        completionDate: 'Feb 20, 2026',
        activities: [
          {
            id: 'act-al-2',
            title: 'Deploy Phase-1 Cold Unit in Niphad Village',
            description: 'Connect 12 farmer members and log internal cabinet temperature for 14 continuous days.',
            status: 'Completed',
            completedDate: 'Feb 19, 2026',
            evidenceSubmitted: {
              id: 'ev-al-2',
              title: 'Niphad_Solar_Locker_Field_Log.pdf',
              fileType: 'PDF',
              fileUrl: '#',
              submissionDate: 'Feb 20, 2026',
              adminApprovalStatus: 'Approved',
              adminFeedback: 'Temperature maintained steadily between 4°C - 7°C even during peak afternoon heat.',
              verifiedBy: 'Mesa Admin'
            }
          }
        ]
      }
    ],
    mslCriteria: [
      {
        id: 'msl-al-1',
        name: 'Validated Customer Problem',
        category: 'Market Need',
        description: 'Empirical verification that post-harvest spoilage forces farmers into distress selling below production costs.',
        isVerified: true,
        verifiedDate: 'Feb 05, 2026',
        tasks: [
          {
            id: 'msl-al-t1',
            title: '40 Farmer Loss Interviews Recorded',
            requiredMetric: '40 interviews',
            currentMetric: '42 recorded',
            status: 'Approved',
            evidenceName: 'Nashik_Farmer_Field_Interviews.pdf',
            verifiedDate: 'Feb 04, 2026',
            verifiedBy: 'Admin'
          },
          {
            id: 'msl-al-t2',
            title: 'Mandi Price Drop Log (15 days)',
            requiredMetric: '15 consecutive days',
            currentMetric: '15 days verified',
            status: 'Approved',
            evidenceName: 'Vashi_Mandi_Price_Index.pdf',
            verifiedDate: 'Feb 05, 2026',
            verifiedBy: 'Admin'
          }
        ]
      },
      {
        id: 'msl-al-2',
        name: 'Proof of Value & Payback Willingness',
        category: 'Business Model',
        description: 'Farmers demonstrate willingness to pay ₹120/crate/week for storage vs losing ₹400 in distress sales.',
        isVerified: false,
        tasks: [
          {
            id: 'msl-al-t3',
            title: '15 Paid Farmer Commitments Secured',
            requiredMetric: '15 paid tokens',
            currentMetric: '12 paid, 3 pending',
            status: 'Under Review',
            evidenceName: 'Farmer_Paid_PreOrders_FPO1.pdf'
          },
          {
            id: 'msl-al-t4',
            title: 'FPO Commercial Agreement Signed',
            requiredMetric: '1 signed MOU',
            currentMetric: 'Draft under review by legal',
            status: 'In Progress'
          }
        ]
      }
    ],
    workshops: [
      {
        id: 'ws-al-1',
        title: 'MSL Framework & Metric Grounding',
        date: 'Jan 18, 2026',
        instructor: 'Dr. Rajesh Sharma',
        attended: true,
        attendanceType: 'In-Person',
        notes: 'Vikram presented farmer interview insights.'
      },
      {
        id: 'ws-al-2',
        title: 'ClimateTech Grants & Non-Dilutive Capital',
        date: 'Mar 02, 2026',
        instructor: 'Prof. Sunita Rao',
        attended: true,
        attendanceType: 'Virtual',
        notes: 'Applied for Department of Science & Technology prototype fellowship.'
      }
    ]
  },
  {
    id: 'venture-kiranaos',
    name: 'KiranaOS',
    tagline: 'Vernacular AI inventory, credit ledger & B2B reordering for mom-and-pop stores',
    logo: 'KO',
    description:
      'KiranaOS transforms traditional corner grocery retailers into tech-enabled hubs with voice-assisted vernacular inventory management, automated WhatsApp supplier PO generation, and micro-working capital advances.',
    industry: 'RetailTech & FinTech',
    currentStage: 'Build',
    currentMSL: 'MSL Level 3 — Product-Solution Fit & Pilot Traction',
    foundingDate: 'Nov 20, 2025',
    programme: 'ILS · PGP 2026',
    status: 'Active Incubate',
    isAssignedToCurrentMentor: true,
    founders: [
      {
        name: 'Arjun Singhania',
        role: 'CEO',
        email: 'arjun.s@mesa.edu',
        phone: '+91 99300 44556',
        programBatch: 'PGP 2026 - Section B'
      },
      {
        name: 'Tanvi Shah',
        role: 'Chief Product Officer',
        email: 'tanvi.s@mesa.edu',
        phone: '+91 99300 77889',
        programBatch: 'PGP 2026 - Section C'
      }
    ],
    mentorAssignment: {
      principalMentor: {
        id: 'mentor-rajesh-01',
        name: 'Dr. Rajesh Sharma',
        role: 'Principal Mentor',
        email: 'rajesh.sharma@mesa.edu'
      }
    },
    stageMilestones: [
      {
        stage: 'Discover',
        status: 'Completed',
        completionDate: 'Dec 22, 2025',
        milestoneName: '120 Shopkeeper Workflows Shadowed in Bengaluru'
      },
      {
        stage: 'Validate',
        status: 'Completed',
        completionDate: 'Feb 10, 2026',
        milestoneName: 'WhatsApp Voice Ledger Pilot with 45 Kiranas'
      },
      {
        stage: 'Build',
        status: 'Current',
        milestoneName: 'Android POS & Supplier Auto-PO Bridge'
      },
      {
        stage: 'Launch',
        status: 'Upcoming',
        milestoneName: 'Commercial Rollout in Indiranagar & Koramangala'
      },
      {
        stage: 'Grow',
        status: 'Upcoming',
        milestoneName: 'NBFC Partner Integration for Daily Credit Lines'
      }
    ],
    metrics: {
      mrr: '₹2,40,000',
      customerInterviewsCount: 160,
      teamSize: 5,
      fundingRaised: '₹25L Angel Round',
      targetMarket: 'Urban Mom-and-Pop Retailers (Tier 1 Metros)'
    },
    playbookWeeks: [
      {
        weekNumber: 1,
        phase: 'Product Discovery',
        title: 'Voice Interface Accuracy for Dialects',
        status: 'Completed',
        completionDate: 'Jan 10, 2026',
        activities: [
          {
            id: 'act-ko-1',
            title: 'Test Kannada and Hindi voice audio samples in noisy store environments',
            description: 'Ensure 95%+ transcription fidelity during peak street traffic hours.',
            status: 'Completed',
            completedDate: 'Jan 09, 2026',
            evidenceSubmitted: {
              id: 'ev-ko-1',
              title: 'Acoustic_Noise_Fidelity_Benchmarking.pdf',
              fileType: 'PDF',
              fileUrl: '#',
              submissionDate: 'Jan 09, 2026',
              adminApprovalStatus: 'Approved',
              adminFeedback: 'Demonstrated 96.2% intent recognition on noisy ambient grocery recordings.',
              verifiedBy: 'Mesa Admin'
            }
          }
        ]
      }
    ],
    mslCriteria: [
      {
        id: 'msl-ko-1',
        name: 'Validated Customer Problem',
        category: 'Market Need',
        description: 'Proof that manual stockouts and uncollected customer credit leak > 18% of monthly net retailer profits.',
        isVerified: true,
        verifiedDate: 'Jan 18, 2026',
        tasks: [
          {
            id: 'msl-ko-t1',
            title: '50 Khata Book Audits',
            requiredMetric: '50 shops',
            currentMetric: '54 shops audited',
            status: 'Approved',
            evidenceName: 'Khata_Credit_Leakage_Analysis.pdf',
            verifiedDate: 'Jan 17, 2026',
            verifiedBy: 'Admin'
          }
        ]
      },
      {
        id: 'msl-ko-2',
        name: 'Product-Solution Fit & Daily Active Usage',
        category: 'Product Validation',
        description: 'Kirana owners engage with the application at least 3 times daily without founder prompting.',
        isVerified: false,
        tasks: [
          {
            id: 'msl-ko-t2',
            title: '30 Daily Active Stores (DAU/MAU > 70%)',
            requiredMetric: '30 stores',
            currentMetric: '24 stores active',
            status: 'In Progress'
          },
          {
            id: 'msl-ko-t3',
            title: '500 Supplier POs Sent via Platform',
            requiredMetric: '500 POs',
            currentMetric: '412 POs sent',
            status: 'Under Review',
            evidenceName: 'Supplier_PO_Transaction_Log.pdf'
          }
        ]
      }
    ],
    workshops: [
      {
        id: 'ws-ko-1',
        title: 'B2B Sales Cycles & Partner Distribution',
        date: 'Feb 20, 2026',
        instructor: 'Dr. Rajesh Sharma',
        attended: true,
        attendanceType: 'In-Person',
        notes: 'Strategized FMCG brand trade marketing incentives.'
      }
    ]
  },
  {
    id: 'venture-medibridge',
    name: 'MediBridge',
    tagline: 'Smart diagnostic tele-consultation kiosks for semi-urban clinics',
    logo: 'MB',
    description:
      'MediBridge connects rural and semi-urban patients with certified city specialists through connected diagnostic kiosks equipped with digital stethoscopes, instant ECG, and vitals integration.',
    industry: 'HealthTech & Diagnostics',
    currentStage: 'Launch',
    currentMSL: 'MSL Level 4 — Commercial Scalability & Unit Profitability',
    foundingDate: 'Oct 10, 2025',
    programme: 'ILS · PGP 2026',
    status: 'Active Incubate',
    isAssignedToCurrentMentor: true,
    founders: [
      {
        name: 'Dr. Shalini Menon',
        role: 'Co-Founder & Clinical Director',
        email: 'shalini.m@mesa.edu',
        phone: '+91 94470 12345',
        programBatch: 'PGP 2026 - Section A'
      },
      {
        name: 'Karthik Raman',
        role: 'Co-Founder & COO',
        email: 'karthik.r@mesa.edu',
        phone: '+91 94470 67890',
        programBatch: 'PGP 2026 - Section B'
      }
    ],
    mentorAssignment: {
      principalMentor: {
        id: 'mentor-rajesh-01',
        name: 'Dr. Rajesh Sharma',
        role: 'Principal Mentor',
        email: 'rajesh.sharma@mesa.edu'
      }
    },
    stageMilestones: [
      {
        stage: 'Discover',
        status: 'Completed',
        completionDate: 'Nov 15, 2025',
        milestoneName: 'Clinical Need Audit in Mandya & Hassan Districts'
      },
      {
        stage: 'Validate',
        status: 'Completed',
        completionDate: 'Jan 05, 2026',
        milestoneName: '150 Tele-consultations with Partner Hospital Network'
      },
      {
        stage: 'Build',
        status: 'Completed',
        completionDate: 'Feb 28, 2026',
        milestoneName: 'Hardware Diagnostic Box CDSCO Compliance Approved'
      },
      {
        stage: 'Launch',
        status: 'Current',
        milestoneName: '12 Clinic Centers Live across Southern Karnataka'
      },
      {
        stage: 'Grow',
        status: 'Upcoming',
        milestoneName: 'Series A Expansion to 100 Clinic Centers'
      }
    ],
    metrics: {
      mrr: '₹4,80,000',
      customerInterviewsCount: 220,
      teamSize: 8,
      fundingRaised: '₹60L Institutional Seed',
      targetMarket: 'Tier 2/3 Towns & Semi-Urban Clinics'
    },
    playbookWeeks: [
      {
        weekNumber: 1,
        phase: 'Clinical Protocols',
        title: 'Telemedicine Regulatory Adherence',
        status: 'Completed',
        completionDate: 'Nov 25, 2025',
        activities: [
          {
            id: 'act-mb-1',
            title: 'CDSCO Class B Medical Device Compliance Verification',
            description: 'Obtain statutory testing clearances for integrated blood glucose and ECG sensors.',
            status: 'Completed',
            completedDate: 'Nov 24, 2025',
            evidenceSubmitted: {
              id: 'ev-mb-1',
              title: 'CDSCO_Compliance_Certificate_VitalsHub.pdf',
              fileType: 'PDF',
              fileUrl: '#',
              submissionDate: 'Nov 24, 2025',
              adminApprovalStatus: 'Approved',
              adminFeedback: 'Full statutory compliance documentation in order.',
              verifiedBy: 'Mesa Admin'
            }
          }
        ]
      }
    ],
    mslCriteria: [
      {
        id: 'msl-mb-1',
        name: 'Validated Clinical Problem & Access Barrier',
        category: 'Market Need',
        description: 'Proof that patients travel > 65km and incur ₹1,800 travel expenses for basic cardiology and endocrinology follow-ups.',
        isVerified: true,
        verifiedDate: 'Dec 12, 2025',
        tasks: [
          {
            id: 'msl-mb-t1',
            title: '100 Patient Travel Expense Audits',
            requiredMetric: '100 audits',
            currentMetric: '112 audits verified',
            status: 'Approved',
            evidenceName: 'Patient_Distance_Expense_Study.pdf',
            verifiedDate: 'Dec 10, 2025',
            verifiedBy: 'Admin'
          }
        ]
      },
      {
        id: 'msl-mb-2',
        name: 'Commercial Scalability & Clinic Partner Payback',
        category: 'Business Model',
        description: 'Local pharmacy/clinic partners break even on equipment lease within 60 days of installation.',
        isVerified: true,
        verifiedDate: 'Feb 15, 2026',
        tasks: [
          {
            id: 'msl-mb-t2',
            title: '10 Consecutive Partner Clinics Profitable',
            requiredMetric: '10 clinics',
            currentMetric: '12 clinics operating profitably',
            status: 'Approved',
            evidenceName: 'Clinic_Partner_PnL_Cohort1.pdf',
            verifiedDate: 'Feb 14, 2026',
            verifiedBy: 'Admin'
          }
        ]
      }
    ],
    workshops: [
      {
        id: 'ws-mb-1',
        title: 'MedTech Regulatory Clearance & Hospital Alliances',
        date: 'Dec 10, 2025',
        instructor: 'Dr. Rajesh Sharma',
        attended: true,
        attendanceType: 'In-Person',
        notes: 'Refined enterprise pricing contract for Manipal Hospitals MoU.'
      }
    ]
  },
  {
    id: 'venture-loomly',
    name: 'Loomly',
    tagline: 'Direct-from-weaver ethical luxury textiles with digital provenance',
    logo: 'LY',
    description:
      'Loomly connects heritage handloom weavers in Pochampally and Maheshwar directly with conscious urban luxury buyers through authenticated digital origin passports, doubling weaver wage realisations.',
    industry: 'Artisan D2C & Luxury Marketplace',
    currentStage: 'Validate',
    currentMSL: 'MSL Level 2 — Customer Problem & Pilot Feasibility',
    foundingDate: 'Jan 02, 2026',
    programme: 'ILS · PGP 2026',
    status: 'Active Incubate',
    isAssignedToCurrentMentor: true,
    founders: [
      {
        name: 'Pallavi Rao',
        role: 'Founder & Creative Lead',
        email: 'pallavi.r@mesa.edu',
        phone: '+91 96190 22334',
        programBatch: 'PGP 2026 - Section C'
      }
    ],
    mentorAssignment: {
      principalMentor: {
        id: 'mentor-rajesh-01',
        name: 'Dr. Rajesh Sharma',
        role: 'Principal Mentor',
        email: 'rajesh.sharma@mesa.edu'
      },
      associateMentor: {
        id: 'mentor-neha-03',
        name: 'Neha Kapoor',
        role: 'Associate Mentor',
        email: 'neha.kapoor@mesa.edu'
      }
    },
    stageMilestones: [
      {
        stage: 'Discover',
        status: 'Completed',
        completionDate: 'Feb 01, 2026',
        milestoneName: 'Maheshwari Weaver Cluster Interviews'
      },
      {
        stage: 'Validate',
        status: 'Current',
        milestoneName: 'Curated Capsule Drop #1 (Sold Out ₹3.5L)'
      },
      {
        stage: 'Build',
        status: 'Upcoming',
        milestoneName: 'Shopify Custom Store & QR Provenance Tags'
      },
      {
        stage: 'Launch',
        status: 'Upcoming',
        milestoneName: 'US & UK Ethical Fashion Retail Trunk Shows'
      },
      {
        stage: 'Grow',
        status: 'Upcoming',
        milestoneName: 'Cluster Co-operative Scaling to 250 Looms'
      }
    ],
    metrics: {
      mrr: '₹1,20,000',
      customerInterviewsCount: 75,
      teamSize: 3,
      fundingRaised: '₹5L Mesa Grant',
      targetMarket: 'Conscious Luxury D2C & Export Buyers'
    },
    playbookWeeks: [
      {
        weekNumber: 1,
        phase: 'Value Proposition',
        title: 'Provenance Storytelling & Authenticity Proof',
        status: 'Completed',
        completionDate: 'Jan 28, 2026',
        activities: [
          {
            id: 'act-ly-1',
            title: 'Design Weaver Micro-Documentary Cards',
            description: 'Provide photograph, weaver name, and weaving hours for each garment tag.',
            status: 'Completed',
            completedDate: 'Jan 27, 2026',
            evidenceSubmitted: {
              id: 'ev-ly-1',
              title: 'Loomly_Artisan_Tag_Prototypes.pdf',
              fileType: 'PDF',
              fileUrl: '#',
              submissionDate: 'Jan 27, 2026',
              adminApprovalStatus: 'Approved',
              adminFeedback: 'High emotional resonance and tangible artisan attribution.',
              verifiedBy: 'Mesa Admin'
            }
          }
        ]
      }
    ],
    mslCriteria: [
      {
        id: 'msl-ly-1',
        name: 'Validated Customer Problem & Willingness to Pay',
        category: 'Market Need',
        description: 'Buyers will pay a 40%+ price premium when guaranteed genuine handloom weave with direct weaver attribution.',
        isVerified: true,
        verifiedDate: 'Feb 15, 2026',
        tasks: [
          {
            id: 'msl-ly-t1',
            title: 'Capsule Drop 1 Sold Out in < 48 Hours',
            requiredMetric: '50 units sold',
            currentMetric: '58 units sold',
            status: 'Approved',
            evidenceName: 'Shopify_Sales_Ledger_Drop1.pdf',
            verifiedDate: 'Feb 14, 2026',
            verifiedBy: 'Admin'
          }
        ]
      }
    ],
    workshops: [
      {
        id: 'ws-ly-1',
        title: 'Brand Positioning & Premium Pricing Psychology',
        date: 'Feb 05, 2026',
        instructor: 'Dr. Rajesh Sharma',
        attended: true,
        attendanceType: 'In-Person',
        notes: 'Reviewed direct weaver compensation model.'
      }
    ]
  },
  {
    id: 'venture-solarplex',
    name: 'SolarPlex',
    tagline: 'Commercial rooftop solar aggregation & AI net metering brokerage',
    logo: 'SP',
    description:
      'SolarPlex aggregates commercial warehouse rooftops to install zero-capex solar installations, brokering green energy credits directly to heavy industrial consumers in adjacent MIDC zones.',
    industry: 'CleanTech & Energy',
    currentStage: 'Discover',
    currentMSL: 'MSL Level 1 — Problem Space Identification',
    foundingDate: 'Feb 20, 2026',
    programme: 'ILS · PGP 2026',
    status: 'Active Incubate',
    isAssignedToCurrentMentor: false, // NOT assigned to current mentor (Demonstrates Row Level Security / Permission Restriction)
    founders: [
      {
        name: 'Devansh Kulkarni',
        role: 'CEO & Founder',
        email: 'devansh.k@mesa.edu',
        phone: '+91 98220 55667',
        programBatch: 'PGP 2026 - Section B'
      }
    ],
    mentorAssignment: {
      principalMentor: {
        id: 'mentor-amitabh-04',
        name: 'Amitabh Sen',
        role: 'Principal Mentor',
        email: 'amitabh.sen@mesa.edu'
      }
    },
    stageMilestones: [
      {
        stage: 'Discover',
        status: 'Current',
        milestoneName: '15 Warehouse Rooftop Solar Feasibility Studies'
      },
      {
        stage: 'Validate',
        status: 'Upcoming',
        milestoneName: 'State DISCOM Open Access PPA Clearance'
      },
      {
        stage: 'Build',
        status: 'Upcoming',
        milestoneName: '500 kW Micro-Grid Installation'
      },
      {
        stage: 'Launch',
        status: 'Upcoming',
        milestoneName: 'Green Credit Trading Portal'
      },
      {
        stage: 'Grow',
        status: 'Upcoming',
        milestoneName: 'Expansion Across Western Industrial Corridors'
      }
    ],
    metrics: {
      customerInterviewsCount: 18,
      teamSize: 2,
      targetMarket: 'Industrial Warehouse Parks'
    },
    playbookWeeks: [],
    mslCriteria: [],
    workshops: []
  }
];

export const INITIAL_MEETINGS: MentorshipMeeting[] = [
  {
    id: 'mtg-01',
    ventureId: 'venture-campuscart',
    ventureName: 'CampusCart',
    founderName: 'Ananya Rao & Rohan Verma',
    mentorId: 'mentor-rajesh-01',
    mentorName: 'Dr. Rajesh Sharma',
    scheduledAt: '2026-11-05T14:30:00',
    durationMinutes: 45,
    topic: 'MSL-3 Unit Contribution Audit & Multi-Hostel Pod Expansion',
    status: 'Scheduled',
    meetingLink: 'https://meet.google.com/mesa-cc-nov5',
    location: 'Incubation Studio 3B / Virtual',
    adminApproved: true,
    reportSubmitted: false
  },
  {
    id: 'mtg-02',
    ventureId: 'venture-agriloop',
    ventureName: 'AgriLoop',
    founderName: 'Vikram Choudhury',
    mentorId: 'mentor-rajesh-01',
    mentorName: 'Dr. Rajesh Sharma',
    scheduledAt: '2026-11-06T16:00:00',
    durationMinutes: 45,
    topic: 'FPO Commercial Agreement & Cold Locker Subsidies',
    status: 'Scheduled',
    meetingLink: 'https://meet.google.com/mesa-al-nov6',
    location: 'Conference Room 2',
    adminApproved: true,
    reportSubmitted: false
  },
  {
    id: 'mtg-03',
    ventureId: 'venture-kiranaos',
    ventureName: 'KiranaOS',
    founderName: 'Arjun Singhania',
    mentorId: 'mentor-rajesh-01',
    mentorName: 'Dr. Rajesh Sharma',
    scheduledAt: '2026-11-08T11:00:00',
    durationMinutes: 45,
    topic: 'NBFC Credit Underwriting API & Khata Book Retention',
    status: 'Scheduled',
    meetingLink: 'https://meet.google.com/mesa-ko-nov8',
    location: 'Virtual Link',
    adminApproved: true,
    reportSubmitted: false
  },
  {
    id: 'mtg-04',
    ventureId: 'venture-campuscart',
    ventureName: 'CampusCart',
    founderName: 'Ananya Rao',
    mentorId: 'mentor-rajesh-01',
    mentorName: 'Dr. Rajesh Sharma',
    scheduledAt: '2026-10-28T15:00:00',
    durationMinutes: 45,
    topic: 'Review WhatsApp Concierge Repeat Cohort & PWA Wireframes',
    status: 'Completed',
    adminApproved: true,
    reportSubmitted: true,
    reportId: 'rep-01'
  },
  {
    id: 'mtg-05',
    ventureId: 'venture-medibridge',
    ventureName: 'MediBridge',
    founderName: 'Dr. Shalini Menon',
    mentorId: 'mentor-rajesh-01',
    mentorName: 'Dr. Rajesh Sharma',
    scheduledAt: '2026-10-22T10:30:00',
    durationMinutes: 45,
    topic: 'CDSCO Compliance Documentation & Hospital Network MoUs',
    status: 'Completed',
    adminApproved: true,
    reportSubmitted: true,
    reportId: 'rep-02'
  },
  {
    id: 'mtg-06',
    ventureId: 'venture-loomly',
    ventureName: 'Loomly',
    founderName: 'Pallavi Rao',
    mentorId: 'mentor-rajesh-01',
    mentorName: 'Dr. Rajesh Sharma',
    scheduledAt: '2026-10-18T16:00:00',
    durationMinutes: 45,
    topic: 'Drop #1 Retrospective & Luxury Pricing Elasticity',
    status: 'Completed',
    adminApproved: true,
    reportSubmitted: false // Needs Report! Triggers Report Reminder
  },
  {
    id: 'mtg-07',
    ventureId: 'venture-agriloop',
    ventureName: 'AgriLoop',
    founderName: 'Vikram Choudhury',
    mentorId: 'mentor-rajesh-01',
    mentorName: 'Dr. Rajesh Sharma',
    scheduledAt: '2026-11-12T15:00:00',
    durationMinutes: 45,
    topic: 'Student requested follow-up on NABARD subsidy application',
    status: 'Pending Admin Approval',
    adminApproved: false, // Per prompt: pending student requests are invisible/unconfirmed until Admin approval
    reportSubmitted: false
  }
];

export const INITIAL_REPORTS: MeetingReport[] = [
  {
    id: 'rep-01',
    meetingId: 'mtg-04',
    ventureId: 'venture-campuscart',
    ventureName: 'CampusCart',
    mentorId: 'mentor-rajesh-01',
    mentorName: 'Dr. Rajesh Sharma',
    submittedAt: '2026-10-29T10:15:00',
    sessionDate: 'Oct 28, 2026',
    durationMinutes: 45,
    meetingSummary:
      'Reviewed CampusCart concierge trial data across 184 completed orders in Block B. Observed 48.2% 7-day repeat rate with average ticket size of ₹142. Discussed transitioning from manual WhatsApp order logs to the mobile PWA.',
    adviceProvided:
      'Advised founders not to expand to Block C until inventory shrinkage in Pod 1 drops below 2%. Recommended introducing a minimum order basket of ₹99 to improve contribution margin from ₹14.50 to target ₹18.00.',
    founderEngagementScore: 5,
    actionItems: [
      {
        task: 'Finalize PWA order checkout flow with UPI dynamic QR code',
        assignee: 'Rohan Verma (CTO)',
        dueDate: 'Nov 04, 2026'
      },
      {
        task: 'Submit audited Pod 1 inventory shrinkage report for MSL-3 verification',
        assignee: 'Ananya Rao (CEO)',
        dueDate: 'Nov 07, 2026'
      }
    ],
    adminStatus: 'Approved',
    adminFeedback: 'Mesa Admin reviewed and verified. Action items assigned to student dashboard.',
    invoiced: true
  },
  {
    id: 'rep-02',
    meetingId: 'mtg-05',
    ventureId: 'venture-medibridge',
    ventureName: 'MediBridge',
    mentorId: 'mentor-rajesh-01',
    mentorName: 'Dr. Rajesh Sharma',
    submittedAt: '2026-10-23T14:40:00',
    sessionDate: 'Oct 22, 2026',
    durationMinutes: 45,
    meetingSummary:
      'Evaluated CDSCO testing logs for the integrated ECG box. Verified that all 12 partner clinics achieved operational profitability with 32+ consultations per month per center.',
    adviceProvided:
      'Formulated an institutional distribution agreement for Manipal Health network to secure corporate endorsement prior to raising Series A capital.',
    founderEngagementScore: 5,
    actionItems: [
      {
        task: 'Draft legal addendum for clinic hardware lease agreement',
        assignee: 'Karthik Raman (COO)',
        dueDate: 'Nov 02, 2026'
      }
    ],
    adminStatus: 'Approved',
    adminFeedback: 'Clear strategic outcomes. Approved for faculty archive.',
    invoiced: true
  }
];

export const INITIAL_GOALS: GoalTask[] = [
  {
    id: 'goal-01',
    ventureId: 'venture-campuscart',
    ventureName: 'CampusCart',
    title: 'Audit Pod 1 Inventory Shrinkage & Waste Log',
    description: 'Document 30 days of physical vs ledger inventory counts to ensure shrinkage remains strictly under 2.5%.',
    assignedBy: {
      id: 'mentor-rajesh-01',
      name: 'Dr. Rajesh Sharma',
      role: 'Principal Mentor'
    },
    assignedTo: 'Ananya Rao',
    dueDate: '2026-11-07',
    status: 'Under Review',
    milestone: 'MSL-3 Unit Contribution Viability',
    evidenceSubmitted: {
      title: 'Shrinkage_Audit_March2026.pdf',
      fileUrl: '#',
      date: '2026-11-02',
      status: 'Under Review',
      adminFeedback: 'Currently being cross-checked with warehouse invoices.'
    }
  },
  {
    id: 'goal-02',
    ventureId: 'venture-campuscart',
    ventureName: 'CampusCart',
    title: 'Deploy PWA Dynamic QR Code Checkout',
    description: 'Integrate Razorpay / Cashfree UPI intent flow on the student mobile web client to eliminate manual payment confirmation.',
    assignedBy: {
      id: 'admin-01',
      name: 'Mesa Incubation Cell',
      role: 'Admin'
    },
    assignedTo: 'Rohan Verma',
    dueDate: '2026-11-10',
    status: 'In Progress',
    milestone: 'MSL-3 Product Architecture'
  },
  {
    id: 'goal-03',
    ventureId: 'venture-agriloop',
    ventureName: 'AgriLoop',
    title: 'Secure 3 Additional Paid Farmer Commitments',
    description: 'Close out Niphad FPO token pre-bookings to hit the mandatory 15 paid pre-order threshold.',
    assignedBy: {
      id: 'mentor-rajesh-01',
      name: 'Dr. Rajesh Sharma',
      role: 'Principal Mentor'
    },
    assignedTo: 'Vikram Choudhury',
    dueDate: '2026-11-12',
    status: 'In Progress',
    milestone: 'MSL-2 Payback Willingness'
  },
  {
    id: 'goal-04',
    ventureId: 'venture-kiranaos',
    ventureName: 'KiranaOS',
    title: 'Surpass 500 WhatsApp Supplier Purchase Orders',
    description: 'Cross the empirical supplier volume requirement to establish genuine habitual daily retail stickiness.',
    assignedBy: {
      id: 'mentor-rajesh-01',
      name: 'Dr. Rajesh Sharma',
      role: 'Principal Mentor'
    },
    assignedTo: 'Arjun Singhania',
    dueDate: '2026-11-09',
    status: 'In Progress',
    milestone: 'MSL-3 Daily Active Retailer Usage'
  },
  {
    id: 'goal-05',
    ventureId: 'venture-loomly',
    ventureName: 'Loomly',
    title: 'Submit Unit Cost & Weaver Compensation Matrix',
    description: 'Provide breakdown of fabric procurement, weaver daily wage, finishing, and packaging per saree unit.',
    assignedBy: {
      id: 'mentor-rajesh-01',
      name: 'Dr. Rajesh Sharma',
      role: 'Principal Mentor'
    },
    assignedTo: 'Pallavi Rao',
    dueDate: '2026-11-01',
    status: 'Overdue',
    milestone: 'MSL-2 Unit Economics Audit'
  },
  {
    id: 'goal-06',
    ventureId: 'venture-campuscart',
    ventureName: 'CampusCart',
    title: 'Complete 30 Verified Customer Interviews',
    description: 'Document 30 verbatim transcripts addressing midnight delivery urgency.',
    assignedBy: {
      id: 'admin-01',
      name: 'Mesa Admin',
      role: 'Admin'
    },
    assignedTo: 'Ananya Rao',
    dueDate: '2026-02-05',
    status: 'Completed',
    milestone: 'MSL-1 Validated Customer Problem',
    evidenceSubmitted: {
      title: 'CampusCart_30_Customer_Transcripts.pdf',
      fileUrl: '#',
      date: '2026-02-02',
      status: 'Approved',
      adminFeedback: 'Passed faculty validation.'
    }
  }
];

export const VENTURE_ACTIVITIES: Record<string, VentureActivity[]> = {
  'venture-campuscart': [
    {
      id: 'act-01',
      date: 'Nov 02, 2026',
      timestamp: '11:42 AM',
      type: 'Evidence Submitted',
      actor: 'Ananya Rao',
      actorRole: 'Founder (CEO)',
      description: 'Submitted "Shrinkage_Audit_March2026.pdf" for MSL-3 Unit Contribution criterion verification.'
    },
    {
      id: 'act-02',
      date: 'Oct 29, 2026',
      timestamp: '10:15 AM',
      type: 'Meeting Report Submitted',
      actor: 'Dr. Rajesh Sharma',
      actorRole: 'Principal Mentor',
      description: 'Submitted Mentorship Session #4 report with advice on unit economics and UPI QR flow.'
    },
    {
      id: 'act-03',
      date: 'Oct 28, 2026',
      timestamp: '03:45 PM',
      type: 'Mentorship Meeting Completed',
      actor: 'Dr. Rajesh Sharma & Ananya Rao',
      actorRole: 'Mentorship Session',
      description: 'Completed 45-minute structured review on WhatsApp concierge cohort retention.'
    },
    {
      id: 'act-04',
      date: 'Oct 24, 2026',
      timestamp: '04:00 PM',
      type: 'Goal Assigned',
      actor: 'Dr. Rajesh Sharma',
      actorRole: 'Principal Mentor',
      description: 'Assigned goal "Audit Pod 1 Inventory Shrinkage & Waste Log" due on Nov 07.'
    },
    {
      id: 'act-05',
      date: 'Mar 20, 2026',
      timestamp: '02:30 PM',
      type: 'MSL Criterion Verified',
      actor: 'Mesa Incubation Admin',
      actorRole: 'Admin',
      description: 'Formally marked "Problem-Solution Fit Prototype" criterion as VERIFIED (184 orders, 48.2% repeat rate).'
    },
    {
      id: 'act-06',
      date: 'Feb 10, 2026',
      timestamp: '05:00 PM',
      type: 'Venture Stage Advanced',
      actor: 'Academic Board',
      actorRole: 'Admin',
      description: 'Venture successfully promoted from Discover Stage to Build Stage.'
    },
    {
      id: 'act-07',
      date: 'Jan 16, 2026',
      timestamp: '09:00 AM',
      type: 'Mentor Assigned',
      actor: 'Dean of Mentorship',
      actorRole: 'Admin',
      description: 'Assigned Dr. Rajesh Sharma as Principal Mentor and Priya Nair as Associate Mentor.'
    },
    {
      id: 'act-08',
      date: 'Jan 15, 2026',
      timestamp: '10:00 AM',
      type: 'Venture Created',
      actor: 'Ananya Rao & Rohan Verma',
      actorRole: 'Student Founders',
      description: 'CampusCart officially matriculated into Mesa Startup Hub ILS · PGP 2026 Cohort.'
    }
  ],
  'venture-agriloop': [
    {
      id: 'act-al-01',
      date: 'Nov 01, 2026',
      timestamp: '02:15 PM',
      type: 'Evidence Submitted',
      actor: 'Vikram Choudhury',
      actorRole: 'Founder',
      description: 'Submitted Farmer Paid Pre-Orders log for Niphad FPO.'
    },
    {
      id: 'act-al-02',
      date: 'Oct 15, 2026',
      timestamp: '04:30 PM',
      type: 'Mentorship Meeting Completed',
      actor: 'Dr. Rajesh Sharma',
      actorRole: 'Principal Mentor',
      description: 'Reviewed solar thermal storage telemetry data.'
    },
    {
      id: 'act-al-03',
      date: 'Feb 05, 2026',
      timestamp: '11:00 AM',
      type: 'MSL Criterion Verified',
      actor: 'Mesa Admin',
      actorRole: 'Admin',
      description: 'MSL Criterion "Validated Customer Problem" approved and verified.'
    }
  ]
};

export const INITIAL_AVAILABILITY: AvailabilitySlot[] = [
  // Monday: 3 separate slots
  {
    id: 'av-mon-1',
    mentorId: 'mentor-rajesh-01',
    dayOfWeek: 'Monday',
    startTime: '09:00',
    endTime: '11:00',
    slotDurationMinutes: 45,
    isActive: true
  },
  {
    id: 'av-mon-2',
    mentorId: 'mentor-rajesh-01',
    dayOfWeek: 'Monday',
    startTime: '14:00',
    endTime: '16:00',
    slotDurationMinutes: 45,
    isActive: true
  },
  {
    id: 'av-mon-3',
    mentorId: 'mentor-rajesh-01',
    dayOfWeek: 'Monday',
    startTime: '18:00',
    endTime: '19:00',
    slotDurationMinutes: 45,
    isActive: true
  },
  // Wednesday: 2 separate slots
  {
    id: 'av-wed-1',
    mentorId: 'mentor-rajesh-01',
    dayOfWeek: 'Wednesday',
    startTime: '10:00',
    endTime: '12:00',
    slotDurationMinutes: 45,
    isActive: true
  },
  {
    id: 'av-wed-2',
    mentorId: 'mentor-rajesh-01',
    dayOfWeek: 'Wednesday',
    startTime: '15:00',
    endTime: '17:00',
    slotDurationMinutes: 45,
    isActive: true
  },
  // Friday: 1 slot
  {
    id: 'av-fri-1',
    mentorId: 'mentor-rajesh-01',
    dayOfWeek: 'Friday',
    startTime: '09:00',
    endTime: '11:00',
    slotDurationMinutes: 45,
    isActive: true
  }
];

export const INITIAL_BLACKOUT_DATES: BlackoutDate[] = [
  {
    id: 'bo-1',
    mentorId: 'mentor-rajesh-01',
    date: '2026-11-14',
    reason: 'Mesa Faculty Research Symposium'
  },
  {
    id: 'bo-2',
    mentorId: 'mentor-rajesh-01',
    date: '2026-11-20',
    reason: 'Venture Partner Investment Committee Meeting'
  }
];

export const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'inv-2026-001',
    invoiceNumber: 'INV-MSH-2026-084',
    mentorId: 'mentor-rajesh-01',
    mentorName: 'Dr. Rajesh Sharma',
    meetingId: 'mtg-04',
    meetingTopic: 'Review WhatsApp Concierge Repeat Cohort & PWA Wireframes',
    ventureName: 'CampusCart',
    meetingDate: 'Oct 28, 2026',
    sessionDuration: 45,
    ratePerSession: 3500, // Institutional honorarium per 45-min verified session
    taxRate: 0.18,
    totalAmount: 4130,
    createdAt: '2026-10-30',
    status: 'Approved',
    notes: 'Report verified and approved by Mesa Academic Cell.'
  },
  {
    id: 'inv-2026-002',
    invoiceNumber: 'INV-MSH-2026-079',
    mentorId: 'mentor-rajesh-01',
    mentorName: 'Dr. Rajesh Sharma',
    meetingId: 'mtg-05',
    meetingTopic: 'CDSCO Compliance Documentation & Hospital Network MoUs',
    ventureName: 'MediBridge',
    meetingDate: 'Oct 22, 2026',
    sessionDuration: 45,
    ratePerSession: 3500,
    taxRate: 0.18,
    totalAmount: 4130,
    createdAt: '2026-10-25',
    status: 'Paid',
    paymentDate: '2026-10-31',
    notes: 'Disbursed via Direct Bank Transfer (Mesa Incubation Account).'
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-01',
    title: 'New Evidence Submitted for Review',
    message: 'Ananya Rao (CampusCart) submitted "Shrinkage_Audit_March2026.pdf" for goal #01.',
    timestamp: '2 hours ago',
    read: false,
    category: 'Evidence',
    actionUrl: 'venture-campuscart'
  },
  {
    id: 'notif-02',
    title: 'Report Reminder: Mentorship Meeting with Loomly',
    message: 'Session with Pallavi Rao took place on Oct 18. Please submit your structured meeting report.',
    timestamp: '1 day ago',
    read: false,
    category: 'Reports'
  },
  {
    id: 'notif-03',
    title: 'Upcoming Session Confirmed',
    message: 'Mentorship meeting with CampusCart is confirmed for tomorrow at 2:30 PM (Incubation Studio 3B).',
    timestamp: '1 day ago',
    read: true,
    category: 'Meetings'
  },
  {
    id: 'notif-04',
    title: 'Admin Verification Update',
    message: 'Prof. K. Iyer approved the customer interview transcripts for CampusCart MSL-1.',
    timestamp: '3 days ago',
    read: true,
    category: 'Admin'
  },
  {
    id: 'notif-05',
    title: 'Invoice Disbursed',
    message: 'Invoice INV-MSH-2026-079 for MediBridge (₹4,130) has been paid.',
    timestamp: '4 days ago',
    read: true,
    category: 'Reports'
  }
];
