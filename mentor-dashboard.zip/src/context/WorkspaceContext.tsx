import React, { createContext, useContext, useState } from 'react';
import {
  Venture,
  MentorshipMeeting,
  MeetingReport,
  GoalTask,
  AvailabilitySlot,
  BlackoutDate,
  Invoice,
  NotificationItem,
  MentorProfile,
  VentureActivity
} from '../types';
import {
  CURRENT_MENTOR,
  INITIAL_VENTURES,
  INITIAL_MEETINGS,
  INITIAL_REPORTS,
  INITIAL_GOALS,
  VENTURE_ACTIVITIES,
  INITIAL_AVAILABILITY,
  INITIAL_BLACKOUT_DATES,
  INITIAL_INVOICES,
  INITIAL_NOTIFICATIONS
} from '../data/mockData';

export type WorkspacePage =
  | 'dashboard'
  | 'mentorship-sessions'
  | 'meetings'
  | 'reports'
  | 'goals'
  | 'directory'
  | 'venture-history'
  | 'availability'
  | 'invoices'
  | 'notifications'
  | 'profile';

export type MentorshipSessionsTab = 'meetings' | 'reports' | 'availability';

export type VentureHistoryTab =
  | 'overview'
  | 'journey'
  | 'goals'
  | 'meetings'
  | 'msl'
  | 'activity';

interface WorkspaceContextType {
  currentPage: WorkspacePage;
  setCurrentPage: (page: WorkspacePage) => void;
  sessionsTab: MentorshipSessionsTab;
  setSessionsTab: (tab: MentorshipSessionsTab) => void;
  openMentorshipSessions: (tab?: MentorshipSessionsTab) => void;
  selectedVentureId: string | null;
  selectedVenture: Venture | null;
  ventureHistoryTab: VentureHistoryTab;
  setVentureHistoryTab: (tab: VentureHistoryTab) => void;
  openVentureHistory: (ventureId: string, tab?: VentureHistoryTab) => void;
  backToDirectory: () => void;

  // Data
  mentor: MentorProfile;
  ventures: Venture[];
  meetings: MentorshipMeeting[];
  reports: MeetingReport[];
  goals: GoalTask[];
  availability: AvailabilitySlot[];
  blackoutDates: BlackoutDate[];
  invoices: Invoice[];
  notifications: NotificationItem[];
  getVentureActivities: (ventureId: string) => VentureActivity[];

  // Mutators & actions
  submitReport: (report: Omit<MeetingReport, 'id' | 'submittedAt' | 'invoiced' | 'adminStatus'>) => void;
  createGoal: (goal: Omit<GoalTask, 'id' | 'status'>) => void;
  createInvoice: (meetingId: string) => boolean;
  updateAvailability: (slots: AvailabilitySlot[]) => void;
  addAvailabilitySlot: (slot: Omit<AvailabilitySlot, 'id'>) => AvailabilitySlot;
  updateAvailabilitySlot: (id: string, updatedFields: Partial<AvailabilitySlot>) => void;
  removeAvailabilitySlot: (id: string) => void;
  addBlackoutDate: (date: string, reason: string) => void;
  removeBlackoutDate: (id: string) => void;
  saveAvailabilityToSupabase: (slotsToSave?: AvailabilitySlot[], blackoutsToSave?: BlackoutDate[]) => boolean;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  unreadNotificationsCount: number;

  // Active Modals
  isReportModalOpen: boolean;
  setIsReportModalOpen: (open: boolean) => void;
  reportMeetingTarget: MentorshipMeeting | null;
  openReportModal: (meeting: MentorshipMeeting) => void;

  isGoalModalOpen: boolean;
  setIsGoalModalOpen: (open: boolean) => void;
  preselectedVentureForGoal: string | null;
  openGoalModal: (ventureId?: string) => void;

  isEvidenceModalOpen: boolean;
  setIsEvidenceModalOpen: (open: boolean) => void;
  viewingEvidence: {
    title: string;
    fileType?: string;
    fileUrl?: string;
    submissionDate?: string;
    adminApprovalStatus?: string;
    adminFeedback?: string;
    verifiedBy?: string;
  } | null;
  openEvidenceModal: (evidence: any) => void;

  // Role simulation
  isSimulatingUnassignedMentor: boolean;
  setIsSimulatingUnassignedMentor: (val: boolean) => void;
}

const WorkspaceContext = createContext<WorkspaceContextType | undefined>(undefined);

export const WorkspaceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentPage, setCurrentPageState] = useState<WorkspacePage>('dashboard');
  const [sessionsTab, setSessionsTab] = useState<MentorshipSessionsTab>('meetings');
  const [selectedVentureId, setSelectedVentureId] = useState<string | null>('venture-campuscart');
  const [ventureHistoryTab, setVentureHistoryTab] = useState<VentureHistoryTab>('overview');

  const setCurrentPage = (page: WorkspacePage) => {
    if (page === 'meetings') {
      setCurrentPageState('mentorship-sessions');
      setSessionsTab('meetings');
    } else if (page === 'reports') {
      setCurrentPageState('mentorship-sessions');
      setSessionsTab('reports');
    } else if (page === 'availability') {
      setCurrentPageState('mentorship-sessions');
      setSessionsTab('availability');
    } else {
      setCurrentPageState(page);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openMentorshipSessions = (tab: MentorshipSessionsTab = 'meetings') => {
    setSessionsTab(tab);
    setCurrentPageState('mentorship-sessions');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const [mentor, setMentor] = useState<MentorProfile>(CURRENT_MENTOR);
  const [ventures, setVentures] = useState<Venture[]>(INITIAL_VENTURES);
  const [meetings, setMeetings] = useState<MentorshipMeeting[]>(INITIAL_MEETINGS);
  const [reports, setReports] = useState<MeetingReport[]>(INITIAL_REPORTS);
  const [goals, setGoals] = useState<GoalTask[]>(INITIAL_GOALS);

  // Load previously saved availability & blackout dates from persistence (Supabase cache)
  const [availability, setAvailability] = useState<AvailabilitySlot[]>(() => {
    try {
      const saved = localStorage.getItem('msh_mentor_availability_slots');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Error loading saved availability slots', e);
    }
    return INITIAL_AVAILABILITY;
  });

  const [blackoutDates, setBlackoutDates] = useState<BlackoutDate[]>(() => {
    try {
      const saved = localStorage.getItem('msh_mentor_blackout_dates');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error('Error loading saved blackout dates', e);
    }
    return INITIAL_BLACKOUT_DATES;
  });

  const [invoices, setInvoices] = useState<Invoice[]>(INITIAL_INVOICES);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [activitiesMap, setActivitiesMap] = useState<Record<string, VentureActivity[]>>(VENTURE_ACTIVITIES);

  const [isSimulatingUnassignedMentor, setIsSimulatingUnassignedMentor] = useState(false);

  // Modal States
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportMeetingTarget, setReportMeetingTarget] = useState<MentorshipMeeting | null>(null);

  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [preselectedVentureForGoal, setPreselectedVentureForGoal] = useState<string | null>(null);

  const [isEvidenceModalOpen, setIsEvidenceModalOpen] = useState(false);
  const [viewingEvidence, setViewingEvidence] = useState<any>(null);

  const selectedVenture = ventures.find((v) => v.id === selectedVentureId) || null;

  const openVentureHistory = (ventureId: string, tab: VentureHistoryTab = 'overview') => {
    setSelectedVentureId(ventureId);
    setVentureHistoryTab(tab);
    setCurrentPage('venture-history');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const backToDirectory = () => {
    setCurrentPage('directory');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openReportModal = (meeting: MentorshipMeeting) => {
    setReportMeetingTarget(meeting);
    setIsReportModalOpen(true);
  };

  const openGoalModal = (ventureId?: string) => {
    setPreselectedVentureForGoal(ventureId || selectedVentureId || null);
    setIsGoalModalOpen(true);
  };

  const openEvidenceModal = (evidence: any) => {
    setViewingEvidence(evidence);
    setIsEvidenceModalOpen(true);
  };

  const getVentureActivities = (ventureId: string): VentureActivity[] => {
    const list = activitiesMap[ventureId] || [];
    return [...list].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const submitReport = (
    reportData: Omit<MeetingReport, 'id' | 'submittedAt' | 'invoiced' | 'adminStatus'>
  ) => {
    const newReportId = `rep-${Date.now()}`;
    const newReport: MeetingReport = {
      ...reportData,
      id: newReportId,
      submittedAt: new Date().toISOString(),
      adminStatus: 'Pending Review',
      invoiced: false
    };

    setReports((prev) => [newReport, ...prev]);

    // Mark meeting as reported
    setMeetings((prev) =>
      prev.map((m) =>
        m.id === reportData.meetingId
          ? { ...m, reportSubmitted: true, reportId: newReportId, status: 'Completed' }
          : m
      )
    );

    // Add activity to venture timeline
    const ventureAct: VentureActivity = {
      id: `act-${Date.now()}`,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'Meeting Report Submitted',
      actor: mentor.name,
      actorRole: mentor.programmeRole,
      description: `Submitted structured meeting report for session on "${reportData.ventureName}".`
    };

    setActivitiesMap((prev) => ({
      ...prev,
      [reportData.ventureId]: [ventureAct, ...(prev[reportData.ventureId] || [])]
    }));

    // Add notification
    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: 'Report Submitted for Admin Review',
      message: `Your report for ${reportData.ventureName} has been routed to the Mesa Incubation Director.`,
      timestamp: 'Just now',
      read: false,
      category: 'Reports'
    };
    setNotifications((prev) => [newNotif, ...prev]);

    setIsReportModalOpen(false);
    setReportMeetingTarget(null);
  };

  const createGoal = (goalData: Omit<GoalTask, 'id' | 'status'>) => {
    const newGoal: GoalTask = {
      ...goalData,
      id: `goal-${Date.now()}`,
      status: 'In Progress'
    };

    setGoals((prev) => [newGoal, ...prev]);

    // Add activity
    const ventureAct: VentureActivity = {
      id: `act-${Date.now()}`,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'Goal Assigned',
      actor: mentor.name,
      actorRole: mentor.programmeRole,
      description: `Assigned new milestone goal: "${goalData.title}" (Due: ${goalData.dueDate}).`
    };

    setActivitiesMap((prev) => ({
      ...prev,
      [goalData.ventureId]: [ventureAct, ...(prev[goalData.ventureId] || [])]
    }));

    setIsGoalModalOpen(false);
  };

  const createInvoice = (meetingId: string): boolean => {
    const meeting = meetings.find((m) => m.id === meetingId);
    if (!meeting) return false;

    // Check one-meeting-one-invoice rule
    const alreadyInvoiced = invoices.some((inv) => inv.meetingId === meetingId);
    if (alreadyInvoiced) return false;

    const report = reports.find((r) => r.meetingId === meetingId);
    // Eligibility requires report to exist
    if (!report) return false;

    const rate = 3500;
    const tax = rate * 0.18;
    const total = rate + tax;

    const newInvoice: Invoice = {
      id: `inv-${Date.now()}`,
      invoiceNumber: `INV-MSH-2026-${Math.floor(100 + Math.random() * 900)}`,
      mentorId: mentor.id,
      mentorName: mentor.name,
      meetingId: meeting.id,
      meetingTopic: meeting.topic,
      ventureName: meeting.ventureName,
      meetingDate: new Date(meeting.scheduledAt).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      sessionDuration: meeting.durationMinutes,
      ratePerSession: rate,
      taxRate: 0.18,
      totalAmount: total,
      createdAt: new Date().toISOString().split('T')[0],
      status: 'Submitted',
      notes: `Honorarium claim for verified session with ${meeting.ventureName}.`
    };

    setInvoices((prev) => [newInvoice, ...prev]);

    // Mark report as invoiced
    setReports((prev) =>
      prev.map((r) => (r.id === report.id ? { ...r, invoiced: true } : r))
    );

    return true;
  };

  const updateAvailability = (slots: AvailabilitySlot[]) => {
    setAvailability(slots);
  };

  const addAvailabilitySlot = (slotData: Omit<AvailabilitySlot, 'id'>): AvailabilitySlot => {
    const newSlot: AvailabilitySlot = {
      ...slotData,
      id: `av-${slotData.dayOfWeek.toLowerCase().slice(0, 3)}-${Date.now()}`
    };
    setAvailability((prev) => [...prev, newSlot]);
    return newSlot;
  };

  const updateAvailabilitySlot = (id: string, updatedFields: Partial<AvailabilitySlot>) => {
    setAvailability((prev) =>
      prev.map((slot) => (slot.id === id ? { ...slot, ...updatedFields } : slot))
    );
  };

  const removeAvailabilitySlot = (id: string) => {
    setAvailability((prev) => prev.filter((slot) => slot.id !== id));
  };

  const addBlackoutDate = (date: string, reason: string) => {
    const newBlackout: BlackoutDate = {
      id: `bo-${Date.now()}`,
      mentorId: mentor.id,
      date,
      reason: reason || 'Unavailable'
    };
    setBlackoutDates((prev) => [...prev, newBlackout]);
  };

  const removeBlackoutDate = (id: string) => {
    setBlackoutDates((prev) => prev.filter((bo) => bo.id !== id));
  };

  const saveAvailabilityToSupabase = (
    slotsToSave?: AvailabilitySlot[],
    blackoutsToSave?: BlackoutDate[]
  ): boolean => {
    try {
      const finalSlots = slotsToSave !== undefined ? slotsToSave : availability;
      const finalBlackouts = blackoutsToSave !== undefined ? blackoutsToSave : blackoutDates;

      if (slotsToSave !== undefined) setAvailability(slotsToSave);
      if (blackoutsToSave !== undefined) setBlackoutDates(blackoutsToSave);

      localStorage.setItem('msh_mentor_availability_slots', JSON.stringify(finalSlots));
      localStorage.setItem('msh_mentor_blackout_dates', JSON.stringify(finalBlackouts));

      const newNotif: NotificationItem = {
        id: `notif-av-${Date.now()}`,
        title: 'Availability Saved to Supabase',
        message: `Saved ${finalSlots.length} weekly recurring slots and ${finalBlackouts.length} blackout dates. Synced with Mesa Admin Scheduling Engine.`,
        timestamp: 'Just now',
        read: false,
        category: 'Admin'
      };
      setNotifications((prev) => [newNotif, ...prev]);
      return true;
    } catch (e) {
      console.error('Failed to save availability to Supabase', e);
      return false;
    }
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;

  return (
    <WorkspaceContext.Provider
      value={{
        currentPage,
        setCurrentPage,
        sessionsTab,
        setSessionsTab,
        openMentorshipSessions,
        selectedVentureId,
        selectedVenture,
        ventureHistoryTab,
        setVentureHistoryTab,
        openVentureHistory,
        backToDirectory,
        mentor,
        ventures,
        meetings,
        reports,
        goals,
        availability,
        blackoutDates,
        invoices,
        notifications,
        getVentureActivities,
        submitReport,
        createGoal,
        createInvoice,
        updateAvailability,
        addAvailabilitySlot,
        updateAvailabilitySlot,
        removeAvailabilitySlot,
        addBlackoutDate,
        removeBlackoutDate,
        saveAvailabilityToSupabase,
        markNotificationRead,
        markAllNotificationsRead,
        unreadNotificationsCount,
        isReportModalOpen,
        setIsReportModalOpen,
        reportMeetingTarget,
        openReportModal,
        isGoalModalOpen,
        setIsGoalModalOpen,
        preselectedVentureForGoal,
        openGoalModal,
        isEvidenceModalOpen,
        setIsEvidenceModalOpen,
        viewingEvidence,
        openEvidenceModal,
        isSimulatingUnassignedMentor,
        setIsSimulatingUnassignedMentor
      }}
    >
      {children}
    </WorkspaceContext.Provider>
  );
};

export const useWorkspace = () => {
  const context = useContext(WorkspaceContext);
  if (!context) {
    throw new Error('useWorkspace must be used within a WorkspaceProvider');
  }
  return context;
};
