export type Stage = 'Discover' | 'Validate' | 'Build' | 'Launch' | 'Grow';

export interface Founder {
  name: string;
  role: string;
  email: string;
  avatar?: string;
  phone?: string;
  programBatch?: string;
}

export interface MentorAssignment {
  principalMentor: {
    id: string;
    name: string;
    role: string;
    email: string;
  };
  associateMentor?: {
    id: string;
    name: string;
    role: string;
    email: string;
  };
}

export interface PlaybookActivity {
  id: string;
  title: string;
  description: string;
  status: 'Completed' | 'In Progress' | 'Pending Review' | 'Not Started';
  completedDate?: string;
  evidenceSubmitted?: {
    id: string;
    title: string;
    fileType: 'PDF' | 'DOCX' | 'SHEET' | 'LINK';
    fileUrl: string;
    submissionDate: string;
    adminApprovalStatus: 'Approved' | 'Pending Review' | 'Needs Revision';
    adminFeedback?: string;
    verifiedBy?: string;
  };
}

export interface PlaybookWeek {
  weekNumber: number;
  phase: string;
  title: string;
  status: 'Completed' | 'Current' | 'Upcoming';
  completionDate?: string;
  activities: PlaybookActivity[];
}

export interface GoalTask {
  id: string;
  ventureId: string;
  ventureName: string;
  title: string;
  description: string;
  assignedBy: {
    id: string;
    name: string;
    role: 'Admin' | 'Principal Mentor' | 'Associate Mentor';
  };
  assignedTo: string;
  dueDate: string;
  status: 'Completed' | 'In Progress' | 'Overdue' | 'Under Review';
  milestone: string;
  evidenceSubmitted?: {
    title: string;
    fileUrl: string;
    date: string;
    status: 'Approved' | 'Under Review' | 'Needs Revision';
    adminFeedback?: string;
  };
}

export interface MentorshipMeeting {
  id: string;
  ventureId: string;
  ventureName: string;
  founderName: string;
  founderAvatar?: string;
  mentorId: string;
  mentorName: string;
  scheduledAt: string;
  durationMinutes: number;
  topic: string;
  status: 'Scheduled' | 'Completed' | 'Rescheduled' | 'Pending Admin Approval';
  meetingLink?: string;
  location?: string;
  adminApproved: boolean;
  reportSubmitted?: boolean;
  reportId?: string;
}

export interface MeetingReport {
  id: string;
  meetingId: string;
  ventureId: string;
  ventureName: string;
  mentorId: string;
  mentorName: string;
  submittedAt: string;
  sessionDate: string;
  durationMinutes: number;
  meetingSummary: string;
  adviceProvided: string;
  founderEngagementScore: number; // 1 to 5
  actionItems: {
    task: string;
    assignee: string;
    dueDate: string;
  }[];
  adminStatus: 'Approved' | 'Pending Review' | 'Revisions Requested';
  adminFeedback?: string;
  invoiced: boolean;
}

export interface MSLTask {
  id: string;
  title: string;
  requiredMetric: string;
  currentMetric: string;
  status: 'Approved' | 'Under Review' | 'Pending Submission' | 'Needs Revision' | 'In Progress';
  evidenceUrl?: string;
  evidenceName?: string;
  verifiedDate?: string;
  verifiedBy?: string;
}

export interface MSLCriterion {
  id: string;
  name: string;
  category: string;
  description: string;
  isVerified: boolean;
  verifiedDate?: string;
  tasks: MSLTask[];
}

export interface WorkshopAttendance {
  id: string;
  title: string;
  date: string;
  instructor: string;
  attended: boolean;
  attendanceType: 'In-Person' | 'Virtual';
  notes?: string;
}

export interface VentureActivity {
  id: string;
  date: string;
  timestamp: string;
  type:
    | 'Venture Created'
    | 'Mentor Assigned'
    | 'Goal Assigned'
    | 'Evidence Submitted'
    | 'Evidence Approved'
    | 'Playbook Activity Completed'
    | 'MSL Criterion Verified'
    | 'Mentorship Meeting Completed'
    | 'Meeting Report Submitted'
    | 'Workshop Attended'
    | 'Venture Stage Advanced';
  actor: string;
  actorRole: string;
  description: string;
  meta?: Record<string, any>;
}

export interface Venture {
  id: string;
  name: string;
  tagline: string;
  logo: string;
  description: string;
  industry: string;
  currentStage: Stage;
  currentMSL: string; // e.g. "MSL Level 3 - Problem-Solution Fit"
  foundingDate: string;
  programme: string;
  status: 'Active Incubate' | 'Graduated' | 'On Hold';
  founders: Founder[];
  mentorAssignment: MentorAssignment;
  isAssignedToCurrentMentor: boolean; // Permission check
  stageMilestones: {
    stage: Stage;
    status: 'Completed' | 'Current' | 'Upcoming';
    completionDate?: string;
    milestoneName: string;
  }[];
  playbookWeeks: PlaybookWeek[];
  mslCriteria: MSLCriterion[];
  workshops: WorkshopAttendance[];
  metrics: {
    mrr?: string;
    customerInterviewsCount: number;
    teamSize: number;
    fundingRaised?: string;
    targetMarket: string;
  };
}

export type DayOfWeek =
  | 'Monday'
  | 'Tuesday'
  | 'Wednesday'
  | 'Thursday'
  | 'Friday'
  | 'Saturday'
  | 'Sunday';

export interface AvailabilitySlot {
  id: string;
  mentorId?: string;
  dayOfWeek: DayOfWeek;
  startTime: string; // "09:00"
  endTime: string;   // "11:00"
  slotDurationMinutes?: number; // 30, 45, 60
  isActive?: boolean;
}

export interface BlackoutDate {
  id: string;
  mentorId?: string;
  date: string; // "YYYY-MM-DD"
  reason: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  mentorId: string;
  mentorName: string;
  meetingId: string;
  meetingTopic: string;
  ventureName: string;
  meetingDate: string;
  sessionDuration: number;
  ratePerSession: number; // Institutional mentorship honorarium rate
  taxRate: number;
  totalAmount: number;
  createdAt: string;
  status: 'Draft' | 'Submitted' | 'Under Review' | 'Approved' | 'Paid';
  paymentDate?: string;
  notes?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  category: 'Meetings' | 'Reports' | 'Goals' | 'Admin' | 'Evidence';
  actionUrl?: string;
}

export interface MentorProfile {
  id: string;
  name: string;
  salutation: string;
  title: string;
  email: string;
  phone: string;
  avatar: string;
  programmeRole: 'Principal Mentor' | 'Associate Mentor' | 'EIR';
  cohort: string;
  bio: string;
  areasOfExpertise: string[];
  totalSessionsCompleted: number;
  totalHoursMentored: number;
  activeVenturesCount: number;
  studentSatisfactionRating: number;
  bufferTimeMinutes: number;
  preferredMeetingLength: number;
}
